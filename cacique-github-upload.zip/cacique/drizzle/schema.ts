import { index, int, mysqlEnum, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const series = mysqlTable("series", {
  id: int("id").autoincrement().primaryKey(),
  code: varchar("code", { length: 32 }).notNull().unique(),
  name: varchar("name", { length: 64 }).notNull(),
  color: varchar("color", { length: 16 }).notNull().default("#d8a94a"),
  minPoints: int("minPoints").notNull().default(0),
  orderIndex: int("orderIndex").notNull().default(0),
  active: int("active").notNull().default(1),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const players = mysqlTable("players", {
  id: int("id").autoincrement().primaryKey(),
  nickname: varchar("nickname", { length: 40 }).notNull(),
  normalizedNickname: varchar("normalizedNickname", { length: 40 }).notNull().unique(),
  userId: int("userId").references(() => users.id, { onDelete: "set null" }),
  gameId: varchar("gameId", { length: 40 }),
  avatarUrl: varchar("avatarUrl", { length: 512 }),
  seriesId: int("seriesId").references(() => series.id, { onDelete: "set null" }),
  points: int("points").notNull().default(0),
  wins: int("wins").notNull().default(0),
  losses: int("losses").notNull().default(0),
  status: mysqlEnum("status", ["active", "inactive"]).notNull().default("active"),
  notes: text("notes"),
  joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ bySeries: index("players_series_idx").on(table.seriesId), byPoints: index("players_points_idx").on(table.points), onePlayerPerUser: uniqueIndex("players_user_unique").on(table.userId) }));

export const matches = mysqlTable("matches", {
  id: int("id").autoincrement().primaryKey(),
  mode: varchar("mode", { length: 32 }).notNull().default("1x1"),
  title: varchar("title", { length: 120 }),
  status: mysqlEnum("status", ["scheduled", "awaiting_proofs", "under_review", "approved", "rejected"]).notNull().default("scheduled"),
  winnerTeam: mysqlEnum("winnerTeam", ["A", "B"]),
  resultText: varchar("resultText", { length: 160 }),
  playedAt: timestamp("playedAt").defaultNow().notNull(),
  createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
  auditedBy: int("auditedBy").references(() => users.id, { onDelete: "set null" }),
  auditReason: text("auditReason"),
  auditedAt: timestamp("auditedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ byStatus: index("matches_status_idx").on(table.status), byDate: index("matches_played_idx").on(table.playedAt) }));

export const matchParticipants = mysqlTable("match_participants", {
  id: int("id").autoincrement().primaryKey(),
  matchId: int("matchId").notNull().references(() => matches.id, { onDelete: "cascade" }),
  playerId: int("playerId").notNull().references(() => players.id, { onDelete: "restrict" }),
  team: mysqlEnum("team", ["A", "B"]).notNull(),
  stakeAmount: int("stakeAmount").notNull().default(0),
  seriesIdAtMatch: int("seriesIdAtMatch").references(() => series.id, { onDelete: "set null" }),
  seriesNameAtMatch: varchar("seriesNameAtMatch", { length: 64 }),
  pointsAwarded: int("pointsAwarded").notNull().default(0),
}, (table) => ({ uniquePlayerPerMatch: uniqueIndex("match_player_unique").on(table.matchId, table.playerId), byMatch: index("match_participants_match_idx").on(table.matchId), bySeriesAtMatch: index("match_participants_series_snapshot_idx").on(table.seriesIdAtMatch) }));

export const proofs = mysqlTable("proofs", {
  id: int("id").autoincrement().primaryKey(),
  matchId: int("matchId").notNull().references(() => matches.id, { onDelete: "cascade" }),
  playerId: int("playerId").notNull().references(() => players.id, { onDelete: "restrict" }),
  objectKey: varchar("objectKey", { length: 255 }).notNull(),
  fileName: varchar("fileName", { length: 180 }).notNull(),
  mimeType: varchar("mimeType", { length: 64 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "review"]).notNull().default("pending"),
  reviewReason: text("reviewReason"),
  reviewedBy: int("reviewedBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  reviewedAt: timestamp("reviewedAt"),
}, (table) => ({ byMatch: index("proofs_match_idx").on(table.matchId), byPlayer: index("proofs_player_idx").on(table.playerId) }));

export const scoreEvents = mysqlTable("score_events", {
  id: int("id").autoincrement().primaryKey(),
  matchId: int("matchId").notNull().references(() => matches.id, { onDelete: "restrict" }),
  playerId: int("playerId").notNull().references(() => players.id, { onDelete: "restrict" }),
  points: int("points").notNull(),
  reason: varchar("reason", { length: 180 }).notNull(),
  createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ oneEventPerPlayerMatch: uniqueIndex("score_match_player_unique").on(table.matchId, table.playerId), byPlayer: index("score_player_idx").on(table.playerId) }));

export const scoreAdjustments = mysqlTable("score_adjustments", {
  id: int("id").autoincrement().primaryKey(),
  playerId: int("playerId").notNull().references(() => players.id, { onDelete: "restrict" }),
  delta: int("delta").notNull(),
  reason: varchar("reason", { length: 300 }).notNull(),
  createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ byPlayer: index("score_adjustments_player_idx").on(table.playerId), byDate: index("score_adjustments_date_idx").on(table.createdAt) }));

export const draws = mysqlTable("draws", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 120 }).notNull(),
  mode: varchar("mode", { length: 48 }).notNull().default("random"),
  slots: int("slots").notNull(),
  status: mysqlEnum("status", ["draft", "confirmed"]).notNull().default("confirmed"),
  participantNames: text("participantNames").notNull(),
  resultNames: text("resultNames").notNull(),
  createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const adminRoles = mysqlTable("admin_roles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  role: mysqlEnum("role", ["match_admin", "auditor", "moderator"]).notNull(),
  grantedBy: int("grantedBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const communitySettings = mysqlTable("community_settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 64 }).notNull().unique(),
  settingValue: text("settingValue").notNull(),
  updatedBy: int("updatedBy").references(() => users.id, { onDelete: "set null" }),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 120 }).notNull(),
  body: text("body").notNull(),
  active: int("active").notNull().default(1),
  createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const auditLog = mysqlTable("audit_log", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId").references(() => users.id, { onDelete: "set null" }),
  action: varchar("action", { length: 80 }).notNull(),
  entityType: varchar("entityType", { length: 50 }).notNull(),
  entityId: int("entityId"),
  details: text("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({ byEntity: index("audit_entity_idx").on(table.entityType, table.entityId), byDate: index("audit_date_idx").on(table.createdAt) }));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Player = typeof players.$inferSelect;
export type Series = typeof series.$inferSelect;
export type Match = typeof matches.$inferSelect;
