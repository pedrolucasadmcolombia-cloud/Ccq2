INSERT IGNORE INTO `series` (`code`,`name`,`color`,`minPoints`,`orderIndex`,`active`) VALUES
  ('c-inicial','C Inicial','#7C8793',0,0,1),
  ('c-media','C Média','#74884B',200,1,1),
  ('c-elite','C Elite','#75A843',400,2,1),
  ('b-inicial','B Inicial','#8FCB46',600,3,1),
  ('b-media','B Média','#B1C850',800,4,1),
  ('b-elite','B Elite','#D4B64A',1000,5,1),
  ('a-inicial','A Inicial','#E79A3B',1200,6,1),
  ('a-media','A Média','#E57A45',1400,7,1),
  ('a-elite','A Elite','#D96558',1600,8,1),
  ('s-elite','S Elite','#EDC85D',1800,9,1);
