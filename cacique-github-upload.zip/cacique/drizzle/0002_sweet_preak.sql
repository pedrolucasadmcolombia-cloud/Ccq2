CREATE TABLE `score_adjustments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`playerId` int NOT NULL,
	`delta` int NOT NULL,
	`reason` varchar(300) NOT NULL,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `score_adjustments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `players` ADD `userId` int;--> statement-breakpoint
ALTER TABLE `players` ADD CONSTRAINT `players_user_unique` UNIQUE(`userId`);--> statement-breakpoint
ALTER TABLE `score_adjustments` ADD CONSTRAINT `score_adjustments_playerId_players_id_fk` FOREIGN KEY (`playerId`) REFERENCES `players`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `score_adjustments` ADD CONSTRAINT `score_adjustments_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `score_adjustments_player_idx` ON `score_adjustments` (`playerId`);--> statement-breakpoint
CREATE INDEX `score_adjustments_date_idx` ON `score_adjustments` (`createdAt`);--> statement-breakpoint
ALTER TABLE `players` ADD CONSTRAINT `players_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;