ALTER TABLE `match_participants` ADD `stakeAmount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `match_participants` ADD `seriesIdAtMatch` int;--> statement-breakpoint
ALTER TABLE `match_participants` ADD CONSTRAINT `match_participants_seriesIdAtMatch_series_id_fk` FOREIGN KEY (`seriesIdAtMatch`) REFERENCES `series`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `match_participants_series_snapshot_idx` ON `match_participants` (`seriesIdAtMatch`);