-- Renomeia as dez séries padrão in-place. Os códigos e IDs permanecem estáveis, preservando jogadores e partidas; os limites de pontos e cores atuais também são mantidos.
UPDATE `series` SET `name`='🥉 OURO III', `orderIndex`=9 WHERE `code`='c-inicial' AND `name`='C Inicial';
--> statement-breakpoint
UPDATE `series` SET `name`='🥈 OURO II', `orderIndex`=8 WHERE `code`='c-media' AND `name`='C Média';
--> statement-breakpoint
UPDATE `series` SET `name`='🥇 OURO I', `orderIndex`=7 WHERE `code`='c-elite' AND `name`='C Elite';
--> statement-breakpoint
UPDATE `series` SET `name`='🛡️ PLATINA III', `orderIndex`=6 WHERE `code`='b-inicial' AND `name`='B Inicial';
--> statement-breakpoint
UPDATE `series` SET `name`='🛡️ PLATINA II', `orderIndex`=5 WHERE `code`='b-media' AND `name`='B Média';
--> statement-breakpoint
UPDATE `series` SET `name`='🛡️ PLATINA I', `orderIndex`=4 WHERE `code`='b-elite' AND `name`='B Elite';
--> statement-breakpoint
UPDATE `series` SET `name`='💎 DIAMANTE III', `orderIndex`=3 WHERE `code`='a-inicial' AND `name`='A Inicial';
--> statement-breakpoint
UPDATE `series` SET `name`='💎 DIAMANTE II', `orderIndex`=2 WHERE `code`='a-media' AND `name`='A Média';
--> statement-breakpoint
UPDATE `series` SET `name`='💎 DIAMANTE I', `orderIndex`=1 WHERE `code`='a-elite' AND `name`='A Elite';
--> statement-breakpoint
UPDATE `series` SET `name`='👑 MESTRE', `orderIndex`=0 WHERE `code`='s-elite' AND `name`='S Elite';
