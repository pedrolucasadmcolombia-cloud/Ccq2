# Entregas e critérios — SORTEADO CACIQUE

## 1. Identidade visual e navegação responsiva
- O sistema terá identidade visual premium própria, tema escuro profissional, fundo preto/grafite, detalhes dourado e verde neon, brilhos discretos, cards modernos, animações fluidas, ícones profissionais e tipografia legível.
- A experiência deverá funcionar em Android, iPhone, tablets e computadores, com prioridade para celular; botões terão tamanho adequado ao toque, tabelas serão adaptadas a telas pequenas e formulários serão simples e rápidos.
- A navegação clara terá menus adaptados a celulares e computadores, estados de carregamento, mensagens de sucesso e erro, tratamento de falhas, estados vazios e confirmação antes de excluir.

## 2. Página inicial pública
- A página inicial exibirá o logotipo e nome CACIQUE SORTEADOS, indicador do sistema online, quantidade real de jogadores cadastrados, partidas e confrontos, Top 3 jogadores da semana com pontuações, últimas partidas, destaques, avisos/novidades, atalhos para todas as funcionalidades e links para WhatsApp, TikTok e Instagram.
- Os dados e estatísticas serão atualizados a partir das informações reais persistidas, sem apresentar dados fictícios como reais; qualquer exemplo ficará claramente identificado.

## 3. Cadastro, consulta e perfil de jogadores
- Cada jogador terá nick, ID quando necessário, avatar, série, pontuação, vitórias, derrotas, data de entrada, status da conta e observações administrativas.
- Os administradores poderão adicionar e editar cadastros, pesquisar por nick, filtrar por série, consultar estatísticas e histórico de partidas, ativar/desativar cadastro e identificar nomes duplicados.
- A lista oferecerá cards para celular e tabela detalhada para computador, além de perfil individual com histórico e estatísticas.

## 4. Ranking e estatísticas
- O ranking exibirá posição, nick, avatar, pontuação total, vitórias, derrotas, partidas, taxa de vitória, série atual e histórico de desempenho; o Top 3 terá medalhas de ouro, prata e bronze.
- Haverá filtros por nome, série, pontuação, vitórias, período e classificação geral; listas grandes terão paginação ou carregamento progressivo; haverá classificação geral, semanal e mensal, exportação, gráficos, estatísticas individuais e comparação entre jogadores.
- A classificação será calculada automaticamente pelas regras configuradas; jogadores não poderão alterar pontos. Estatísticas serão calculadas com dados reais armazenados.

## 5. Séries e progressão competitiva
- As dez séries padrão serão exibidas nesta ordem: 👑 MESTRE, 💎 DIAMANTE I, 💎 DIAMANTE II, 💎 DIAMANTE III, 🛡️ PLATINA I, 🛡️ PLATINA II, 🛡️ PLATINA III, 🥇 OURO I, 🥈 OURO II e 🥉 OURO III.
- Administradores poderão cadastrar séries, alterar nomes e cores, definir requisitos e regras de progressão, promover e rebaixar jogadores e consultar histórico de alterações. A atualização manterá IDs, jogadores vinculados e requisitos de pontos atuais; somente nomes e ordem de exibição serão adaptados.

## 6. Pareador inteligente e confrontos
- O sistema aceitará modos 1x1, 2x2, 3x3, 4x4 e modos personalizados; administradores poderão colar listas do WhatsApp, cadastrar jogadores manualmente, importar listas de confrontos, organizar jogadores em equipes, criar confrontos automaticamente, definir vagas e selecionar jogadores por série.
- O pareador identificará jogadores duplicados e nomes não cadastrados, evitará confrontos repetidos, balanceará confrontos conforme série/pontuação e permitirá visualizar a prévia antes de confirmar.
- Ao gerar confrontos, o sistema usará todos os nomes como um roster e sorteará novas equipes; a linha `Jogador1 - Jogador2` não fixa a dupla, a equipe nem o confronto. Em 1x1, os pares informados não serão repetidos como adversários; em 2x2 ou maior, os pares informados não permanecerão juntos na mesma equipe.
- A área de importação interpretará uma linha por par no formato `Jogador1 - Jogador2`, validará os nomes, usará o par como combinação a redistribuir e mostrará a nova prévia antes de salvar. Se não existir combinação válida que desfaça os pares e evite revanche, o sistema orientará a alterar a lista; não confirmará confrontos que preservem os pares de entrada.
- Os botões IMPORTAR LISTA, GERAR CONFRONTOS, EMBARALHAR, VALIDAR JOGADORES, LIMPAR LISTA e CONFIRMAR CONFRONTOS terão comportamento funcional; nenhuma lista será persistida sem prévia/validação e confirmação.

## 7. Partidas, comprovantes e auditoria
- Cada partida terá data e horário, administrador responsável, equipe vencedora e perdedora, lista de participantes, resultado, prints/comprovantes enviados, status da auditoria, pontuação atribuída e histórico de alterações.
- Será possível anexar vários comprovantes por partida e relacionar cada comprovante ao jogador correto.
- Estados: Aguardando comprovantes, Aguardando auditoria, Aprovado, Rejeitado e Em análise. O administrador aprovará ou rejeitará comprovantes informando o motivo.
- Após aprovação, pontos serão calculados conforme regras configuradas. O sistema impedirá registros duplicados, pontuação repetida, alterações não autorizadas e comprovantes associados ao jogador errado; todas as alterações importantes serão registradas.
- A interface permitirá denunciar resultados e consultar histórico completo de confrontos/partidas.

## 8. Sorteios
- O sistema permitirá cadastrar participantes, definir vagas, sortear e distribuir aleatoriamente, visualizar resultados, consultar histórico e refazer o sorteio antes de confirmar.
- O sorteio evitará participantes duplicados, apresentará claramente os critérios, registrará o administrador responsável e oferecerá distribuição por séries quando for necessário equilíbrio competitivo.

## 9. Segurança e painel administrativo
- O painel será protegido por login seguro, perfil de administrador e níveis de acesso Administrador principal, Administrador de partidas, Auditor e Moderador, cada qual com permissões específicas.
- Administradores poderão gerenciar jogadores, partidas, aprovação de comprovantes, pontuação, séries, sorteios, regras, links, configurações e histórico de ações administrativas.
- Somente usuários autorizados executarão ações administrativas. Permissões serão verificadas no servidor e no banco; cada alteração registrará quem a realizou e quando.
- Chaves secretas nunca serão colocadas no frontend; dados serão validados no servidor; jogadores não poderão escrever a própria pontuação ou informação administrativa.

## 10. Dados, persistência e integridade
- O banco relacional gerenciado persistirá dados após atualizar ou fechar o navegador; entidades incluirão usuários, jogadores, séries, partidas, equipes, confrontos, comprovantes, pontuações, sorteios, administradores, auditoria e configurações, com relacionamentos e regras de integridade.
- Cadastros serão salvos no banco; pontuação e ranking refletirão eventos aprovados e regras reais. O usuário confirmou MySQL gerenciado como equivalente relacional ao PostgreSQL mencionado originalmente.
- Imagens e comprovantes serão armazenados de forma durável e indexados/associados corretamente; haverá exportação/backup e recuperação disponíveis sem alegar uma capacidade de restauração que não esteja implementada.

## 11. Links, avisos e regras da comunidade
- Haverá página de comunidade com cards e ícones interativos para grupo principal e secundário do WhatsApp, TikTok oficial, Instagram oficial, regras e suporte.
- Links, avisos e regras serão configuráveis pelo administrador e poderão permanecer sem valor até serem fornecidos.

## 12. Páginas requeridas e conclusão dos fluxos
- Serão organizadas as páginas: inicial, ranking geral, auditoria de partidas, lista de jogadores, perfil individual, pareador inteligente, gerenciador de sorteios, histórico de partidas, estatísticas, links da comunidade, login administrativo, painel administrativo e configurações do sistema.
- O fluxo de cadastro de jogador, criação de confronto, envio de comprovante, auditoria, atribuição de pontos e atualização do ranking deverá estar conectado de ponta a ponta.
- Botões e formulários não serão apenas estáticos: as entradas serão validadas e os registros ficarão disponíveis após recarregar o navegador.

## 13. Login administrativo PH por conta e senha conforme a referência
- A rota `/admin/login` exibirá fundo real da arena desfocado e escurecido, modal central arredondado, botão de fechar, escudo dourado, título “Login Administrativo”, subtítulo de identificação segura, seletor `PH 👑 (Desenvolvedor / ADM)`, campo “SENHA DE ACESSO” e CTA amarelo “Validar Acesso”, responsivo e confortável em celular.
- A senha será validada exclusivamente no servidor por variável protegida `CACIQUE_ADMIN_PASSWORD`; não será gravada no banco, incluída no frontend, exibida em mensagens/logs ou solicitada pelo chat. Conta inexistente, senha incorreta, senha vazia e credencial ausente não concederão acesso; recomenda-se uma senha longa e exclusiva.
- Tentativas de login terão limite temporário por IP; a sessão terá assinatura e validade de oito horas, será enviada em cookie HttpOnly, Secure, SameSite=None e utilizará proteção CSRF nas mutações autenticadas.
- O login local PH receberá o papel de administrador principal após validação. Manus OAuth continuará disponível para as contas de jogadores e demais membros da equipe; permissões de cada papel continuarão verificadas no servidor.
- Fechar o modal retornará à página inicial; login correto abrirá o painel e erros serão apresentados sem revelar se a conta ou senha estava errada.

## 14. [x] Pareamento em duas etapas conforme a referência do Drive
- A página Pareador apresentará seis vagas como padrão 3x3 e permitirá formatos 1x1, 2x2, 3x3, 4x4 e personalizado de 1 a 6 jogadores por equipe. “Preencher Vagas” aceitará texto colado do WhatsApp e resolverá nicks cadastrados, séries e valores explicitamente indicados em reais; cada vaga terá nick, série usada somente no confronto e aposta individual editáveis. Duplicatas — inclusive repetidas na mesma linha — não poderão ser confirmadas. Toda linha/fragmento sem jogador reconhecido deverá ser corrigida em uma vaga ou explicitamente declarada como texto que não é participante; listas acima de 12 participantes bloquearão a geração até serem ajustadas, sem omissão silenciosa.
- Na Etapa 1, “Gerar Pareamento (Duelos 1v1)” formará duelos equilibrados com base nos dados reais de série e pontuação, sem repetir adversários anteriores. “Alterar Pareamento” criará uma nova prévia sem repetir os duelos que acabou de exibir. Cada cartão exibirá ambos os jogadores, série, aposta e um indicador de equilíbrio compreensível.
- Na Etapa 2, “Realizar Sorteio dos Times (50/50)” sorteará no servidor, separadamente por duelo, qual jogador será atribuído ao Time Azul/Lado A e qual ao Time Vermelho/Lado B; cada duelo contribuirá exatamente um integrante a cada time, preservando equipes de mesmo tamanho.
- A escalação e o progresso do pareamento poderão ser salvos como rascunho neste dispositivo durante o preenchimento, revisão de duelos e sorteio final. A escalação final exibirá cada nick, série e aposta, oferecerá “Copiar pro WhatsApp” e “Baixar Banner (Stories)” em formato vertical 9:16. Uma partida agendada só será persistida após confirmação explícita; o registro armazenará o formato, os times, a aposta individual e a série no momento do confronto sem alterar o perfil do jogador.
- Após a partida, a tela oferecerá registrar a vitória Azul ou Vermelha e seguirá para envio dos comprovantes individuais no fluxo existente. Pontos só serão atribuídos após auditoria aprovada; todas as permissões e gravações serão verificadas no servidor e registradas no log administrativo.
- O material de referência cita vantagem “EMU/K3”, mas não informa os critérios para calculá-la. Não será aplicada uma fórmula inventada: a interface apresentará apenas diferenças/indicadores verificáveis de série e pontuação até que o administrador defina a regra especial.

## 15. [x] Três roletas independentes de nomes no Pareador
- A página Pareador exibirá exatamente três roletas circulares independentes, identificadas como Roleta 1, Roleta 2 e Roleta 3; cada uma terá sua própria área editável para inserir ou colar nomes, aceitando um nome por linha ou itens separados por vírgula.
- Cada roleta aceitará de 2 a 48 nomes válidos, com nomes não vazios de até 80 caracteres e sem duplicatas normalizadas. O botão Girar ficará desativado enquanto a lista for inválida; com até 14 opções, os segmentos exibirão nomes abreviados; acima disso, exibirão o número correspondente à ordem da lista para manter a leitura, com os nomes completos ainda visíveis na área editável e no resultado. O indicador fixo mostrará visualmente onde o giro terminou.
- Ao girar, o servidor escolherá uniformemente um índice com aleatoriedade criptográfica e retornará apenas o nome/índice selecionado; a interface animará a roda até essa opção e, ao concluir, abrirá uma janela modal “Resultado:” sobre o fundo escurecido/desfocado, com confetes e o nome sorteado em destaque. A modal oferecerá “Usar no pareador” para preencher a próxima vaga ativa vazia, “Remover” para retirar o sorteado da lista da roleta e “Fechar” para fechar sem removê-lo. O nick escolhido continuará sujeito à validação normal do cadastro antes da geração de duelos.
- As listas das três roletas serão preservadas junto com o rascunho local do Pareador; o resultado de uma roleta não criará partida nem escreverá dados de jogador. Em desktop, as três rodas aparecerão lado a lado; em celular, empilhadas, com contraste legível e respeito à preferência de movimento reduzido.
- Acima das três rodas haverá a opção “Girar as 3 roletas”. Ela exigirá que cada lista seja válida, enviará as três listas juntas ao servidor para um sorteio uniforme independente, animará as três rodas e, somente após as três pararem, abrirá uma única modal com os três nomes identificados pela roleta correspondente. Nenhuma modal individual poderá sobrepor o resultado conjunto, e uma lista inválida impedirá o giro parcial.

## 16. Edição e exclusão seguras de jogadores e partidas
- Administradores autorizados poderão editar jogadores e excluir um cadastro com confirmação. A exclusão permanente de jogador só será aceita quando não houver partidas, comprovantes, eventos/ajustes de pontuação, vitórias ou derrotas vinculados; caso exista histórico, o servidor recusará a exclusão e orientará a inativar o jogador para preservar os registros. A exclusão será transacional e registrará no log o resumo do cadastro removido e o administrador responsável.
- Administradores autorizados poderão editar uma partida agendada sem provas ou pontuação: título, modo, horário e distribuição dos participantes entre as equipes. Cada participante existente deverá continuar em apenas uma equipe; ambas as equipes permanecerão com pelo menos um jogador ativo; a alteração será validada e registrada numa transação. O resultado continuará pelo fluxo de envio e auditoria existente; partidas com provas, revisão ou pontuação não poderão ser reescritas.
- Partidas não aprovadas poderão ser excluídas com confirmação somente se não houver comprovantes nem eventos de pontuação. A transação guardará antes um resumo da partida e participantes no log administrativo; o banco removerá o registro e dependências de escalação com integridade referencial. Partidas aprovadas/pontuadas ou com provas serão protegidas contra exclusão.
- Os botões Editar/Excluir aparecerão somente para papéis autorizados; a interface informará claramente quando o estado ou histórico impedir uma ação. As verificações de autorização e integridade serão obrigatórias no servidor, sem depender dos controles do cliente.
