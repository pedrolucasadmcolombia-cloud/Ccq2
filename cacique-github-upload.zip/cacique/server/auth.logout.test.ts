import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import { ADMIN_CSRF_COOKIE, COOKIE_NAME } from "../shared/const";
import { ADMIN_SESSION_COOKIE } from "./_core/adminPassword";
import type { TrpcContext } from "./_core/context";

type CookieCall = {
  name: string;
  options: Record<string, unknown>;
};

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext; clearedCookies: CookieCall[] } {
  const clearedCookies: CookieCall[] = [];

  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    adminPasswordSession: false,
    adminCsrfToken: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
    } as TrpcContext["res"],
  };

  return { ctx, clearedCookies };
}

describe("auth.logout", () => {
  it("clears the OAuth and local admin cookies and reports success", async () => {
    const { ctx, clearedCookies } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.logout();

    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(3);
    expect(clearedCookies.map((cookie) => cookie.name)).toEqual([
      COOKIE_NAME,
      ADMIN_SESSION_COOKIE,
      ADMIN_CSRF_COOKIE,
    ]);
    expect(clearedCookies[0]?.options).toMatchObject({
      maxAge: -1,
      secure: true,
      sameSite: "none",
      httpOnly: true,
      path: "/",
    });
    expect(clearedCookies[1]?.options).toMatchObject({
      maxAge: 0,
      secure: true,
      sameSite: "none",
      httpOnly: true,
      path: "/",
    });
    expect(clearedCookies[2]?.options).toMatchObject({
      maxAge: 0,
      secure: true,
      sameSite: "none",
      httpOnly: false,
      path: "/",
    });
  });
});
