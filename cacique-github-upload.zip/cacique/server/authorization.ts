import { eq } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { adminRoles, type User } from "../drizzle/schema";
import { getDb } from "./db";

export type CommunityRole = "owner" | "match_admin" | "auditor" | "moderator" | "member";

export async function getCommunityRole(user: User | null): Promise<CommunityRole> {
  if (!user) return "member";
  if (user.role === "admin" && user.loginMethod === "local-password") return "owner";
  const db = await getDb();
  if (!db) return "member";
  const rows = await db.select({ role: adminRoles.role }).from(adminRoles).where(eq(adminRoles.userId, user.id)).limit(1);
  return rows[0]?.role ?? "member";
}

export async function assertRole(user: User | null, allowed: CommunityRole[]) {
  if (!user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Faça login para continuar." });
  const role = await getCommunityRole(user);
  if (!allowed.includes(role)) throw new TRPCError({ code: "FORBIDDEN", message: "Seu perfil não tem permissão para esta ação." });
  return role;
}
