import { and, count, desc, eq, gte, inArray, like, or, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { adminRoles, announcements, auditLog, communitySettings, draws, matchParticipants, matches, players, proofs, scoreAdjustments, scoreEvents, series, users } from "../drizzle/schema";
import { assertRole, getCommunityRole } from "./authorization";
import { getDb, getUserByOpenId, upsertUser } from "./db";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { storeImage } from "./services/storage";
import { createBackupSnapshot, restoreBackupSnapshot } from "./services/backup";
import { drawDuelSides, generateBalancedPairings, pairingKey, pickRandomWheelOption, pickRandomWheelOptions, secureShuffle } from "./services/pairing";
import { resolveWhatsAppRoster } from "./services/whatsappRoster";
import { ADMIN_DISPLAY_NAME, LOCAL_ADMIN_OPEN_ID, clearAdminLoginFailures, clearAdminSessionCookies, createAdminSession, hasAdminPasswordConfigured, isAdminLoginRateLimited, recordAdminLoginFailure, setAdminSessionCookies, verifyAdminPassword } from "./_core/adminPassword";

const owner = ["owner"] as const;
const managers = ["owner", "match_admin"] as const;
const auditors = ["owner", "auditor"] as const;
const moderators = ["owner", "moderator"] as const;
const allStaff = ["owner", "match_admin", "auditor", "moderator"] as const;
const playedMatchStatuses = ["awaiting_proofs", "under_review", "approved", "rejected"] as const;
const roleProcedure = (roles: readonly ("owner" | "match_admin" | "auditor" | "moderator")[]) =>
  protectedProcedure.use(async ({ ctx, next }) => {
    await assertRole(ctx.user, [...roles]);
    return next({ ctx: { ...ctx, user: ctx.user } });
  });
const managerProcedure = roleProcedure(managers);
const auditorProcedure = roleProcedure(auditors);
const moderatorProcedure = roleProcedure(moderators);
const anyStaffProcedure = roleProcedure(allStaff);

async function database() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Banco de dados indisponível." });
  return db;
}
async function writeAudit(actorUserId: number, action: string, entityType: string, entityId: number | null, details: unknown) {
  const db = await database();
  await db.insert(auditLog).values({ actorUserId, action, entityType, entityId, details: JSON.stringify(details) });
}
const normalized = (s: string) => s.normalize("NFKC").trim().toLocaleLowerCase("pt-BR");
const avatarUrlSchema = z.string().trim().max(512).refine(value => {
  if (!value) return true;
  if (value.startsWith("/manus-storage/")) return !value.split("/").includes("..");
  try { return new URL(value).protocol === "https:"; } catch { return false; }
}, "O avatar precisa ser um URL HTTPS ou um caminho do armazenamento do projeto.");
const dbError = (error: unknown): never => {
  if (error instanceof TRPCError) throw error;
  if (error && typeof error === "object" && "code" in error && error.code === "ER_DUP_ENTRY") {
    throw new TRPCError({ code: "CONFLICT", message: "Este registro já existe; confira nomes ou participantes duplicados." });
  }
  throw error;
};
function hasPreviousCrossedPair(teamA:readonly number[],teamB:readonly number[],rows:readonly {matchId:number;playerId:number;team:"A"|"B"}[]) {
  const games=new Map<number,{A:number[];B:number[]}>();
  for(const row of rows){const game=games.get(row.matchId)??{A:[],B:[]};game[row.team].push(row.playerId);games.set(row.matchId,game);}
  for(const game of games.values())for(const a of game.A)for(const b of game.B){if((teamA.includes(a)&&teamB.includes(b))||(teamA.includes(b)&&teamB.includes(a)))return true;}
  return false;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    role: protectedProcedure.query(async ({ ctx }) => getCommunityRole(ctx.user)),
    passwordSession: publicProcedure.query(({ ctx }) => ctx.adminPasswordSession),
    passwordLogin: publicProcedure.input(z.object({ account: z.literal("ph"), password: z.string().min(1).max(256) })).mutation(async ({ ctx, input }) => {
      if (!hasAdminPasswordConfigured()) throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "A credencial administrativa não está configurada." });
      if (isAdminLoginRateLimited(ctx.req)) throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Muitas tentativas. Aguarde 15 minutos antes de tentar novamente." });
      const passwordMatches = verifyAdminPassword(input.password);
      if (input.account !== "ph" || !passwordMatches) {
        recordAdminLoginFailure(ctx.req);
        throw new TRPCError({ code: "UNAUTHORIZED", message: "Conta ou senha inválida." });
      }
      await upsertUser({ openId: LOCAL_ADMIN_OPEN_ID, name: ADMIN_DISPLAY_NAME, loginMethod: "local-password", role: "admin", lastSignedIn: new Date() });
      const user = await getUserByOpenId(LOCAL_ADMIN_OPEN_ID);
      if (!user || user.role !== "admin" || user.loginMethod !== "local-password") throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível iniciar a sessão administrativa." });
      clearAdminLoginFailures(ctx.req);
      setAdminSessionCookies(ctx.req, ctx.res, createAdminSession());
      return { success: true } as const;
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      clearAdminSessionCookies(ctx.req, ctx.res);
      return { success: true } as const;
    }),
  }),
  dashboard: router({
    overview: publicProcedure.query(async () => {
      const db = await database();
      const [playerCount, matchCount, confrontationCount, top, recent, notice] = await Promise.all([
        db.select({ value: count() }).from(players).where(eq(players.status, "active")),
        db.select({ value: count() }).from(matches),
        db.select({ value: count() }).from(matches).where(sql`${matches.status} <> 'scheduled'`),
        db.select({ id: players.id, nickname: players.nickname, points: players.points, wins: players.wins, avatarUrl: players.avatarUrl, seriesName: series.name, seriesColor: series.color }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(eq(players.status, "active")).orderBy(desc(players.points), desc(players.wins)).limit(3),
        db.select({ id: matches.id, title: matches.title, mode: matches.mode, status: matches.status, playedAt: matches.playedAt, resultText: matches.resultText }).from(matches).orderBy(desc(matches.playedAt)).limit(5),
        db.select({ id: announcements.id, title: announcements.title, body: announcements.body, createdAt: announcements.createdAt }).from(announcements).where(eq(announcements.active, 1)).orderBy(desc(announcements.createdAt)).limit(3),
      ]);
      return { players: playerCount[0]?.value ?? 0, matches: matchCount[0]?.value ?? 0, confrontations: confrontationCount[0]?.value ?? 0, top, recent, announcements: notice };
    }),
  }),
  players: router({
    list: publicProcedure.input(z.object({ query: z.string().trim().max(60).optional(), seriesId: z.number().int().positive().optional(), minPoints:z.number().int().min(0).optional(), minWins:z.number().int().min(0).optional(), includeInactive: z.boolean().optional(), period: z.enum(["all", "week", "month"]).default("all"), sort: z.enum(["points", "wins", "name"]).default("points"), limit: z.number().int().min(1).max(100).default(50), offset: z.number().int().min(0).default(0) }).optional()).query(async ({ ctx, input }) => {
      const db = await database();
      const role = await getCommunityRole(ctx.user);
      const filters = [];
      if (!input?.includeInactive || role === "member") filters.push(eq(players.status, "active"));
      if (input?.seriesId) filters.push(eq(players.seriesId, input.seriesId));
      if (input?.query) filters.push(or(like(players.nickname, `%${input.query}%`), like(players.gameId, `%${input.query}%`))!);
      if ((input?.period ?? "all") === "all" && input?.minPoints !== undefined) filters.push(gte(players.points, input.minPoints));
      if ((input?.period ?? "all") === "all" && input?.minWins !== undefined) filters.push(gte(players.wins, input.minWins));
      const where = filters.length ? and(...filters) : undefined;
      const limit = input?.limit ?? 50;
      const offset = input?.offset ?? 0;
      const selectPlayers = () => db.select({ id: players.id, nickname: players.nickname, gameId: players.gameId, avatarUrl: players.avatarUrl, seriesId: players.seriesId, seriesName: series.name, seriesColor: series.color, points: players.points, wins: players.wins, losses: players.losses, status: players.status, notes: players.notes, accountUserId: players.userId, joinedAt: players.joinedAt }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(where);
      if ((input?.period ?? "all") === "all") {
        const order = input?.sort === "wins" ? [desc(players.wins), desc(players.points), players.nickname] : input?.sort === "name" ? [players.nickname] : [desc(players.points), desc(players.wins), players.nickname];
        const [rows, totals] = await Promise.all([
          selectPlayers().orderBy(...order).limit(limit).offset(offset),
          db.select({ value: count() }).from(players).where(where),
        ]);
        return { rows: role === "member" ? rows.map(player => ({ ...player, notes: null, accountUserId: null })) : rows, total: totals[0]?.value ?? 0 };
      }
      const baseRows = await selectPlayers();
      const period = input?.period ?? "week";
      const dateFilter = period === "week"
        ? sql`${matches.playedAt} >= date_sub(current_timestamp(), interval 7 day)`
        : sql`date_format(${matches.playedAt}, '%Y-%m') = date_format(current_timestamp(), '%Y-%m')`;
      const stats = await db.select({
        playerId: matchParticipants.playerId,
        points: sql<number>`coalesce(sum(${scoreEvents.points}), 0)`,
        wins: sql<number>`coalesce(sum(case when ${matches.winnerTeam} = ${matchParticipants.team} then 1 else 0 end), 0)`,
        losses: sql<number>`coalesce(sum(case when ${matches.winnerTeam} <> ${matchParticipants.team} then 1 else 0 end), 0)`,
      }).from(matchParticipants)
        .innerJoin(matches, eq(matchParticipants.matchId, matches.id))
        .innerJoin(scoreEvents, and(eq(scoreEvents.matchId, matches.id), eq(scoreEvents.playerId, matchParticipants.playerId)))
        .where(and(eq(matches.status, "approved"), dateFilter))
        .groupBy(matchParticipants.playerId);
      const adjustmentDateFilter=period==="week"?sql`${scoreAdjustments.createdAt} >= date_sub(current_timestamp(), interval 7 day)`:sql`date_format(${scoreAdjustments.createdAt}, '%Y-%m') = date_format(current_timestamp(), '%Y-%m')`;
      const adjustments=await db.select({playerId:scoreAdjustments.playerId,points:sql<number>`coalesce(sum(${scoreAdjustments.delta}),0)`}).from(scoreAdjustments).where(adjustmentDateFilter).groupBy(scoreAdjustments.playerId);
      const byPlayer = new Map(stats.map(item => [item.playerId, item]));
      const adjustmentByPlayer=new Map(adjustments.map(item=>[item.playerId,Number(item.points??0)]));
      const rows = baseRows.map(player => {
        const activity = byPlayer.get(player.id);
        return { ...player, points: Number(activity?.points ?? 0)+Number(adjustmentByPlayer.get(player.id)??0), wins: Number(activity?.wins ?? 0), losses: Number(activity?.losses ?? 0) };
      }).filter(player => (input?.minPoints === undefined || player.points >= input.minPoints) && (input?.minWins === undefined || player.wins >= input.minWins)).sort((a, b) => input?.sort === "wins" ? b.wins - a.wins || b.points - a.points : input?.sort === "name" ? a.nickname.localeCompare(b.nickname) : b.points - a.points || b.wins - a.wins || a.nickname.localeCompare(b.nickname));
      const visibleRows = rows.slice(offset, offset + limit).map(player => role === "member" ? { ...player, notes: null, accountUserId: null } : player);
      return { rows: visibleRows, total: rows.length };
    }),
    export: publicProcedure.input(z.object({ query: z.string().trim().max(60).optional(), seriesId: z.number().int().positive().optional(), minPoints:z.number().int().min(0).optional(), minWins:z.number().int().min(0).optional(), period:z.enum(["all","week","month"]).default("all"), sort:z.enum(["points","wins","name"]).default("points") }).optional()).query(async ({ input }) => {
      const db = await database();
      const filters = [eq(players.status, "active")];
      if (input?.seriesId) filters.push(eq(players.seriesId, input.seriesId));
      if (input?.query) filters.push(or(like(players.nickname, `%${input.query}%`), like(players.gameId, `%${input.query}%`))!);
      if ((input?.period ?? "all") === "all" && input?.minPoints !== undefined) filters.push(gte(players.points, input.minPoints));
      if ((input?.period ?? "all") === "all" && input?.minWins !== undefined) filters.push(gte(players.wins, input.minWins));
      const order = input?.sort === "wins" ? [desc(players.wins), desc(players.points), players.nickname] : input?.sort === "name" ? [players.nickname] : [desc(players.points), desc(players.wins), players.nickname];
      const selectPlayers = () => db.select({ id:players.id,nickname: players.nickname, gameId: players.gameId, seriesName: series.name, points: players.points, wins: players.wins, losses: players.losses }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(and(...filters));
      if ((input?.period ?? "all") === "all") return selectPlayers().orderBy(...order).limit(5000);
      const baseRows = await selectPlayers();
      const dateFilter = input?.period === "week" ? sql`${matches.playedAt} >= date_sub(current_timestamp(), interval 7 day)` : sql`date_format(${matches.playedAt}, '%Y-%m') = date_format(current_timestamp(), '%Y-%m')`;
      const stats = await db.select({ playerId:matchParticipants.playerId, points:sql<number>`coalesce(sum(${scoreEvents.points}),0)`, wins:sql<number>`coalesce(sum(case when ${matches.winnerTeam}=${matchParticipants.team} then 1 else 0 end),0)`, losses:sql<number>`coalesce(sum(case when ${matches.winnerTeam}<>${matchParticipants.team} then 1 else 0 end),0)` }).from(matchParticipants).innerJoin(matches,eq(matchParticipants.matchId,matches.id)).innerJoin(players,eq(matchParticipants.playerId,players.id)).innerJoin(scoreEvents,and(eq(scoreEvents.matchId,matches.id),eq(scoreEvents.playerId,matchParticipants.playerId))).where(and(eq(matches.status,"approved"),dateFilter)).groupBy(matchParticipants.playerId);
      const adjustmentDateFilter=input?.period==="week"?sql`${scoreAdjustments.createdAt} >= date_sub(current_timestamp(), interval 7 day)`:sql`date_format(${scoreAdjustments.createdAt}, '%Y-%m') = date_format(current_timestamp(), '%Y-%m')`;
      const adjustments=await db.select({playerId:scoreAdjustments.playerId,points:sql<number>`coalesce(sum(${scoreAdjustments.delta}),0)`}).from(scoreAdjustments).where(adjustmentDateFilter).groupBy(scoreAdjustments.playerId);
      const byPlayer=new Map(stats.map(item=>[item.playerId,item]));const adjustmentByPlayer=new Map(adjustments.map(item=>[item.playerId,Number(item.points??0)]));
      return baseRows.map(player=>{const periodStats=byPlayer.get(player.id);return {...player,points:Number(periodStats?.points??0)+Number(adjustmentByPlayer.get(player.id)??0),wins:Number(periodStats?.wins??0),losses:Number(periodStats?.losses??0)};}).filter(player=>(input?.minPoints===undefined||player.points>=input.minPoints)&&(input?.minWins===undefined||player.wins>=input.minWins)).sort((a,b)=>input?.sort==="wins"?b.wins-a.wins||b.points-a.points:input?.sort==="name"?a.nickname.localeCompare(b.nickname):b.points-a.points||b.wins-a.wins||a.nickname.localeCompare(b.nickname)).slice(0,5000);
    }),
    get: publicProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => {
      const db = await database();
      const [player] = await db.select({ id: players.id, nickname: players.nickname, gameId: players.gameId, avatarUrl: players.avatarUrl, seriesId: players.seriesId, seriesName: series.name, seriesColor: series.color, points: players.points, wins: players.wins, losses: players.losses, status: players.status, joinedAt: players.joinedAt }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(eq(players.id, input.id)).limit(1);
      if (!player || player.status === "inactive") throw new TRPCError({ code: "NOT_FOUND", message: "Jogador não encontrado." });
      const history = await db.select({ matchId: matches.id, mode: matches.mode, status: matches.status, winnerTeam: matches.winnerTeam, resultText: matches.resultText, playedAt: matches.playedAt, team: matchParticipants.team, points: matchParticipants.pointsAwarded }).from(matchParticipants).innerJoin(matches, eq(matchParticipants.matchId, matches.id)).where(eq(matchParticipants.playerId, input.id)).orderBy(desc(matches.playedAt)).limit(30);
      return { ...player, history, winRate: player.wins + player.losses ? Math.round((player.wins / (player.wins + player.losses)) * 100) : 0 };
    }),
    assignableAccounts: managerProcedure.query(async()=>{
      const db=await database();
      const rows=await db.select({id:users.id,name:users.name,email:users.email,staffRole:adminRoles.role,linkedPlayerId:players.id}).from(users).leftJoin(adminRoles,eq(adminRoles.userId,users.id)).leftJoin(players,eq(players.userId,users.id)).where(eq(users.role,"user")).limit(500);
      return rows.filter(row=>row.staffRole===null).map(({staffRole,...row})=>row);
    }),
    create: managerProcedure.input(z.object({ nickname: z.string().trim().min(2).max(40), gameId: z.string().trim().max(40).optional(), avatarUrl: avatarUrlSchema.optional(), seriesId: z.number().int().positive().optional(), userId:z.number().int().positive().nullable().optional(), notes: z.string().max(1500).optional() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      try {
        return await db.transaction(async tx=>{
          if(input.userId){const [account]=await tx.select({id:users.id,role:users.role,staffRole:adminRoles.role}).from(users).leftJoin(adminRoles,eq(adminRoles.userId,users.id)).where(eq(users.id,input.userId)).limit(1);if(!account||account.role!=="user"||account.staffRole)throw new TRPCError({code:"BAD_REQUEST",message:"Selecione uma conta de membro sem papel administrativo."});const [linked]=await tx.select({id:players.id}).from(players).where(eq(players.userId,input.userId)).limit(1);if(linked)throw new TRPCError({code:"CONFLICT",message:"Esta conta já está vinculada a outro jogador."});}
          const result=await tx.insert(players).values({nickname:input.nickname,normalizedNickname:normalized(input.nickname),gameId:input.gameId||null,avatarUrl:input.avatarUrl||null,seriesId:input.seriesId??null,userId:input.userId??null,notes:input.notes||null});
          const id=Number(result[0].insertId);await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"player.created",entityType:"player",entityId:id,details:JSON.stringify({nickname:input.nickname,userId:input.userId??null})});return {id};
        });
      } catch (error) { return dbError(error); }
    }),
    update: managerProcedure.input(z.object({ id: z.number().int().positive(), nickname: z.string().trim().min(2).max(40), gameId: z.string().trim().max(40).optional(), avatarUrl: avatarUrlSchema.optional(), seriesId: z.number().int().positive().nullable(), userId:z.number().int().positive().nullable().optional(), notes: z.string().max(1500).optional(), status: z.enum(["active", "inactive"]) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx=>{
        const [current]=await tx.select({userId:players.userId}).from(players).where(eq(players.id,input.id)).limit(1);if(!current)throw new TRPCError({code:"NOT_FOUND",message:"Jogador não encontrado."});
        const targetUserId=input.userId===undefined?current.userId:input.userId;
        if(targetUserId){const [account]=await tx.select({id:users.id,role:users.role,staffRole:adminRoles.role}).from(users).leftJoin(adminRoles,eq(adminRoles.userId,users.id)).where(eq(users.id,targetUserId)).limit(1);if(!account||account.role!=="user"||account.staffRole)throw new TRPCError({code:"BAD_REQUEST",message:"Selecione uma conta de membro sem papel administrativo."});const [linked]=await tx.select({id:players.id}).from(players).where(eq(players.userId,targetUserId)).limit(1);if(linked&&linked.id!==input.id)throw new TRPCError({code:"CONFLICT",message:"Esta conta já está vinculada a outro jogador."});}
        await tx.update(players).set({nickname:input.nickname,normalizedNickname:normalized(input.nickname),gameId:input.gameId||null,avatarUrl:input.avatarUrl||null,seriesId:input.seriesId,userId:targetUserId,notes:input.notes||null,status:input.status}).where(eq(players.id,input.id));
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"player.updated",entityType:"player",entityId:input.id,details:JSON.stringify({nickname:input.nickname,status:input.status,seriesId:input.seriesId,userId:targetUserId})});
      });
      return { success: true };
    }),
    delete: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      try {
        await db.transaction(async tx => {
          const [player] = await tx.select({ id: players.id, nickname: players.nickname, gameId: players.gameId, seriesId: players.seriesId, userId: players.userId, status: players.status, points: players.points, wins: players.wins, losses: players.losses }).from(players).where(eq(players.id, input.id)).limit(1);
          if (!player) throw new TRPCError({ code: "NOT_FOUND", message: "Jogador não encontrado." });
          const [participation] = await tx.select({ id: matchParticipants.id }).from(matchParticipants).where(eq(matchParticipants.playerId, input.id)).limit(1);
          const [proof] = await tx.select({ id: proofs.id }).from(proofs).where(eq(proofs.playerId, input.id)).limit(1);
          const [event] = await tx.select({ id: scoreEvents.id }).from(scoreEvents).where(eq(scoreEvents.playerId, input.id)).limit(1);
          const [adjustment] = await tx.select({ id: scoreAdjustments.id }).from(scoreAdjustments).where(eq(scoreAdjustments.playerId, input.id)).limit(1);
          if (participation || proof || event || adjustment || player.points !== 0 || player.wins !== 0 || player.losses !== 0) {
            throw new TRPCError({ code: "CONFLICT", message: "Este jogador possui histórico de partidas ou pontuação. Inative-o em Editar para preservar os registros." });
          }
          await tx.insert(auditLog).values({ actorUserId: ctx.user.id, action: "player.deleted", entityType: "player", entityId: input.id, details: JSON.stringify({ nickname: player.nickname, gameId: player.gameId, seriesId: player.seriesId, userId: player.userId, status: player.status }) });
          await tx.delete(players).where(eq(players.id, input.id));
        });
        return { success: true };
      } catch (error) { return dbError(error); }
    }),
    adjustPoints: roleProcedure(owner).input(z.object({ playerId: z.number().int().positive(), delta: z.number().int().min(-10000).max(10000), reason: z.string().trim().min(5).max(300) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx => {
        const [p] = await tx.select({ points: players.points }).from(players).where(eq(players.id, input.playerId)).limit(1);
        if (!p || p.points + input.delta < 0) throw new TRPCError({ code: "BAD_REQUEST", message: "A alteração deixaria a pontuação abaixo de zero." });
        await tx.update(players).set({ points: sql`${players.points} + ${input.delta}` }).where(eq(players.id, input.playerId));
        await tx.insert(scoreAdjustments).values({playerId:input.playerId,delta:input.delta,reason:input.reason,createdBy:ctx.user.id});
        const [updated] = await tx.select({ points: players.points, seriesId: players.seriesId }).from(players).where(eq(players.id, input.playerId)).limit(1);
        const thresholds = await tx.select({ id: series.id, minPoints: series.minPoints }).from(series).where(eq(series.active, 1)).orderBy(desc(series.minPoints));
        const reached = thresholds.find(item => updated && updated.points >= item.minPoints);
        if (reached && updated?.seriesId !== reached.id) {
          await tx.update(players).set({ seriesId: reached.id }).where(eq(players.id, input.playerId));
          await tx.insert(auditLog).values({ actorUserId: ctx.user.id, action: "player.series_auto_changed", entityType: "player", entityId: input.playerId, details: JSON.stringify({ seriesId: reached.id, points: updated.points }) });
        }
        await tx.insert(auditLog).values({ actorUserId: ctx.user.id, action: "score.adjusted", entityType: "player", entityId: input.playerId, details: JSON.stringify({ delta: input.delta, reason: input.reason }) });
      });
      return { success: true };
    }),
  }),
  series: router({
    list: publicProcedure.query(async () => {
      const db = await database();
      return db.select().from(series).where(eq(series.active, 1)).orderBy(series.orderIndex, series.minPoints);
    }),
    save: managerProcedure.input(z.object({ id: z.number().int().positive().optional(), code: z.string().trim().min(1).max(32), name: z.string().trim().min(2).max(64), color: z.string().regex(/^#[0-9a-fA-F]{6}$/), minPoints: z.number().int().min(0), orderIndex: z.number().int().min(0), active: z.boolean().default(true) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx=>{
        let id=input.id??null;
        if(input.id)await tx.update(series).set({code:input.code,name:input.name,color:input.color,minPoints:input.minPoints,orderIndex:input.orderIndex,active:input.active?1:0}).where(eq(series.id,input.id));
        else{const inserted=await tx.insert(series).values({code:input.code,name:input.name,color:input.color,minPoints:input.minPoints,orderIndex:input.orderIndex,active:input.active?1:0});id=Number(inserted[0].insertId);}
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:input.id?"series.updated":"series.created",entityType:"series",entityId:id,details:JSON.stringify({name:input.name,minPoints:input.minPoints})});
      });
      return { success: true };
    }),
    assign: managerProcedure.input(z.object({ playerId: z.number().int().positive(), seriesId: z.number().int().positive(), reason: z.string().trim().max(300).optional() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx=>{
        const [person]=await tx.select({id:players.id}).from(players).where(eq(players.id,input.playerId)).limit(1);
        const [target]=await tx.select({id:series.id}).from(series).where(and(eq(series.id,input.seriesId),eq(series.active,1))).limit(1);
        if(!person||!target)throw new TRPCError({code:"NOT_FOUND",message:"Jogador ou série ativa não encontrada."});
        await tx.update(players).set({seriesId:input.seriesId}).where(eq(players.id,input.playerId));
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"player.series_changed",entityType:"player",entityId:input.playerId,details:JSON.stringify({seriesId:input.seriesId,reason:input.reason??"Alteração administrativa"})});
      });
      return { success: true };
    }),
  }),
  matches: router({
    list: publicProcedure.input(z.object({ status: z.enum(["scheduled", "awaiting_proofs", "under_review", "approved", "rejected"]).optional(), limit: z.number().int().min(1).max(100).default(50) }).optional()).query(async ({ input }) => {
      const db = await database();
      const rows = await db.select({ id: matches.id, mode: matches.mode, title: matches.title, status: matches.status, winnerTeam: matches.winnerTeam, resultText: matches.resultText, playedAt: matches.playedAt, createdBy: matches.createdBy, auditedBy: matches.auditedBy }).from(matches).where(input?.status ? eq(matches.status, input.status) : undefined).orderBy(desc(matches.playedAt)).limit(input?.limit ?? 50);
      const ids = rows.map(row => row.id);
      if (!ids.length) return [];
      const [proofRows, scoreRows] = await Promise.all([
        db.select({ matchId: proofs.matchId }).from(proofs).where(inArray(proofs.matchId, ids)),
        db.select({ matchId: scoreEvents.matchId }).from(scoreEvents).where(inArray(scoreEvents.matchId, ids)),
      ]);
      const matchesWithProofs = new Set(proofRows.map(row => row.matchId));
      const matchesWithScores = new Set(scoreRows.map(row => row.matchId));
      const actorIds = [...new Set(rows.flatMap(row => [row.createdBy, row.auditedBy].filter((id): id is number => id !== null)))];
      const actors = actorIds.length ? await db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, actorIds)) : [];
      const actorNames = new Map(actors.map(actor => [actor.id, actor.name]));
      const participantRows = await db.select({ id: matchParticipants.id, matchId: matchParticipants.matchId, playerId: players.id, nickname: players.nickname, avatarUrl: players.avatarUrl, status: players.status, team: matchParticipants.team, pointsAwarded: matchParticipants.pointsAwarded, stakeAmount: matchParticipants.stakeAmount, seriesIdAtMatch: matchParticipants.seriesIdAtMatch, seriesNameAtMatch: matchParticipants.seriesNameAtMatch }).from(matchParticipants).innerJoin(players, eq(matchParticipants.playerId, players.id)).where(inArray(matchParticipants.matchId, ids));
      const participantSeriesIds = [...new Set(participantRows.map(person => person.seriesIdAtMatch).filter((id): id is number => id !== null))];
      const participantSeries = participantSeriesIds.length ? await db.select({ id: series.id, name: series.name, color: series.color }).from(series).where(inArray(series.id, participantSeriesIds)) : [];
      const seriesById = new Map(participantSeries.map(item => [item.id, item]));
      const participants = participantRows.map(person => {
        const seriesId = person.seriesIdAtMatch;
        const seriesInfo = seriesId === null ? undefined : seriesById.get(seriesId);
        return { ...person, seriesId, seriesName: person.seriesNameAtMatch ?? seriesInfo?.name ?? null, seriesColor: seriesInfo?.color ?? null };
      });
      return rows.map(row => ({ id: row.id, mode: row.mode, title: row.title, status: row.status, winnerTeam: row.winnerTeam, resultText: row.resultText, playedAt: row.playedAt, createdByName: row.createdBy === null ? null : actorNames.get(row.createdBy) ?? null, auditedByName: row.auditedBy === null ? null : actorNames.get(row.auditedBy) ?? null, canEdit: row.status === "scheduled" && !matchesWithProofs.has(row.id) && !matchesWithScores.has(row.id), canDelete: row.status !== "approved" && !matchesWithProofs.has(row.id) && !matchesWithScores.has(row.id), participants: participants.filter(person => person.matchId === row.id) }));
    }),
    create: managerProcedure.input(z.object({ mode: z.string().trim().min(2).max(32), title: z.string().trim().max(120).optional(), teamA: z.array(z.number().int().positive()).min(1).max(12), teamB: z.array(z.number().int().positive()).min(1).max(12), playedAt: z.date().optional() })).mutation(async ({ ctx, input }) => {
      const all = [...input.teamA, ...input.teamB];
      if (new Set(all).size !== all.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Um jogador não pode aparecer duas vezes no mesmo confronto." });
      if (input.teamA.length !== input.teamB.length) throw new TRPCError({ code: "BAD_REQUEST", message: "As equipes precisam ter o mesmo número de participantes." });
      const db = await database();
      try {
        const id = await db.transaction(async tx => {
          const found = await tx.select({ id: players.id, seriesId: players.seriesId, seriesName: series.name }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(and(inArray(players.id, all), eq(players.status, "active")));
          if (found.length !== all.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Há jogador inativo ou não cadastrado na lista." });
          const previous=await tx.select({matchId:matchParticipants.matchId,playerId:matchParticipants.playerId,team:matchParticipants.team}).from(matchParticipants).innerJoin(matches,eq(matches.id,matchParticipants.matchId)).where(and(inArray(matchParticipants.playerId,all),inArray(matches.status,playedMatchStatuses)));
          if(hasPreviousCrossedPair(input.teamA,input.teamB,previous))throw new TRPCError({code:"CONFLICT",message:"O confronto repete um adversário anterior. Gere uma nova prévia com outros pares."});
          const inserted = await tx.insert(matches).values({ mode: input.mode, title: input.title || null, createdBy: ctx.user.id, playedAt: input.playedAt ?? new Date(), status: "scheduled" });
          const matchId = Number(inserted[0].insertId);
          const profileByPlayer = new Map(found.map(row => [row.id, row]));
          await tx.insert(matchParticipants).values([...input.teamA.map(playerId => ({ matchId, playerId, team: "A" as const, seriesIdAtMatch: profileByPlayer.get(playerId)?.seriesId ?? null, seriesNameAtMatch: profileByPlayer.get(playerId)?.seriesName ?? null })), ...input.teamB.map(playerId => ({ matchId, playerId, team: "B" as const, seriesIdAtMatch: profileByPlayer.get(playerId)?.seriesId ?? null, seriesNameAtMatch: profileByPlayer.get(playerId)?.seriesName ?? null }))]);
          await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"match.created",entityType:"match",entityId:matchId,details:JSON.stringify({mode:input.mode,participants:all})});
          return matchId;
        });
        return { id };
      } catch (error) { return dbError(error); }
    }),
    update: managerProcedure.input(z.object({ id:z.number().int().positive(), mode:z.string().trim().min(2).max(32), title:z.string().trim().max(120).nullable(), playedAt:z.date(), teamA:z.array(z.number().int().positive()).min(1).max(12), teamB:z.array(z.number().int().positive()).min(1).max(12) })).mutation(async ({ctx,input})=>{
      const all=[...input.teamA,...input.teamB];
      if(new Set(all).size!==all.length)throw new TRPCError({code:"BAD_REQUEST",message:"Um jogador não pode aparecer duas vezes na mesma partida."});
      if(input.teamA.length!==input.teamB.length)throw new TRPCError({code:"BAD_REQUEST",message:"As equipes precisam ter o mesmo número de participantes."});
      const db=await database();
      try{
        await db.transaction(async tx=>{
          const [match]=await tx.select().from(matches).where(eq(matches.id,input.id)).limit(1);
          if(!match)throw new TRPCError({code:"NOT_FOUND",message:"Partida não encontrada."});
          if(match.status!=="scheduled")throw new TRPCError({code:"CONFLICT",message:"Só partidas agendadas podem ser editadas. Após o envio de resultado ou comprovantes, o histórico fica bloqueado."});
          const [proof]=await tx.select({id:proofs.id}).from(proofs).where(eq(proofs.matchId,input.id)).limit(1);
          const [score]=await tx.select({id:scoreEvents.id}).from(scoreEvents).where(eq(scoreEvents.matchId,input.id)).limit(1);
          if(proof||score)throw new TRPCError({code:"CONFLICT",message:"A partida já possui prova ou pontuação e não pode ser reescrita."});
          const found=await tx.select({id:players.id}).from(players).where(and(inArray(players.id,all),eq(players.status,"active")));
          const activeIds=new Set(found.map(row=>row.id));
          const currentRows=await tx.select({playerId:matchParticipants.playerId,team:matchParticipants.team,status:players.status,stakeAmount:matchParticipants.stakeAmount,seriesIdAtMatch:matchParticipants.seriesIdAtMatch,seriesNameAtMatch:matchParticipants.seriesNameAtMatch}).from(matchParticipants).innerJoin(players,eq(players.id,matchParticipants.playerId)).where(eq(matchParticipants.matchId,input.id));
          const currentSeriesRows=await tx.select({playerId:players.id,seriesId:players.seriesId,seriesName:series.name}).from(players).leftJoin(series,eq(players.seriesId,series.id)).where(inArray(players.id,all));
          const currentSeriesByPlayer=new Map(currentSeriesRows.map(row=>[row.playerId,{seriesId:row.seriesId,seriesName:row.seriesName}]));
          const currentIds=new Set(currentRows.map(row=>row.playerId));
          if(all.some(id=>!activeIds.has(id)&&!currentIds.has(id)))throw new TRPCError({code:"BAD_REQUEST",message:"Novos participantes devem estar cadastrados e ativos."});
          if(!input.teamA.some(id=>activeIds.has(id))||!input.teamB.some(id=>activeIds.has(id)))throw new TRPCError({code:"BAD_REQUEST",message:"Cada equipe precisa ter ao menos um jogador ativo."});
          const previous=await tx.select({matchId:matchParticipants.matchId,playerId:matchParticipants.playerId,team:matchParticipants.team}).from(matchParticipants).innerJoin(matches,eq(matches.id,matchParticipants.matchId)).where(and(inArray(matchParticipants.playerId,all),inArray(matches.status,playedMatchStatuses)));
          if(hasPreviousCrossedPair(input.teamA,input.teamB,previous.filter(row=>row.matchId!==input.id)))throw new TRPCError({code:"CONFLICT",message:"A nova distribuição repete adversários anteriores. Escolha outra divisão de equipes."});
          const previousDetails=new Map(currentRows.map(row=>[row.playerId,row]));
          const before=currentRows.map(({playerId,team,stakeAmount,seriesIdAtMatch,seriesNameAtMatch})=>({playerId,team,stakeAmount,seriesIdAtMatch,seriesNameAtMatch}));
          await tx.update(matches).set({mode:input.mode,title:input.title||null,playedAt:input.playedAt}).where(eq(matches.id,input.id));
          await tx.delete(matchParticipants).where(eq(matchParticipants.matchId,input.id));
          const participantRow=(playerId:number,team:"A"|"B")=>{const previous=previousDetails.get(playerId);const current=currentSeriesByPlayer.get(playerId);return{matchId:input.id,playerId,team,stakeAmount:previous?.stakeAmount??0,seriesIdAtMatch:previous?previous.seriesIdAtMatch:(current?.seriesId??null),seriesNameAtMatch:previous?previous.seriesNameAtMatch:(current?.seriesName??null)};};
          const after=[...input.teamA.map(playerId=>participantRow(playerId,"A")),...input.teamB.map(playerId=>participantRow(playerId,"B"))];
          await tx.insert(matchParticipants).values(after);
          await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"match.updated",entityType:"match",entityId:input.id,details:JSON.stringify({before:{mode:match.mode,title:match.title,playedAt:match.playedAt,participants:before},after:{mode:input.mode,title:input.title,playedAt:input.playedAt,participants:after}})});
        });
        return {success:true};
      }catch(error){return dbError(error);}
    }),
    delete: managerProcedure.input(z.object({id:z.number().int().positive()})).mutation(async({ctx,input})=>{
      const db=await database();
      try{
        await db.transaction(async tx=>{
          const [match]=await tx.select().from(matches).where(eq(matches.id,input.id)).limit(1);
          if(!match)throw new TRPCError({code:"NOT_FOUND",message:"Partida não encontrada."});
          if(match.status==="approved")throw new TRPCError({code:"CONFLICT",message:"Partidas aprovadas não podem ser excluídas porque já alteraram pontuações e histórico."});
          const [proof]=await tx.select({id:proofs.id}).from(proofs).where(eq(proofs.matchId,input.id)).limit(1);
          const [score]=await tx.select({id:scoreEvents.id}).from(scoreEvents).where(eq(scoreEvents.matchId,input.id)).limit(1);
          if(proof||score)throw new TRPCError({code:"CONFLICT",message:"Esta partida possui comprovantes ou pontuação; não pode ser excluída."});
          const participants=await tx.select({playerId:matchParticipants.playerId,nickname:players.nickname,team:matchParticipants.team,stakeAmount:matchParticipants.stakeAmount,seriesIdAtMatch:matchParticipants.seriesIdAtMatch,seriesNameAtMatch:matchParticipants.seriesNameAtMatch}).from(matchParticipants).innerJoin(players,eq(players.id,matchParticipants.playerId)).where(eq(matchParticipants.matchId,input.id));
          await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"match.deleted",entityType:"match",entityId:input.id,details:JSON.stringify({mode:match.mode,title:match.title,status:match.status,playedAt:match.playedAt,participants})});
          await tx.delete(matches).where(eq(matches.id,input.id));
        });
        return {success:true};
      }catch(error){return dbError(error);}
    }),
    createBatch: managerProcedure.input(z.object({ matches:z.array(z.object({mode:z.string().trim().min(2).max(32),title:z.string().trim().max(120).optional(),teamA:z.array(z.number().int().positive()).min(1).max(12),teamB:z.array(z.number().int().positive()).min(1).max(12),playedAt:z.date().optional(),participantDetails:z.array(z.object({playerId:z.number().int().positive(),stakeAmount:z.number().int().min(0).max(100_000),seriesIdAtMatch:z.number().int().positive().nullable()})).max(24)})).min(1).max(50) })).mutation(async ({ctx,input})=>{
      const db=await database();
      const batchPlayers=input.matches.flatMap(item=>[...item.teamA,...item.teamB]);
      if(new Set(batchPlayers).size!==batchPlayers.length)throw new TRPCError({code:"BAD_REQUEST",message:"Um jogador não pode aparecer mais de uma vez no mesmo lote de confrontos."});
      for(const item of input.matches){if(item.teamA.length!==item.teamB.length)throw new TRPCError({code:"BAD_REQUEST",message:"As equipes precisam ter o mesmo número de participantes."});const detailIds=item.participantDetails.map(detail=>detail.playerId);if(new Set(detailIds).size!==detailIds.length||detailIds.length!==item.teamA.length+item.teamB.length||detailIds.some(id=>!item.teamA.includes(id)&&!item.teamB.includes(id)))throw new TRPCError({code:"BAD_REQUEST",message:"Os metadados de aposta/série precisam corresponder exatamente aos participantes da partida."});}
      try{
        const ids=await db.transaction(async tx=>{
          const previous=await tx.select({matchId:matchParticipants.matchId,playerId:matchParticipants.playerId,team:matchParticipants.team}).from(matchParticipants).innerJoin(matches,eq(matches.id,matchParticipants.matchId)).where(and(inArray(matchParticipants.playerId,batchPlayers),inArray(matches.status,playedMatchStatuses)));
          const seriesIds=[...new Set(input.matches.flatMap(item=>item.participantDetails.map(detail=>detail.seriesIdAtMatch).filter((id):id is number=>id!==null)))];
          const existingSeries=seriesIds.length?await tx.select({id:series.id,name:series.name}).from(series).where(inArray(series.id,seriesIds)):[];
          if(existingSeries.length!==seriesIds.length)throw new TRPCError({code:"BAD_REQUEST",message:"Uma das séries selecionadas não existe mais; valide a escalação novamente."});
          const seriesNameById=new Map(existingSeries.map(item=>[item.id,item.name]));
          const profileSeriesRows=await tx.select({playerId:players.id,seriesId:players.seriesId,seriesName:series.name}).from(players).leftJoin(series,eq(players.seriesId,series.id)).where(inArray(players.id,batchPlayers));
          const profileSeriesByPlayer=new Map(profileSeriesRows.map(row=>[row.playerId,{seriesId:row.seriesId,seriesName:row.seriesName}]));
          const created:number[]=[];
          for(const item of input.matches){
            const all=[...item.teamA,...item.teamB];
            if(new Set(all).size!==all.length)throw new TRPCError({code:"BAD_REQUEST",message:"Um jogador não pode aparecer duas vezes no mesmo confronto."});
            const found=await tx.select({id:players.id}).from(players).where(and(inArray(players.id,all),eq(players.status,"active")));
            if(found.length!==all.length)throw new TRPCError({code:"BAD_REQUEST",message:"Há jogador inativo ou não cadastrado na lista."});
            if(hasPreviousCrossedPair(item.teamA,item.teamB,previous))throw new TRPCError({code:"CONFLICT",message:"O lote contém adversários que já se enfrentaram. Gere uma nova prévia antes de confirmar."});
            const inserted=await tx.insert(matches).values({mode:item.mode,title:item.title||null,createdBy:ctx.user.id,playedAt:item.playedAt??new Date(),status:"scheduled"});
            const matchId=Number(inserted[0].insertId);created.push(matchId);
            const detailsByPlayer=new Map(item.participantDetails.map(detail=>[detail.playerId,detail]));
            const participantRow=(playerId:number,team:"A"|"B")=>{
              const detail=detailsByPlayer.get(playerId);
              const profile=profileSeriesByPlayer.get(playerId);
              const seriesIdAtMatch=detail?.seriesIdAtMatch===undefined?(profile?.seriesId??null):detail.seriesIdAtMatch;
              const seriesNameAtMatch=seriesIdAtMatch===null?null:seriesNameById.get(seriesIdAtMatch)??(seriesIdAtMatch===profile?.seriesId?profile?.seriesName??null:null);
              return{matchId,playerId,team,stakeAmount:detail?.stakeAmount??0,seriesIdAtMatch,seriesNameAtMatch};
            };
            const participantRows=[...item.teamA.map(playerId=>participantRow(playerId,"A")),...item.teamB.map(playerId=>participantRow(playerId,"B"))];
            await tx.insert(matchParticipants).values(participantRows);
            await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"match.created",entityType:"match",entityId:matchId,details:JSON.stringify({mode:item.mode,title:item.title??null,participants:participantRows,batch:true})});
          }
          return created;
        });
        return {ids};
      }catch(error){return dbError(error);}
    }),
    setResult: managerProcedure.input(z.object({ id: z.number().int().positive(), winnerTeam: z.enum(["A", "B"]), resultText: z.string().trim().max(160).optional() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx => {
        const [match] = await tx.select({ status: matches.status }).from(matches).where(eq(matches.id, input.id)).limit(1);
        if (!match) throw new TRPCError({ code: "NOT_FOUND", message: "Partida não encontrada." });
        if (match.status !== "scheduled" && match.status !== "rejected") throw new TRPCError({ code: "CONFLICT", message: "O resultado só pode ser informado em uma partida agendada ou rejeitada." });
        if (match.status === "rejected") await tx.update(proofs).set({ status: "pending", reviewReason: null, reviewedBy: null, reviewedAt: null }).where(eq(proofs.matchId, input.id));
        await tx.update(matches).set({ winnerTeam: input.winnerTeam, resultText: input.resultText || null, status: "awaiting_proofs" }).where(eq(matches.id, input.id));
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"match.result_submitted",entityType:"match",entityId:input.id,details:JSON.stringify({winnerTeam:input.winnerTeam,resultText:input.resultText})});
      });
      return { success: true };
    }),
    uploadOptions: protectedProcedure.input(z.object({matchId:z.number().int().positive()})).query(async({ctx,input})=>{
      const db=await database();
      const rows=await db.select({playerId:players.id,nickname:players.nickname,userId:players.userId}).from(matchParticipants).innerJoin(players,eq(matchParticipants.playerId,players.id)).where(eq(matchParticipants.matchId,input.matchId));
      const role=await getCommunityRole(ctx.user);
      return rows.filter(row=>role!=="member"||row.userId===ctx.user.id).map(({userId,...row})=>row);
    }),
    uploadProof: protectedProcedure.input(z.object({ matchId: z.number().int().positive(), playerId: z.number().int().positive(), fileName: z.string().trim().min(1).max(180), mimeType: z.enum(["image/jpeg", "image/png", "image/webp"]), base64: z.string().min(1).max(7_100_000) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      const [match] = await db.select({ status: matches.status }).from(matches).where(eq(matches.id, input.matchId)).limit(1);
      if (!match || (match.status !== "awaiting_proofs" && match.status !== "under_review")) throw new TRPCError({ code: "BAD_REQUEST", message: "Esta partida não está recebendo comprovantes." });
      const [participant] = await db.select({ playerId: matchParticipants.playerId, userId:players.userId }).from(matchParticipants).innerJoin(players,eq(players.id,matchParticipants.playerId)).where(and(eq(matchParticipants.matchId, input.matchId), eq(matchParticipants.playerId, input.playerId))).limit(1);
      if (!participant) throw new TRPCError({ code: "BAD_REQUEST", message: "O jogador não participa desta partida." });
      const role=await getCommunityRole(ctx.user);
      if(role==="member"&&participant.userId!==ctx.user.id)throw new TRPCError({code:"FORBIDDEN",message:"Sua conta só pode enviar comprovantes para o jogador vinculado ao seu perfil."});
      const stored = await storeImage({ base64: input.base64, mimeType: input.mimeType, label: input.fileName });
      await db.transaction(async tx=>{
        const [currentMatch]=await tx.select({status:matches.status}).from(matches).where(eq(matches.id,input.matchId)).limit(1);
        const [currentParticipant]=await tx.select({userId:players.userId}).from(matchParticipants).innerJoin(players,eq(players.id,matchParticipants.playerId)).where(and(eq(matchParticipants.matchId,input.matchId),eq(matchParticipants.playerId,input.playerId))).limit(1);
        if(!currentMatch||!currentParticipant||(currentMatch.status!=="awaiting_proofs"&&currentMatch.status!=="under_review"))throw new TRPCError({code:"CONFLICT",message:"A partida mudou enquanto o comprovante era enviado. O registro não foi salvo."});
        if(role==="member"&&currentParticipant.userId!==ctx.user.id)throw new TRPCError({code:"FORBIDDEN",message:"A conta deixou de estar vinculada ao jogador escolhido."});
        const inserted=await tx.insert(proofs).values({matchId:input.matchId,playerId:input.playerId,objectKey:stored.objectKey,fileName:input.fileName,mimeType:input.mimeType});
        await tx.update(matches).set({status:"under_review"}).where(eq(matches.id,input.matchId));
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"proof.uploaded",entityType:"proof",entityId:Number(inserted[0].insertId),details:JSON.stringify({matchId:input.matchId,playerId:input.playerId,bytes:stored.bytes})});
      });
      return { success: true };
    }),
    reviewProof: auditorProcedure.input(z.object({ proofId: z.number().int().positive(), status: z.enum(["approved", "rejected", "review"]), reason: z.string().trim().min(3).max(500) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx=>{
        const [proof]=await tx.select({matchId:proofs.matchId,status:proofs.status}).from(proofs).where(eq(proofs.id,input.proofId)).limit(1);
        if(!proof)throw new TRPCError({code:"NOT_FOUND",message:"Comprovante não encontrado."});
        const [match]=await tx.select({status:matches.status}).from(matches).where(eq(matches.id,proof.matchId)).limit(1);
        if(!match||match.status==="approved")throw new TRPCError({code:"CONFLICT",message:"A partida já foi aprovada ou encerrada; evidências não podem ser alteradas."});
        if(proof.status==="approved"&&input.status!=="approved")throw new TRPCError({code:"CONFLICT",message:"Um comprovante aprovado não pode ser reaberto. Rejeite a partida para iniciar uma nova revisão."});
        if(proof.status===input.status)throw new TRPCError({code:"CONFLICT",message:"O comprovante já está neste estado."});
        await tx.update(proofs).set({ status: input.status, reviewReason: input.reason, reviewedBy: ctx.user.id, reviewedAt: new Date() }).where(eq(proofs.id, input.proofId));
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:`proof.${input.status}`,entityType:"proof",entityId:input.proofId,details:JSON.stringify({reason:input.reason})});
      });
      return { success: true };
    }),
    audit: auditorProcedure.input(z.object({ id: z.number().int().positive(), decision: z.enum(["approved", "rejected"]), reason: z.string().trim().min(5).max(500) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx => {
        const [match] = await tx.select().from(matches).where(eq(matches.id, input.id)).limit(1);
        if (!match) throw new TRPCError({ code: "NOT_FOUND", message: "Partida não encontrada." });
        if (match.status === "approved") throw new TRPCError({ code: "CONFLICT", message: "A partida já foi aprovada e pontuada." });
        if (input.decision === "approved") {
          if (!match.winnerTeam) throw new TRPCError({ code: "BAD_REQUEST", message: "Registre primeiro o resultado e a equipe vencedora." });
          const people = await tx.select({ playerId: matchParticipants.playerId, team: matchParticipants.team }).from(matchParticipants).where(eq(matchParticipants.matchId, input.id));
          const winners = people.filter(p => p.team === match.winnerTeam);
          if (!winners.length) throw new TRPCError({ code: "BAD_REQUEST", message: "A equipe vencedora não tem participantes cadastrados." });
          const winnerIds = winners.map(p => p.playerId);
          const acceptedProofs = await tx.select({ playerId: proofs.playerId }).from(proofs).where(and(eq(proofs.matchId, input.id), eq(proofs.status, "approved"), inArray(proofs.playerId, winnerIds)));
          const covered = new Set(acceptedProofs.map(p => p.playerId));
          if (winnerIds.some(id => !covered.has(id))) throw new TRPCError({ code: "BAD_REQUEST", message: "Cada vencedor precisa ter pelo menos um comprovante aprovado." });
          const settings = await tx.select().from(communitySettings).where(inArray(communitySettings.settingKey, ["winPoints", "lossPoints"]));
          const winPoints = Math.max(0, Number(settings.find(s => s.settingKey === "winPoints")?.settingValue ?? 3) || 0);
          const lossPoints = Math.max(0, Number(settings.find(s => s.settingKey === "lossPoints")?.settingValue ?? 0) || 0);
          for (const person of people) {
            const value = person.team === match.winnerTeam ? winPoints : lossPoints;
            await tx.insert(scoreEvents).values({ matchId: input.id, playerId: person.playerId, points: value, reason: person.team === match.winnerTeam ? "Vitória auditada" : "Participação em partida auditada", createdBy: ctx.user.id });
            await tx.update(players).set({ points: sql`${players.points} + ${value}`, wins: sql`${players.wins} + ${person.team === match.winnerTeam ? 1 : 0}`, losses: sql`${players.losses} + ${person.team === match.winnerTeam ? 0 : 1}` }).where(eq(players.id, person.playerId));
            await tx.update(matchParticipants).set({ pointsAwarded: value }).where(and(eq(matchParticipants.matchId, input.id), eq(matchParticipants.playerId, person.playerId)));
            const [updatedPlayer] = await tx.select({ points: players.points, seriesId: players.seriesId }).from(players).where(eq(players.id, person.playerId)).limit(1);
            const thresholds = await tx.select({ id: series.id, minPoints: series.minPoints }).from(series).where(eq(series.active, 1)).orderBy(desc(series.minPoints));
            const reached = thresholds.find(item => updatedPlayer && updatedPlayer.points >= item.minPoints);
            if (reached && updatedPlayer?.seriesId !== reached.id) {
              await tx.update(players).set({ seriesId: reached.id }).where(eq(players.id, person.playerId));
              await tx.insert(auditLog).values({ actorUserId: ctx.user.id, action: "player.series_auto_changed", entityType: "player", entityId: person.playerId, details: JSON.stringify({ seriesId: reached.id, points: updatedPlayer.points }) });
            }
          }
        }
        await tx.update(matches).set({ status: input.decision, auditReason: input.reason, auditedBy: ctx.user.id, auditedAt: new Date() }).where(eq(matches.id, input.id));
        await tx.insert(auditLog).values({ actorUserId: ctx.user.id, action: `match.${input.decision}`, entityType: "match", entityId: input.id, details: JSON.stringify({ reason: input.reason }) });
      });
      return { success: true };
    }),
    proofs: anyStaffProcedure.input(z.object({ matchId: z.number().int().positive() })).query(async ({ input }) => {
      const db = await database();
      return db.select({ id: proofs.id, matchId: proofs.matchId, playerId: proofs.playerId, nickname: players.nickname, objectKey: proofs.objectKey, fileName: proofs.fileName, mimeType: proofs.mimeType, status: proofs.status, reviewReason: proofs.reviewReason, createdAt: proofs.createdAt }).from(proofs).innerJoin(players, eq(proofs.playerId, players.id)).where(eq(proofs.matchId, input.matchId)).orderBy(desc(proofs.createdAt));
    }),
    reportResult: protectedProcedure.input(z.object({ matchId: z.number().int().positive(), reason: z.string().trim().min(10).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      const [match] = await db.select({ id: matches.id, status: matches.status }).from(matches).where(eq(matches.id, input.matchId)).limit(1);
      if (!match || match.status === "scheduled") throw new TRPCError({ code: "BAD_REQUEST", message: "Só é possível denunciar um resultado já informado." });
      await writeAudit(ctx.user.id, "match.reported", "match", input.matchId, { reason: input.reason });
      return { success: true };
    }),
  }),
  pairer: router({
    spinWheel: managerProcedure.input(z.object({ names: z.array(z.string().trim().min(1).max(80)).min(2).max(48) })).mutation(({ input }) => {
      const normalizedNames = input.names.map(normalized);
      if (new Set(normalizedNames).size !== normalizedNames.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Remova nomes duplicados da lista antes de girar." });
      const selection = pickRandomWheelOption(input.names);
      if (!selection) throw new TRPCError({ code: "BAD_REQUEST", message: "Adicione pelo menos dois nomes para girar." });
      return { selectedIndex: selection.index, selectedName: selection.item };
    }),
    spinAllWheels: managerProcedure.input(z.object({
      wheels: z.tuple([
        z.array(z.string().trim().min(1).max(80)).min(2).max(48),
        z.array(z.string().trim().min(1).max(80)).min(2).max(48),
        z.array(z.string().trim().min(1).max(80)).min(2).max(48),
      ]),
    })).mutation(({ input }) => {
      for (const names of input.wheels) {
        const normalizedNames = names.map(normalized);
        if (new Set(normalizedNames).size !== normalizedNames.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Cada roleta precisa ter nomes únicos. Remova as duplicatas antes do giro conjunto." });
      }
      const selections = pickRandomWheelOptions(input.wheels);
      const results = selections.map(selection => {
        if (!selection) throw new TRPCError({ code: "BAD_REQUEST", message: "Cada roleta precisa ter pelo menos dois nomes." });
        return { selectedIndex: selection.index, selectedName: selection.item };
      });
      return { results };
    }),
    resolveRoster: managerProcedure.input(z.object({ text: z.string().trim().min(1).max(12_000) })).mutation(async ({ input }) => {
      const db = await database();
      const [roster, activeSeries] = await Promise.all([
        db.select({ id: players.id, nickname: players.nickname, points: players.points, seriesId: players.seriesId, seriesName: series.name }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(eq(players.status, "active")).limit(2_000),
        db.select({ id: series.id, name: series.name }).from(series).where(eq(series.active, 1)),
      ]);
      return resolveWhatsAppRoster(input.text, roster, activeSeries);
    }),
    validateNames: managerProcedure.input(z.object({ names: z.array(z.string().trim().min(1).max(60)).max(200) })).query(async ({ input }) => {
      const db = await database();
      const clean = input.names.map(n => n.trim()).filter(Boolean);
      const duplicates = clean.filter((n, i) => clean.findIndex(x => normalized(x) === normalized(n)) !== i);
      const rows = clean.length ? await db.select({ id: players.id, nickname: players.nickname, points: players.points, seriesName: series.name, seriesId: players.seriesId, status: players.status }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(inArray(players.normalizedNickname, clean.map(normalized))) : [];
      const byNick = new Map(rows.map(row => [normalized(row.nickname), row]));
      return { players: clean.map(name => ({ input: name, matched: byNick.get(normalized(name)) ?? null })), duplicates: [...new Set(duplicates.map(n => n.trim()))], unknown: clean.filter(n => !byNick.has(normalized(n))) };
    }),
    generate: managerProcedure.input(z.object({
      playerIds: z.array(z.number().int().positive()).min(2).max(96),
      mode: z.enum(["1x1", "2x2", "3x3", "4x4", "custom"]),
      customSize: z.number().int().min(1).max(6).optional(),
      balance: z.boolean().default(true),
      avoidRematches: z.boolean().default(true),
      sourcePairs: z.array(z.tuple([z.number().int().positive(), z.number().int().positive()])).max(48).default([]),
      seriesOverrides: z.array(z.object({ playerId: z.number().int().positive(), seriesId: z.number().int().positive().nullable() })).max(96).default([]),
    })).mutation(async ({ input }) => {
      const selectedIds = new Set(input.playerIds);
      if (selectedIds.size !== input.playerIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Remova participantes duplicados antes de gerar." });
      const overridePlayerIds = new Set(input.seriesOverrides.map(item => item.playerId));
      if (overridePlayerIds.size !== input.seriesOverrides.length || input.seriesOverrides.some(item => !selectedIds.has(item.playerId))) throw new TRPCError({ code: "BAD_REQUEST", message: "A série temporária precisa corresponder a um participante único da lista." });
      for (const [a, b] of input.sourcePairs) {
        if (a === b || !selectedIds.has(a) || !selectedIds.has(b)) throw new TRPCError({ code: "BAD_REQUEST", message: "A lista de duplas de entrada não corresponde aos participantes selecionados." });
      }

      const size = input.mode === "custom" ? (input.customSize ?? 1) : Number(input.mode[0]);
      const db = await database();
      const found = await db.select({ id: players.id, nickname: players.nickname, points: players.points, seriesId: players.seriesId, seriesName: series.name, seriesOrder: series.orderIndex }).from(players).leftJoin(series, eq(players.seriesId, series.id)).where(and(inArray(players.id, input.playerIds), eq(players.status, "active")));
      if (found.length !== input.playerIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "A lista contém jogador inativo ou não cadastrado." });
      if (found.length % (size * 2) !== 0) throw new TRPCError({ code: "BAD_REQUEST", message: `Para ${input.mode}, selecione múltiplo de ${size * 2} participantes.` });

      const requestedSeriesIds = [...new Set(input.seriesOverrides.flatMap(item => item.seriesId === null ? [] : [item.seriesId]))];
      const overrideSeriesRows = requestedSeriesIds.length ? await db.select({ id: series.id, name: series.name, orderIndex: series.orderIndex }).from(series).where(and(inArray(series.id, requestedSeriesIds), eq(series.active, 1))) : [];
      if (overrideSeriesRows.length !== requestedSeriesIds.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Uma série escolhida não está mais ativa; atualize as vagas antes de gerar." });
      const overrideByPlayer = new Map(input.seriesOverrides.map(item => [item.playerId, item.seriesId]));
      const overrideSeriesById = new Map(overrideSeriesRows.map(item => [item.id, item]));
      const rankedRoster = found.map(player => {
        if (!overrideByPlayer.has(player.id)) return player;
        const seriesId = overrideByPlayer.get(player.id) ?? null;
        const selectedSeries = seriesId === null ? undefined : overrideSeriesById.get(seriesId);
        return { ...player, seriesId, seriesName: selectedSeries?.name ?? null, seriesOrder: selectedSeries?.orderIndex ?? null };
      });

      const prior = await db.select({ matchId: matchParticipants.matchId, playerId: matchParticipants.playerId, team: matchParticipants.team }).from(matchParticipants).innerJoin(matches, eq(matches.id, matchParticipants.matchId)).where(and(inArray(matchParticipants.playerId, input.playerIds), inArray(matches.status, playedMatchStatuses)));
      const priorTeams = new Map<number,{A:number[];B:number[]}>();
      for (const row of prior) {
        const teams = priorTeams.get(row.matchId) ?? { A: [], B: [] };
        teams[row.team].push(row.playerId);
        priorTeams.set(row.matchId, teams);
      }
      const previousOpponentPairs = new Set<string>();
      for (const teams of priorTeams.values()) {
        for (const a of teams.A) for (const b of teams.B) previousOpponentPairs.add(pairingKey(a, b));
      }

      const plan = generateBalancedPairings(rankedRoster, {
        teamSize: size,
        balance: input.balance,
        avoidRematches: input.avoidRematches,
        previousOpponentPairs,
        sourcePairs: input.sourcePairs,
        attempts: 250,
      });
      const conflicts = [
        input.avoidRematches && plan.repeats ? `${plan.repeats} revanche(s)` : null,
        plan.sourceConflicts ? `${plan.sourceConflicts} par(es) original(is)` : null,
      ].filter(Boolean);
      if (conflicts.length) throw new TRPCError({
        code: "BAD_REQUEST",
        message: `Não foi possível sortear equipes diferentes sem manter os pares informados ou repetir adversários (${conflicts.join(", ")}). Altere a lista e gere uma nova prévia.`,
      });

      const note = input.balance
        ? size === 1 ? "Duelos 1v1 equilibrados por série e pontuação; confirme os lados na etapa de sorteio 50/50." : "Lista redistribuída em novas equipes, balanceadas por série e pontuação."
        : size === 1 ? "Duelos 1v1 sorteados; confirme os lados na etapa de sorteio 50/50." : "Lista redistribuída em novas equipes sorteadas aleatoriamente.";
      return { pairings: plan.pairings, note };
    }),
    drawTeams: managerProcedure.input(z.object({ duels: z.array(z.tuple([z.number().int().positive(), z.number().int().positive()])).min(1).max(6) })).mutation(async ({ input }) => {
      const ids = input.duels.flat();
      if (new Set(ids).size !== ids.length || input.duels.some(([a, b]) => a === b)) throw new TRPCError({ code: "BAD_REQUEST", message: "Cada jogador deve participar de um único duelo." });
      const db = await database();
      const activePlayers = await db.select({ id: players.id }).from(players).where(and(inArray(players.id, ids), eq(players.status, "active")));
      if (activePlayers.length !== ids.length) throw new TRPCError({ code: "BAD_REQUEST", message: "Um participante ficou inativo ou não está mais cadastrado. Gere os duelos novamente." });
      const previous = await db.select({ matchId: matchParticipants.matchId, playerId: matchParticipants.playerId, team: matchParticipants.team }).from(matchParticipants).innerJoin(matches, eq(matches.id, matchParticipants.matchId)).where(and(inArray(matchParticipants.playerId, ids), inArray(matches.status, playedMatchStatuses)));
      const draw = drawDuelSides(input.duels, (teamA, teamB) => !hasPreviousCrossedPair(teamA, teamB, previous));
      if (!draw) throw new TRPCError({ code: "CONFLICT", message: "Não existe uma divisão 50/50 sem repetir adversários anteriores. Altere os duelos ou a lista de jogadores." });
      return draw;
    }),
  }),
  draws: router({
    list: publicProcedure.query(async () => {
      const db = await database();
      const rows = await db.select().from(draws).where(eq(draws.status, "confirmed")).orderBy(desc(draws.createdAt)).limit(50);
      return rows.map(row => ({ ...row, participants: JSON.parse(row.participantNames) as string[], results: JSON.parse(row.resultNames) as string[] }));
    }),
    preview: managerProcedure.input(z.object({ title: z.string().trim().min(2).max(120), names: z.array(z.string().trim().min(1).max(60)).min(2).max(500), slots: z.number().int().min(1).max(500), mode: z.enum(["random", "series"]).default("random"), previousDraftId: z.number().int().positive().optional() })).mutation(async ({ ctx, input }) => {
      const rawNames = input.names.map(n => n.trim());
      if (new Set(rawNames.map(normalized)).size !== rawNames.length) throw new TRPCError({ code: "BAD_REQUEST", message: "A lista contém participantes duplicados." });
      if (input.slots > rawNames.length) throw new TRPCError({ code: "BAD_REQUEST", message: "O número de vagas não pode superar participantes." });
      const db = await database();
      const participants=await db.select({nickname:players.nickname,normalizedNickname:players.normalizedNickname,seriesId:players.seriesId,orderIndex:series.orderIndex}).from(players).leftJoin(series,eq(players.seriesId,series.id)).where(and(inArray(players.normalizedNickname,rawNames.map(normalized)),eq(players.status,"active")));
      if(participants.length!==rawNames.length)throw new TRPCError({code:"BAD_REQUEST",message:"O sorteio aceita somente jogadores cadastrados e ativos; verifique a lista."});
      const roster=new Map(participants.map(p=>[p.normalizedNickname,{nickname:p.nickname,seriesId:p.seriesId,orderIndex:p.orderIndex??Number.MAX_SAFE_INTEGER}]));
      const names=rawNames.map(name=>roster.get(normalized(name))!.nickname);
      let ordered = secureShuffle([...names]);
      if (input.mode === "series") {
        const buckets = new Map<string, { order: number; names: string[] }>();
        for (const name of names) {
          const player = roster.get(normalized(name));
          const key = player?.seriesId ? `series-${player.seriesId}` : "series-unassigned";
          const bucket = buckets.get(key) ?? { order: player?.orderIndex ?? Number.MAX_SAFE_INTEGER, names: [] };
          bucket.names.push(name);
          buckets.set(key, bucket);
        }
          const categories = secureShuffle([...buckets.values()].sort((a,b) => a.order - b.order));
        for (const category of categories) secureShuffle(category.names);
        ordered = [];
        while (categories.some(category => category.names.length)) {
          for (const category of categories) {
            const next = category.names.shift();
            if (next) ordered.push(next);
          }
        }
      }
      const results = ordered.slice(0, input.slots);
      const id = await db.transaction(async tx => {
        if (input.previousDraftId) await tx.delete(draws).where(and(eq(draws.id, input.previousDraftId), eq(draws.createdBy, ctx.user.id), eq(draws.status, "draft")));
        const inserted = await tx.insert(draws).values({ title: input.title, mode: input.mode, slots: input.slots, status: "draft", participantNames: JSON.stringify(names), resultNames: JSON.stringify(results), createdBy: ctx.user.id });
        const id=Number(inserted[0].insertId);
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"draw.previewed",entityType:"draw",entityId:id,details:JSON.stringify({slots:input.slots,participantCount:names.length,mode:input.mode,results})});
        return id;
      });
      return { id, participants: names, results, slots: input.slots, mode: input.mode };
    }),
    confirm: managerProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      const result=await db.transaction(async tx=>{
        const [draw]=await tx.select().from(draws).where(and(eq(draws.id,input.id),eq(draws.createdBy,ctx.user.id),eq(draws.status,"draft"))).limit(1);
        if(!draw)throw new TRPCError({code:"NOT_FOUND",message:"Prévia não encontrada ou já confirmada."});
        const changed=await tx.update(draws).set({status:"confirmed"}).where(and(eq(draws.id,input.id),eq(draws.createdBy,ctx.user.id),eq(draws.status,"draft")));
        if(Number(changed[0].affectedRows??0)!==1)throw new TRPCError({code:"CONFLICT",message:"Este sorteio acabou de ser confirmado por outra solicitação."});
        const results=JSON.parse(draw.resultNames) as string[];
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"draw.confirmed",entityType:"draw",entityId:input.id,details:JSON.stringify({slots:draw.slots,participantCount:JSON.parse(draw.participantNames).length,mode:draw.mode,results})});
        return results;
      });
      return { success: true, results:result };
    }),
  }),
  settings: router({
    publicData: publicProcedure.query(async () => {
      const db = await database();
      const rows = await db.select().from(communitySettings).where(inArray(communitySettings.settingKey, ["whatsappPrimary", "whatsappSecondary", "tiktok", "instagram", "support", "rules", "winPoints", "lossPoints"]));
      return Object.fromEntries(rows.map(r => [r.settingKey, r.settingValue]));
    }),
    save: moderatorProcedure.input(z.object({ values: z.record(z.string().max(64), z.string().max(5000)) })).mutation(async ({ ctx, input }) => {
      const editable = new Set(["whatsappPrimary", "whatsappSecondary", "tiktok", "instagram", "support", "rules", "winPoints", "lossPoints"]);
      const entries = Object.entries(input.values);
      if (entries.some(([key]) => !editable.has(key))) throw new TRPCError({ code: "BAD_REQUEST", message: "Configuração não permitida." });
      const urlKeys = new Set(["whatsappPrimary", "whatsappSecondary", "tiktok", "instagram", "support"]);
      for (const [key, value] of entries) {
        if (urlKeys.has(key) && value) {
          try { if (new URL(value).protocol !== "https:") throw new Error("protocol"); }
          catch { throw new TRPCError({ code: "BAD_REQUEST", message: `O link ${key} deve ser uma URL HTTPS válida.` }); }
        }
      }
      if (["winPoints", "lossPoints"].some(key => key in input.values && (!/^\d{1,4}$/.test(input.values[key]) || Number(input.values[key]) > 1000))) throw new TRPCError({ code: "BAD_REQUEST", message: "Pontuação deve ser um número entre 0 e 1000." });
      const db = await database();
      await db.transaction(async tx=>{
        for(const [settingKey,settingValue] of entries)await tx.insert(communitySettings).values({settingKey,settingValue,updatedBy:ctx.user.id}).onDuplicateKeyUpdate({set:{settingValue,updatedBy:ctx.user.id,updatedAt:new Date()}});
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"settings.updated",entityType:"settings",entityId:null,details:JSON.stringify({keys:entries.map(([key])=>key)})});
      });
      return { success: true };
    }),
  }),
  announcements: router({
    list: publicProcedure.query(async () => {
      const db = await database();
      return db.select().from(announcements).where(eq(announcements.active, 1)).orderBy(desc(announcements.createdAt)).limit(20);
    }),
    create: moderatorProcedure.input(z.object({ title: z.string().trim().min(3).max(120), body: z.string().trim().min(5).max(3000) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      return db.transaction(async tx=>{
        const inserted=await tx.insert(announcements).values({title:input.title,body:input.body,createdBy:ctx.user.id});
        const id=Number(inserted[0].insertId);
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"announcement.created",entityType:"announcement",entityId:id,details:JSON.stringify({title:input.title})});
        return {id};
      });
    }),
    deactivate: moderatorProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx=>{
        const [notice]=await tx.select({id:announcements.id}).from(announcements).where(eq(announcements.id,input.id)).limit(1);
        if(!notice)throw new TRPCError({code:"NOT_FOUND",message:"Aviso não encontrado."});
        await tx.update(announcements).set({active:0}).where(eq(announcements.id,input.id));
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"announcement.deactivated",entityType:"announcement",entityId:input.id,details:JSON.stringify({})});
      });
      return { success: true };
    }),
  }),
  administration: router({
    me: protectedProcedure.query(async ({ ctx }) => ({ user: ctx.user, role: await getCommunityRole(ctx.user) })),
    listUsers: roleProcedure(owner).input(z.object({ search: z.string().trim().max(100).optional() })).query(async ({ input }) => {
      const db = await database();
      const rows = await db.select({ id: users.id, name: users.name, email: users.email, role: adminRoles.role }).from(users).leftJoin(adminRoles, eq(adminRoles.userId, users.id)).where(input.search ? or(like(users.name, `%${input.search}%`), like(users.email, `%${input.search}%`)) : undefined).limit(100);
      return rows;
    }),
    grantRole: roleProcedure(owner).input(z.object({ userId: z.number().int().positive(), role: z.enum(["match_admin", "auditor", "moderator"]) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      if (ctx.user.id === input.userId) throw new TRPCError({ code: "BAD_REQUEST", message: "O administrador principal não altera o próprio papel por aqui." });
      await db.transaction(async tx=>{
        const [account]=await tx.select({id:users.id}).from(users).where(eq(users.id,input.userId)).limit(1);
        if(!account)throw new TRPCError({code:"NOT_FOUND",message:"Conta não encontrada."});
        await tx.insert(adminRoles).values({userId:input.userId,role:input.role,grantedBy:ctx.user.id}).onDuplicateKeyUpdate({set:{role:input.role,grantedBy:ctx.user.id}});
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"admin.role_granted",entityType:"user",entityId:input.userId,details:JSON.stringify({role:input.role})});
      });
      return { success: true };
    }),
    revokeRole: roleProcedure(owner).input(z.object({ userId: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx=>{
        await tx.delete(adminRoles).where(eq(adminRoles.userId,input.userId));
        await tx.insert(auditLog).values({actorUserId:ctx.user.id,action:"admin.role_revoked",entityType:"user",entityId:input.userId,details:JSON.stringify({})});
      });
      return { success: true };
    }),
    auditLog: anyStaffProcedure.input(z.object({ limit: z.number().int().min(1).max(100).default(50) }).optional()).query(async ({ input }) => {
      const db = await database();
      return db.select({ id: auditLog.id, actor: users.name, action: auditLog.action, entityType: auditLog.entityType, entityId: auditLog.entityId, details: auditLog.details, createdAt: auditLog.createdAt }).from(auditLog).leftJoin(users, eq(auditLog.actorUserId, users.id)).orderBy(desc(auditLog.createdAt)).limit(input?.limit ?? 50);
    }),
    exportBackup: roleProcedure(owner).query(async ({ctx}) => createBackupSnapshot(ctx.user.id)),
    restoreBackup: roleProcedure(owner).input(z.object({ snapshot: z.unknown() })).mutation(async ({ ctx, input }) => restoreBackupSnapshot(ctx.user.id, input.snapshot)),
  }),
  stats: router({
    summary: publicProcedure.query(async () => {
      const db = await database();
      const [row] = await db.select({ players: count(), points: sql<number>`coalesce(sum(${players.points}), 0)`, wins: sql<number>`coalesce(sum(${players.wins}), 0)`, losses: sql<number>`coalesce(sum(${players.losses}), 0)` }).from(players).where(eq(players.status, "active"));
      const monthly = await db.select({ month: sql<string>`date_format(${matches.playedAt}, '%Y-%m')`, matches: count() }).from(matches).where(eq(matches.status, "approved")).groupBy(sql`date_format(${matches.playedAt}, '%Y-%m')`).orderBy(sql`date_format(${matches.playedAt}, '%Y-%m') desc`).limit(12);
      return { players: row?.players ?? 0, points: Number(row?.points ?? 0), wins: Number(row?.wins ?? 0), losses: Number(row?.losses ?? 0), monthly };
    }),
  }),
});

export type AppRouter = typeof appRouter;
