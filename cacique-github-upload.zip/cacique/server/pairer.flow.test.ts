import { describe, expect, it } from "vitest";
import { drawDuelSides, pickRandomWheelOption, pickRandomWheelOptions } from "./services/pairing";
import { resolveWhatsAppRoster } from "./services/whatsappRoster";

const activeSeries = [
  { id: 1, name: "👑 MESTRE" },
  { id: 2, name: "💎 DIAMANTE I" },
  { id: 3, name: "💎 DIAMANTE II" },
];

const roster = [
  { id: 1, nickname: "Hype", points: 10, seriesId: 2, seriesName: "💎 DIAMANTE I" },
  { id: 2, nickname: "Pimba", points: 11, seriesId: 1, seriesName: "👑 MESTRE" },
  { id: 3, nickname: "Doc", points: 9, seriesId: 3, seriesName: "💎 DIAMANTE II" },
];

describe("duelo e sorteio de equipes", () => {
  it("coloca exatamente um integrante de cada duelo em cada time", () => {
    const duels = [["Hype", "Pimba"], ["Doc", "Unit"], ["A", "B"]] as const;
    const draw = drawDuelSides(duels);

    expect(draw).not.toBeNull();
    expect(draw?.teamA).toHaveLength(3);
    expect(draw?.teamB).toHaveLength(3);
    for (const [first, second] of duels) {
      expect(Number(draw?.teamA.includes(first)) + Number(draw?.teamA.includes(second))).toBe(1);
      expect(Number(draw?.teamB.includes(first)) + Number(draw?.teamB.includes(second))).toBe(1);
    }
  });

  it("respeita combinações permitidas e retorna null quando todas repetem adversários", () => {
    const duels = [[1, 2], [3, 4]] as const;
    const draw = drawDuelSides(duels, (teamA) => teamA.includes(1) && teamA.includes(4));
    expect(draw?.teamA).toEqual(expect.arrayContaining([1, 4]));
    expect(drawDuelSides(duels, () => false)).toBeNull();
  });
});

describe("roleta de nomes", () => {
  it("escolhe um índice válido e devolve o nome correspondente sem alterar a lista", () => {
    const options = ["Hype", "Pimba", "Doc", "Unit"] as const;
    for (let attempt = 0; attempt < 20; attempt++) {
      const selection = pickRandomWheelOption(options);
      expect(selection).not.toBeNull();
      expect(selection!.index).toBeGreaterThanOrEqual(0);
      expect(selection!.index).toBeLessThan(options.length);
      expect(options[selection!.index]).toBe(selection!.item);
    }
    expect(options).toEqual(["Hype", "Pimba", "Doc", "Unit"]);
  });

  it("não gera opção quando a lista está vazia", () => {
    expect(pickRandomWheelOption([])).toBeNull();
  });

  it("escolhe uma opção válida, separada para cada uma das três listas", () => {
    const wheels = [["Hype", "Pimba"], ["Doc", "Unit", "Lua"], ["Nina", "Zed"]] as const;
    const selections = pickRandomWheelOptions(wheels);

    expect(selections).toHaveLength(3);
    selections.forEach((selection, index) => {
      expect(selection).not.toBeNull();
      expect(selection!.index).toBeGreaterThanOrEqual(0);
      expect(selection!.index).toBeLessThan(wheels[index]!.length);
      expect(wheels[index]![selection!.index]).toBe(selection!.item);
    });
    expect(wheels).toEqual([["Hype", "Pimba"], ["Doc", "Unit", "Lua"], ["Nina", "Zed"]]);
  });
});

describe("importação de roster do WhatsApp", () => {
  it("identifica nicks, séries atuais e aposta indicada em cada linha", () => {
    const result = resolveWhatsAppRoster(
      "3x3 - FULL UMP\n1. Hype 💎 DIAMANTE I R$ 12\n2. Pimba 👑 MESTRE R$ 15",
      roster,
      activeSeries,
    );

    expect(result.slots.map(({ nickname, seriesId, stakeAmount }) => ({ nickname, seriesId, stakeAmount }))).toEqual([
      { nickname: "Hype", seriesId: 2, stakeAmount: 12 },
      { nickname: "Pimba", seriesId: 1, stakeAmount: 15 },
    ]);
    expect(result.unrecognizedLines).toEqual(["3x3 - FULL UMP"]);
  });

  it("não descarta duplicata do mesmo jogador repetida na mesma linha", () => {
    const result = resolveWhatsAppRoster("Hype - Hype", roster, activeSeries);
    expect(result.slots.map((slot) => slot.nickname)).toEqual(["Hype", "Hype"]);
    expect(result.duplicates).toEqual(["Hype"]);
  });

  it("mantém nicks não cadastrados identificados como linhas não reconhecidas", () => {
    const result = resolveWhatsAppRoster("Hype\nPlayer Sem Cadastro", roster, activeSeries);
    expect(result.slots.map((slot) => slot.nickname)).toEqual(["Hype"]);
    expect(result.unrecognizedLines).toEqual(["Player Sem Cadastro"]);
  });

  it("marca o fragmento desconhecido quando vem junto de um nick reconhecido", () => {
    const result = resolveWhatsAppRoster("Hype - Player Sem Cadastro\nPimba - R$ 12", roster, activeSeries);
    expect(result.slots.map((slot) => slot.nickname)).toEqual(["Hype", "Pimba"]);
    expect(result.unrecognizedLines).toEqual(["Player Sem Cadastro"]);
  });

  it("separa dois participantes importados na mesma linha e aponta duplicados", () => {
    const result = resolveWhatsAppRoster("Hype - Pimba\nHype", roster, activeSeries);
    expect(result.slots.map((slot) => slot.nickname)).toEqual(["Hype", "Pimba", "Hype"]);
    expect(result.duplicates).toEqual(["Hype"]);
  });
});
