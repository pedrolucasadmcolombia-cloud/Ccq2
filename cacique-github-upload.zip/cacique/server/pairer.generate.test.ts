import { describe, expect, it } from "vitest";
import { generateBalancedPairings } from "./services/pairing";

const roster = [
  { id: 1, nickname: "Hype", points: 10, seriesOrder: 4 },
  { id: 2, nickname: "Pimba", points: 11, seriesOrder: 4 },
  { id: 3, nickname: "Doc", points: 10, seriesOrder: 4 },
  { id: 4, nickname: "Unit", points: 11, seriesOrder: 4 },
];
const originalPairs: readonly [number, number][] = [[1, 2], [3, 4]];

function teamsContainPair(teams: number[][], [a, b]: readonly [number, number]) {
  return teams.some((team) => team.includes(a) && team.includes(b));
}

describe("pairer.generate", () => {
  it("redistributes imported 2x2 duos and keeps the example teams balanced", () => {
    const result = generateBalancedPairings(roster, {
      teamSize: 2,
      balance: true,
      avoidRematches: true,
      sourcePairs: originalPairs,
      attempts: 250,
    });

    expect(result.pairings).toHaveLength(1);
    expect(result.sourceConflicts).toBe(0);
    expect(result.repeats).toBe(0);

    const pairing = result.pairings[0]!;
    const teams = [pairing.teamA.map((player) => player.id), pairing.teamB.map((player) => player.id)];
    expect(teamsContainPair(teams, [1, 2])).toBe(false);
    expect(teamsContainPair(teams, [3, 4])).toBe(false);
    expect(pairing.teamA.reduce((sum, player) => sum + player.points, 0)).toBe(21);
    expect(pairing.teamB.reduce((sum, player) => sum + player.points, 0)).toBe(21);
  });

  it("does not preserve imported pairs as 1x1 opponents", () => {
    const result = generateBalancedPairings(roster, {
      teamSize: 1,
      balance: true,
      avoidRematches: true,
      sourcePairs: originalPairs,
      attempts: 250,
    });

    expect(result.pairings).toHaveLength(2);
    expect(result.sourceConflicts).toBe(0);
    for (const pairing of result.pairings) {
      const ids = [pairing.teamA[0]!.id, pairing.teamB[0]!.id];
      expect(ids).not.toEqual(expect.arrayContaining([1, 2]));
      expect(ids).not.toEqual(expect.arrayContaining([3, 4]));
    }
  });
});
