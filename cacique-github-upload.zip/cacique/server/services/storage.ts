import { randomUUID } from "node:crypto";
import { ENV } from "../_core/env";

const allowedTypes = new Set(["image/jpeg", "image/png", "image/webp"]);

export async function storeImage(input: { base64: string; mimeType: string; label: string }) {
  if (!allowedTypes.has(input.mimeType)) throw new Error("Formato não permitido. Envie JPG, PNG ou WebP.");
  if(!/^[A-Za-z0-9+/]+={0,2}$/.test(input.base64)||input.base64.length%4===1)throw new Error("O arquivo enviado não é uma imagem base64 válida.");
  const data = Buffer.from(input.base64, "base64");
  if (data.length < 1 || data.length > 5 * 1024 * 1024) throw new Error("A imagem deve ter até 5 MB.");
  const isJpeg=data.length>=3&&data[0]===0xff&&data[1]===0xd8&&data[2]===0xff;
  const isPng=data.length>=8&&data.subarray(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]));
  const isWebp=data.length>=12&&data.toString("ascii",0,4)==="RIFF"&&data.toString("ascii",8,12)==="WEBP";
  if(!(input.mimeType==="image/jpeg"&&isJpeg)&&!(input.mimeType==="image/png"&&isPng)&&!(input.mimeType==="image/webp"&&isWebp))throw new Error("O conteúdo do arquivo não corresponde ao formato de imagem informado.");
  if (!ENV.forgeApiUrl || !ENV.forgeApiKey) throw new Error("Armazenamento do projeto não está disponível.");
  const safeName = input.label.normalize("NFKD").replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 64) || "comprovante";
  const key = `sorteado-cacique/proofs/${Date.now()}-${randomUUID()}-${safeName}`;
  const auth = { Authorization: `Bearer ${ENV.forgeApiKey}` };
  const presignUrl = new URL("/v1/storage/presign/put", ENV.forgeApiUrl);
  presignUrl.searchParams.set("path", key);
  const signed = await fetch(presignUrl, { headers: auth });
  const signedData = await signed.json() as { url?: string; error?: string };
  if (!signed.ok || !signedData.url) throw new Error(signedData.error || "Não foi possível preparar o armazenamento.");
  const upload = await fetch(signedData.url, { method: "PUT", headers: { "Content-Type": input.mimeType }, body: data });
  if (!upload.ok) throw new Error("O comprovante não foi enviado ao armazenamento.");
  return { objectKey: key, publicPath: `/manus-storage/${key}`, bytes: data.length };
}
