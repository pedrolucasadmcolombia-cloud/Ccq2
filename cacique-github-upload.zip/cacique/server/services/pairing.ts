import { randomInt } from "node:crypto";

export type RankedParticipant = {
  id: number;
  nickname: string;
  points: number;
  seriesOrder: number | null;
};

export type GeneratedPairing<T extends RankedParticipant> = {
  teamA: T[];
  teamB: T[];
  averagePoints: number;
};

export type PairingPlan<T extends RankedParticipant> = {
  pairings: GeneratedPairing<T>[];
  repeats: number;
  sourceConflicts: number;
  seriesDiff: number;
  pointDiff: number;
};

export type PairingOptions = {
  teamSize: number;
  balance: boolean;
  avoidRematches: boolean;
  previousOpponentPairs?: ReadonlySet<string>;
  sourcePairs?: readonly (readonly [number, number])[];
  attempts?: number;
};

export function pairingKey(a: number, b: number) {
  return a < b ? `${a}:${b}` : `${b}:${a}`;
}

export function secureShuffle<T>(items: T[]) {
  for (let i = items.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [items[i], items[j]] = [items[j]!, items[i]!];
  }
  return items;
}

export function pickRandomWheelOption<T>(items: readonly T[]) {
  if (items.length === 0) return null;
  const index = randomInt(items.length);
  return { index, item: items[index]! };
}

export function pickRandomWheelOptions<T>(wheels: readonly (readonly T[])[]) {
  return wheels.map(items => pickRandomWheelOption(items));
}

/**
 * Assigns exactly one player from each duel to each team. Every possible 50/50
 * orientation is visited in a cryptographically shuffled order so a historical
 * rematch filter can reject invalid team combinations without biasing the draw.
 */
export function drawDuelSides<T>(
  duels: readonly (readonly [T, T])[],
  isAllowed: (teamA: readonly T[], teamB: readonly T[]) => boolean = () => true,
) {
  if (duels.length === 0) return null;
  const orientations = secureShuffle(Array.from({ length: 2 ** duels.length }, (_, mask) => mask));

  for (const mask of orientations) {
    const teamA: T[] = [];
    const teamB: T[] = [];
    duels.forEach(([first, second], index) => {
      if ((mask & (1 << index)) === 0) {
        teamA.push(first);
        teamB.push(second);
      } else {
        teamA.push(second);
        teamB.push(first);
      }
    });
    if (isAllowed(teamA, teamB)) return { teamA, teamB };
  }

  return null;
}

/**
 * Builds new teams from the full roster. No score/name sort is applied after the
 * random shuffle: that deterministic sort used to reconstruct imported duos.
 * The candidate search instead selects the most balanced random split.
 */
export function generateBalancedPairings<T extends RankedParticipant>(
  players: readonly T[],
  options: PairingOptions,
): PairingPlan<T> {
  const previousOpponentPairs = options.previousOpponentPairs ?? new Set<string>();
  const sourcePairKeys = new Set((options.sourcePairs ?? []).map(([a, b]) => pairingKey(a, b)));
  const attempts = Math.max(1, options.attempts ?? 250);
  let best: PairingPlan<T> | null = null;

  for (let attempt = 0; attempt < attempts; attempt++) {
    const randomized = secureShuffle([...players]);
    const pairings: GeneratedPairing<T>[] = [];
    let repeats = 0;
    let sourceConflicts = 0;
    let seriesDiff = 0;
    let pointDiff = 0;

    for (let start = 0; start < randomized.length; start += options.teamSize * 2) {
      const group = randomized.slice(start, start + options.teamSize * 2);
      const teamA = group.slice(0, options.teamSize);
      const teamB = group.slice(options.teamSize);

      for (const a of teamA) {
        for (const b of teamB) {
          const key = pairingKey(a.id, b.id);
          if (options.avoidRematches && previousOpponentPairs.has(key)) repeats++;
          if (options.teamSize === 1 && sourcePairKeys.has(key)) sourceConflicts++;
        }
      }

      if (options.teamSize > 1) {
        for (const team of [teamA, teamB]) {
          for (let i = 0; i < team.length; i++) {
            for (let j = i + 1; j < team.length; j++) {
              if (sourcePairKeys.has(pairingKey(team[i]!.id, team[j]!.id))) sourceConflicts++;
            }
          }
        }
      }

      const teamASeries = teamA.reduce((sum, player) => sum + (player.seriesOrder ?? -1), 0);
      const teamBSeries = teamB.reduce((sum, player) => sum + (player.seriesOrder ?? -1), 0);
      const teamAPoints = teamA.reduce((sum, player) => sum + player.points, 0);
      const teamBPoints = teamB.reduce((sum, player) => sum + player.points, 0);
      seriesDiff += Math.abs(teamASeries - teamBSeries);
      pointDiff += Math.abs(teamAPoints - teamBPoints);

      pairings.push({
        teamA,
        teamB,
        averagePoints: Math.round(group.reduce((sum, player) => sum + player.points, 0) / group.length),
      });
    }

    const candidate: PairingPlan<T> = { pairings, repeats, sourceConflicts, seriesDiff, pointDiff };
    const isBetter = !best
      || candidate.repeats < best.repeats
      || (candidate.repeats === best.repeats && candidate.sourceConflicts < best.sourceConflicts)
      || (options.balance && candidate.repeats === best.repeats && candidate.sourceConflicts === best.sourceConflicts && candidate.seriesDiff < best.seriesDiff)
      || (options.balance && candidate.repeats === best.repeats && candidate.sourceConflicts === best.sourceConflicts && candidate.seriesDiff === best.seriesDiff && candidate.pointDiff < best.pointDiff);

    if (isBetter) best = candidate;
    if (best && best.repeats === 0 && best.sourceConflicts === 0 && !options.balance) break;
  }

  return best ?? { pairings: [], repeats: 0, sourceConflicts: 0, seriesDiff: 0, pointDiff: 0 };
}
