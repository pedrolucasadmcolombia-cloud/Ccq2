export type RosterPlayer = {
  id: number;
  nickname: string;
  points: number;
  seriesId: number | null;
  seriesName: string | null;
};

export type RosterSeries = { id: number; name: string };

export type ResolvedRosterSlot = {
  playerId: number;
  nickname: string;
  points: number;
  currentSeriesId: number | null;
  currentSeriesName: string | null;
  seriesId: number | null;
  seriesName: string | null;
  seriesOverridden: boolean;
  stakeAmount: number;
  sourceLine: string;
};

export type RosterResolution = {
  slots: ResolvedRosterSlot[];
  duplicates: string[];
  unrecognizedLines: string[];
  excessCount: number;
};

const DEFAULT_STAKE = 15;
const MAX_SLOTS = 12;

function fold(value: string) {
  return value
    .normalize("NFKD")
    .replace(/\p{M}/gu, "")
    .toLocaleLowerCase("pt-BR")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim()
    .replace(/\s+/g, " ");
}

function cleanLine(value: string) {
  return value
    .trim()
    .replace(/^>\s*/u, "")
    .replace(/^\s*(?:\d{1,3}\s*(?:[.)\-:]\s*|\s+)|[•*]+\s*)/u, "")
    .trim();
}

function containsPhrase(text: string, phrase: string) {
  if (!phrase) return false;
  return (` ${text} `).includes(` ${phrase} `);
}

function parseStake(line: string) {
  const match = line.match(/(?:R\$\s*|(?:aposta|valor)\s*[:=\-]?\s*)(\d{1,6})/i);
  if (!match) return DEFAULT_STAKE;
  const amount = Number(match[1]);
  return Number.isInteger(amount) && amount >= 0 && amount <= 100_000 ? amount : DEFAULT_STAKE;
}

/**
 * Resolves WhatsApp lines against active, registered players. It supports one or
 * several nicks per line (including `Jogador A - Jogador B`) and only applies a
 * series override when the current series name is explicitly present after that
 * nick. The returned series value never updates the player's profile.
 */
export function resolveWhatsAppRoster(
  text: string,
  players: readonly RosterPlayer[],
  activeSeries: readonly RosterSeries[],
): RosterResolution {
  const normalizedPlayers = players
    .map((player) => ({ player, nickname: fold(player.nickname) }))
    .filter((item) => item.nickname.length >= 2)
    .sort((a, b) => b.nickname.length - a.nickname.length);
  const normalizedSeries = activeSeries.map((item) => ({ series: item, name: fold(item.name) }));
  const slots: ResolvedRosterSlot[] = [];
  const unrecognizedLines: string[] = [];
  const seenPlayerIds = new Set<number>();
  const duplicates: string[] = [];

  for (const original of text.split(/\r?\n/)) {
    const line = cleanLine(original);
    if (!line) continue;
    const normalizedLine = fold(line);
    if (!normalizedLine) continue;
    const paddedLine = ` ${normalizedLine} `;
    const candidates = normalizedPlayers
      .flatMap(({ player, nickname }) => {
        const needle = ` ${nickname} `;
        const occurrences: Array<{ player: RosterPlayer; nickname: string; index: number; end: number }> = [];
        let cursor = 0;
        while (true) {
          const matchIndex = paddedLine.indexOf(needle, cursor);
          if (matchIndex < 0) break;
          const index = matchIndex + 1;
          occurrences.push({ player, nickname, index, end: index + nickname.length });
          cursor = matchIndex + 1;
        }
        return occurrences;
      })
      .sort((a, b) => a.index - b.index || b.nickname.length - a.nickname.length);

    const matched: typeof candidates = [];
    for (const candidate of candidates) {
      const overlaps = matched.some((previous) => candidate.index < previous.end && previous.index < candidate.end);
      if (!overlaps) matched.push(candidate);
    }

    if (!matched.length) {
      unrecognizedLines.push(line);
      continue;
    }

    const unmatchedSegments = line
      .split(/\s+[-–—|,;]\s+/u)
      .map((segment) => segment.trim())
      .filter((segment) => {
        const normalizedSegment = fold(segment);
        if (!normalizedSegment) return false;
        const hasRegisteredPlayer = normalizedPlayers.some(({ nickname }) => containsPhrase(normalizedSegment, nickname));
        const isKnownSeries = normalizedSeries.some(({ name }) => containsPhrase(normalizedSegment, name));
        const isStake = /^(?:r\s+\d{1,6}|(?:aposta|valor)(?:\s+r)?\s+\d{1,6})$/u.test(normalizedSegment);
        return !hasRegisteredPlayer && !isKnownSeries && !isStake;
      });
    unrecognizedLines.push(...unmatchedSegments);

    const wager = parseStake(line);
    matched.forEach((candidate, index) => {
      const nextStart = matched[index + 1]?.index ?? paddedLine.length - 1;
      const metadata = paddedLine.slice(candidate.end, nextStart);
      const seriesMatch = normalizedSeries.find(({ name }) => containsPhrase(metadata, name))
        ?? (matched.length === 1 ? normalizedSeries.find(({ name }) => containsPhrase(normalizedLine, name)) : undefined);
      const seriesId = seriesMatch?.series.id ?? candidate.player.seriesId;
      const seriesName = seriesMatch?.series.name ?? candidate.player.seriesName;
      if (seenPlayerIds.has(candidate.player.id)) duplicates.push(candidate.player.nickname);
      seenPlayerIds.add(candidate.player.id);
      slots.push({
        playerId: candidate.player.id,
        nickname: candidate.player.nickname,
        points: candidate.player.points,
        currentSeriesId: candidate.player.seriesId,
        currentSeriesName: candidate.player.seriesName,
        seriesId,
        seriesName,
        seriesOverridden: Boolean(seriesMatch),
        stakeAmount: wager,
        sourceLine: line,
      });
    });
  }

  return {
    slots: slots.slice(0, MAX_SLOTS),
    duplicates: [...new Set(duplicates)],
    unrecognizedLines,
    excessCount: Math.max(0, slots.length - MAX_SLOTS),
  };
}
