import { count, eq } from "drizzle-orm";
import { z } from "zod";
import { announcements, auditLog, communitySettings, draws, matchParticipants, matches, players, proofs, scoreAdjustments, scoreEvents, series, users } from "../../drizzle/schema";
import { getDb } from "../db";
import { TRPCError } from "@trpc/server";

const dateText = z.string().min(1).max(40).refine(value => !Number.isNaN(Date.parse(value)), "Data inválida.");
const nullableDateText = dateText.nullable();
const backupSchema = z.object({
  schemaVersion: z.literal(1),
  projectId: z.string().min(1).max(128),
  exportedAt: dateText,
  series: z.array(z.object({ id:z.number().int().positive(), code:z.string().min(1).max(32), name:z.string().min(1).max(64), color:z.string().regex(/^#[0-9a-fA-F]{6}$/), minPoints:z.number().int().min(0), orderIndex:z.number().int().min(0), active:z.number().int().min(0).max(1), createdAt:dateText })).max(200),
  players: z.array(z.object({ id:z.number().int().positive(), nickname:z.string().min(2).max(40), normalizedNickname:z.string().min(1).max(40), userId:z.number().int().positive().nullable().default(null), gameId:z.string().max(40).nullable(), avatarUrl:z.string().max(512).nullable(), seriesId:z.number().int().positive().nullable(), points:z.number().int().min(0), wins:z.number().int().min(0), losses:z.number().int().min(0), status:z.enum(["active","inactive"]), notes:z.string().nullable(), joinedAt:dateText, createdAt:dateText, updatedAt:dateText })).max(10000),
  matches: z.array(z.object({ id:z.number().int().positive(), mode:z.string().min(1).max(32), title:z.string().max(120).nullable(), status:z.enum(["scheduled","awaiting_proofs","under_review","approved","rejected"]), winnerTeam:z.enum(["A","B"]).nullable(), resultText:z.string().max(160).nullable(), playedAt:dateText, createdBy:z.number().int().positive().nullable().default(null), auditedBy:z.number().int().positive().nullable().default(null), auditReason:z.string().nullable(), auditedAt:nullableDateText, createdAt:dateText, updatedAt:dateText })).max(10000),
  participants: z.array(z.object({ id:z.number().int().positive(), matchId:z.number().int().positive(), playerId:z.number().int().positive(), team:z.enum(["A","B"]), pointsAwarded:z.number().int() })).max(50000),
  proofs: z.array(z.object({ id:z.number().int().positive(), matchId:z.number().int().positive(), playerId:z.number().int().positive(), objectKey:z.string().regex(/^sorteado-cacique\/proofs\/[A-Za-z0-9._/-]{1,220}$/).refine(value=>!value.includes("..")), fileName:z.string().min(1).max(180), mimeType:z.enum(["image/jpeg","image/png","image/webp"]), status:z.enum(["pending","approved","rejected","review"]), reviewReason:z.string().nullable(), reviewedBy:z.number().int().positive().nullable().default(null), createdAt:dateText, reviewedAt:nullableDateText })).max(50000),
  scoreEvents: z.array(z.object({ id:z.number().int().positive(), matchId:z.number().int().positive(), playerId:z.number().int().positive(), points:z.number().int(), reason:z.string().min(1).max(180), createdBy:z.number().int().positive().nullable().default(null), createdAt:dateText })).max(50000),
  scoreAdjustments:z.array(z.object({id:z.number().int().positive(),playerId:z.number().int().positive(),delta:z.number().int(),reason:z.string().min(1).max(300),createdBy:z.number().int().positive().nullable().default(null),createdAt:dateText})).max(50000).default([]),
  draws: z.array(z.object({ id:z.number().int().positive(), title:z.string().min(1).max(120), mode:z.string().min(1).max(48), slots:z.number().int().min(1), status:z.enum(["draft","confirmed"]), participantNames:z.string().max(100000), resultNames:z.string().max(100000), createdBy:z.number().int().positive().nullable().default(null), createdAt:dateText })).max(10000),
  settings: z.array(z.object({ settingKey:z.string().min(1).max(64), settingValue:z.string().max(5000), updatedBy:z.number().int().positive().nullable().default(null), updatedAt:dateText })).max(100),
  announcements: z.array(z.object({ id:z.number().int().positive(), title:z.string().min(1).max(120), body:z.string().min(1).max(3000), active:z.number().int().min(0).max(1), createdBy:z.number().int().positive().nullable().default(null), createdAt:dateText })).max(10000),
  auditLog: z.array(z.object({ actorUserId:z.number().int().positive().nullable().default(null), action:z.string().min(1).max(80), entityType:z.string().min(1).max(50), entityId:z.number().int().nullable(), details:z.string().nullable(), createdAt:dateText })).max(50000),
}).strict().superRefine((data,ctx)=>{
  const codes=new Set<string>();
  for(const item of data.series){if(codes.has(item.code))ctx.addIssue({code:"custom",message:"O backup contém códigos de série duplicados."});codes.add(item.code);}
  const seriesIds=new Set(data.series.map(item=>item.id));
  const playerIds=new Set(data.players.map(item=>item.id));
  const matchIds=new Set(data.matches.map(item=>item.id));
  const pairKeys=new Set<string>();
  const linkedAccounts=new Set<number>();for(const item of data.players)if(item.userId!==null){if(linkedAccounts.has(item.userId))ctx.addIssue({code:"custom",message:"O backup associa a mesma conta a mais de um jogador."});linkedAccounts.add(item.userId);}
  for(const item of data.players)if(item.seriesId!==null&&!seriesIds.has(item.seriesId))ctx.addIssue({code:"custom",message:"O backup contém jogador associado a uma série inexistente."});
  for(const row of data.participants){const key=`${row.matchId}:${row.playerId}`;if(!matchIds.has(row.matchId)||!playerIds.has(row.playerId)||pairKeys.has(key))ctx.addIssue({code:"custom",message:"O backup contém participantes duplicados ou sem partida/jogador válido."});pairKeys.add(key);}
  for(const item of data.proofs)if(!matchIds.has(item.matchId)||!pairKeys.has(`${item.matchId}:${item.playerId}`))ctx.addIssue({code:"custom",message:"O backup contém comprovante associado a jogador que não participa da partida."});
  for(const item of data.scoreEvents)if(!matchIds.has(item.matchId)||!pairKeys.has(`${item.matchId}:${item.playerId}`))ctx.addIssue({code:"custom",message:"O backup contém pontuação associada a jogador que não participa da partida."});
  for(const item of data.scoreAdjustments)if(!playerIds.has(item.playerId))ctx.addIssue({code:"custom",message:"O backup contém ajuste sem jogador correspondente."});
  for(const item of data.draws){for(const raw of [item.participantNames,item.resultNames]){try{const parsed=JSON.parse(raw);if(!Array.isArray(parsed)||parsed.some((value:unknown)=>typeof value!=="string"))throw new Error();}catch{ctx.addIssue({code:"custom",message:"O backup contém dados inválidos de sorteio."});}}}
});

export type BackupSnapshot = z.infer<typeof backupSchema>;

async function database(){
  const db=await getDb();
  if(!db)throw new TRPCError({code:"SERVICE_UNAVAILABLE",message:"Banco de dados indisponível."});
  return db;
}

export async function createBackupSnapshot(actorUserId:number):Promise<BackupSnapshot>{
  const db=await database();
  const [seriesRows,playerRows,matchRows,participantRows,proofRows,scoreRows,adjustmentRows,drawRows,settingRows,announcementRows,logRows]=await Promise.all([
    db.select().from(series),db.select().from(players),db.select().from(matches),db.select().from(matchParticipants),db.select().from(proofs),db.select().from(scoreEvents),db.select().from(scoreAdjustments),db.select().from(draws),db.select().from(communitySettings),db.select().from(announcements),db.select().from(auditLog),
  ]);
  const snapshot={
    schemaVersion:1 as const,
    projectId:process.env.MANUS_PROJECT_ID||"",
    exportedAt:new Date().toISOString(),
    series:seriesRows.map(({id,code,name,color,minPoints,orderIndex,active,createdAt})=>({id,code,name,color,minPoints,orderIndex,active,createdAt:createdAt.toISOString()})),
    players:playerRows.map(({id,nickname,normalizedNickname,userId,gameId,avatarUrl,seriesId,points,wins,losses,status,notes,joinedAt,createdAt,updatedAt})=>({id,nickname,normalizedNickname,userId,gameId,avatarUrl,seriesId,points,wins,losses,status,notes,joinedAt:joinedAt.toISOString(),createdAt:createdAt.toISOString(),updatedAt:updatedAt.toISOString()})),
    matches:matchRows.map(({id,mode,title,status,winnerTeam,resultText,playedAt,createdBy,auditedBy,auditReason,auditedAt,createdAt,updatedAt})=>({id,mode,title,status,winnerTeam,resultText,playedAt:playedAt.toISOString(),createdBy,auditedBy,auditReason,auditedAt:auditedAt?.toISOString()??null,createdAt:createdAt.toISOString(),updatedAt:updatedAt.toISOString()})),
    participants:participantRows.map(row=>({...row})),
    proofs:proofRows.map(({id,matchId,playerId,objectKey,fileName,mimeType,status,reviewReason,reviewedBy,createdAt,reviewedAt})=>({id,matchId,playerId,objectKey,fileName,mimeType,status,reviewReason,reviewedBy,createdAt:createdAt.toISOString(),reviewedAt:reviewedAt?.toISOString()??null})),
    scoreEvents:scoreRows.map(({id,matchId,playerId,points,reason,createdBy,createdAt})=>({id,matchId,playerId,points,reason,createdBy,createdAt:createdAt.toISOString()})),
    scoreAdjustments:adjustmentRows.map(({id,playerId,delta,reason,createdBy,createdAt})=>({id,playerId,delta,reason,createdBy,createdAt:createdAt.toISOString()})),
    draws:drawRows.map(({id,title,mode,slots,status,participantNames,resultNames,createdBy,createdAt})=>({id,title,mode,slots,status,participantNames,resultNames,createdBy,createdAt:createdAt.toISOString()})),
    settings:settingRows.map(({settingKey,settingValue,updatedBy,updatedAt})=>({settingKey,settingValue,updatedBy,updatedAt:updatedAt.toISOString()})),
    announcements:announcementRows.map(({id,title,body,active,createdBy,createdAt})=>({id,title,body,active,createdBy,createdAt:createdAt.toISOString()})),
    auditLog:logRows.map(({actorUserId,action,entityType,entityId,details,createdAt})=>({actorUserId,action,entityType,entityId,details,createdAt:createdAt.toISOString()})),
  };
  const validated=backupSchema.parse(snapshot);
  await db.insert(auditLog).values({actorUserId,action:"backup.exported",entityType:"backup",entityId:null,details:JSON.stringify({players:playerRows.length,matches:matchRows.length,draws:drawRows.length,proofs:proofRows.length})});
  return validated;
}

export async function restoreBackupSnapshot(actorUserId:number,input:unknown){
  const snapshot=backupSchema.parse(input);
  const projectId=process.env.MANUS_PROJECT_ID||"";
  if(!projectId||snapshot.projectId!==projectId)throw new TRPCError({code:"BAD_REQUEST",message:"Este backup não pertence a este projeto. Comprovantes armazenados não podem ser transferidos entre projetos por esse recurso."});
  const db=await database();
  return db.transaction(async tx=>{
    const [playersCount]=await tx.select({value:count()}).from(players);
    const [matchesCount]=await tx.select({value:count()}).from(matches);
    const [participantsCount]=await tx.select({value:count()}).from(matchParticipants);
    const [drawsCount]=await tx.select({value:count()}).from(draws);
    const [proofsCount]=await tx.select({value:count()}).from(proofs);
    const [scoresCount]=await tx.select({value:count()}).from(scoreEvents);
    const [adjustmentsCount]=await tx.select({value:count()}).from(scoreAdjustments);
    const [announcementsCount]=await tx.select({value:count()}).from(announcements);
    if([playersCount,matchesCount,participantsCount,drawsCount,proofsCount,scoresCount,adjustmentsCount,announcementsCount].some(row=>Number(row?.value??0)>0))throw new TRPCError({code:"CONFLICT",message:"A recuperação exige tabelas de jogadores, partidas, participantes, sorteios, comprovantes, pontuações e avisos sem dados. Nenhum registro existente foi alterado."});

    const currentSeries=await tx.select().from(series);
    for(const existing of currentSeries){
      const incoming=snapshot.series.find(item=>item.code===existing.code);
      if(!incoming||incoming.name!==existing.name||incoming.color!==existing.color||incoming.minPoints!==existing.minPoints||incoming.orderIndex!==existing.orderIndex||incoming.active!==existing.active)throw new TRPCError({code:"CONFLICT",message:"A recuperação foi bloqueada porque há uma série existente ausente ou diferente do backup. Nenhum dado foi alterado."});
    }
    const currentSettings=await tx.select().from(communitySettings);
    for(const existing of currentSettings){
      const incoming=snapshot.settings.find(item=>item.settingKey===existing.settingKey);
      if(!incoming||incoming.settingValue!==existing.settingValue)throw new TRPCError({code:"CONFLICT",message:"A recuperação foi bloqueada porque há uma configuração existente diferente do backup. Nenhum dado foi alterado."});
    }
    const existingUsers=await tx.select({id:users.id}).from(users);
    const userIds=new Set(existingUsers.map(user=>user.id));
    const actor=(id:number|null)=>id!==null&&userIds.has(id)?id:null;

    const seriesIds=new Map<number,number>();
    for(const item of snapshot.series){
      const existing=currentSeries.find(row=>row.code===item.code);
      if(existing)seriesIds.set(item.id,existing.id);
      else{const inserted=await tx.insert(series).values({code:item.code,name:item.name,color:item.color,minPoints:item.minPoints,orderIndex:item.orderIndex,active:item.active,createdAt:new Date(item.createdAt)});seriesIds.set(item.id,Number(inserted[0].insertId));}
    }
    const playerIds=new Map<number,number>();
    for(const item of snapshot.players){
      await tx.insert(players).values({id:item.id,nickname:item.nickname,normalizedNickname:item.normalizedNickname,userId:actor(item.userId),gameId:item.gameId,avatarUrl:item.avatarUrl,seriesId:item.seriesId===null?null:seriesIds.get(item.seriesId)??null,points:item.points,wins:item.wins,losses:item.losses,status:item.status,notes:item.notes,joinedAt:new Date(item.joinedAt),createdAt:new Date(item.createdAt),updatedAt:new Date(item.updatedAt)});
      playerIds.set(item.id,item.id);
    }
    const matchIds=new Map<number,number>();
    for(const item of snapshot.matches){
      await tx.insert(matches).values({id:item.id,mode:item.mode,title:item.title,status:item.status,winnerTeam:item.winnerTeam,resultText:item.resultText,playedAt:new Date(item.playedAt),createdBy:actor(item.createdBy),auditedBy:actor(item.auditedBy),auditReason:item.auditReason,auditedAt:item.auditedAt?new Date(item.auditedAt):null,createdAt:new Date(item.createdAt),updatedAt:new Date(item.updatedAt)});
      matchIds.set(item.id,item.id);
    }
    for(const item of snapshot.participants){
      const matchId=matchIds.get(item.matchId),playerId=playerIds.get(item.playerId);
      if(!matchId||!playerId)throw new TRPCError({code:"BAD_REQUEST",message:"Backup inválido: há participante sem partida ou jogador correspondente."});
      await tx.insert(matchParticipants).values({id:item.id,matchId,playerId,team:item.team,pointsAwarded:item.pointsAwarded});
    }
    for(const item of snapshot.proofs){
      const matchId=matchIds.get(item.matchId),playerId=playerIds.get(item.playerId);
      if(!matchId||!playerId)throw new TRPCError({code:"BAD_REQUEST",message:"Backup inválido: há comprovante sem partida ou jogador correspondente."});
      await tx.insert(proofs).values({id:item.id,matchId,playerId,objectKey:item.objectKey,fileName:item.fileName,mimeType:item.mimeType,status:item.status,reviewReason:item.reviewReason,reviewedBy:actor(item.reviewedBy),createdAt:new Date(item.createdAt),reviewedAt:item.reviewedAt?new Date(item.reviewedAt):null});
    }
    for(const item of snapshot.scoreEvents){
      const matchId=matchIds.get(item.matchId),playerId=playerIds.get(item.playerId);
      if(!matchId||!playerId)throw new TRPCError({code:"BAD_REQUEST",message:"Backup inválido: há pontuação sem partida ou jogador correspondente."});
      await tx.insert(scoreEvents).values({id:item.id,matchId,playerId,points:item.points,reason:item.reason,createdBy:actor(item.createdBy),createdAt:new Date(item.createdAt)});
    }
    for(const item of snapshot.scoreAdjustments){const playerId=playerIds.get(item.playerId);if(!playerId)throw new TRPCError({code:"BAD_REQUEST",message:"Backup inválido: há ajuste sem jogador correspondente."});await tx.insert(scoreAdjustments).values({id:item.id,playerId,delta:item.delta,reason:item.reason,createdBy:actor(item.createdBy),createdAt:new Date(item.createdAt)});}
    for(const item of snapshot.draws)await tx.insert(draws).values({id:item.id,title:item.title,mode:item.mode,slots:item.slots,status:item.status,participantNames:item.participantNames,resultNames:item.resultNames,createdBy:actor(item.createdBy),createdAt:new Date(item.createdAt)});
    for(const item of snapshot.settings){if(currentSettings.some(row=>row.settingKey===item.settingKey))continue;await tx.insert(communitySettings).values({settingKey:item.settingKey,settingValue:item.settingValue,updatedBy:actor(item.updatedBy),updatedAt:new Date(item.updatedAt)});}
    for(const item of snapshot.announcements)await tx.insert(announcements).values({id:item.id,title:item.title,body:item.body,active:item.active,createdBy:actor(item.createdBy),createdAt:new Date(item.createdAt)});
    for(const item of snapshot.auditLog)await tx.insert(auditLog).values({actorUserId:actor(item.actorUserId),action:item.action,entityType:item.entityType,entityId:item.entityId,details:item.details,createdAt:new Date(item.createdAt)});
    await tx.insert(auditLog).values({actorUserId,action:"backup.restored",entityType:"backup",entityId:null,details:JSON.stringify({players:snapshot.players.length,matches:snapshot.matches.length,draws:snapshot.draws.length,proofs:snapshot.proofs.length})});
    return {players:snapshot.players.length,matches:snapshot.matches.length,draws:snapshot.draws.length,proofs:snapshot.proofs.length,scoreAdjustments:snapshot.scoreAdjustments.length};
  });
}
