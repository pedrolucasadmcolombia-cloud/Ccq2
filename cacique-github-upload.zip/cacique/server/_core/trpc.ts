import { ADMIN_CSRF_COOKIE, NOT_ADMIN_ERR_MSG, UNAUTHED_ERR_MSG } from "@shared/const";
import { parse as parseCookieHeader } from "cookie";
import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { TrpcContext } from "./context";
import { constantTimeTokenMatch } from "./adminPassword";

const t = initTRPC.context<TrpcContext>().create({ transformer: superjson });

export const router = t.router;
export const publicProcedure = t.procedure;

const requireUser = t.middleware(async ({ ctx, next }) => {
  if (!ctx.user) throw new TRPCError({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  return next({ ctx: { ...ctx, user: ctx.user } });
});

const requireAdminCsrf = t.middleware(async ({ ctx, next }) => {
  if (ctx.adminPasswordSession && ctx.req.method !== "GET" && ctx.req.method !== "HEAD") {
    let csrfCookie: string | undefined;
    try {
      csrfCookie = parseCookieHeader(ctx.req.headers.cookie ?? "")[ADMIN_CSRF_COOKIE];
    } catch {
      csrfCookie = undefined;
    }
    const csrfHeader = ctx.req.get("x-cacique-csrf");
    if (!constantTimeTokenMatch(csrfCookie, ctx.adminCsrfToken) || !constantTimeTokenMatch(csrfHeader, ctx.adminCsrfToken)) {
      throw new TRPCError({ code: "FORBIDDEN", message: "Sessão inválida. Atualize a página e entre novamente." });
    }
  }
  return next();
});

export const protectedProcedure = t.procedure.use(requireUser).use(requireAdminCsrf);

export const adminProcedure = protectedProcedure.use(
  t.middleware(async ({ ctx, next }) => {
    if (!ctx.user || ctx.user.role !== "admin" || ctx.user.loginMethod !== "local-password") {
      throw new TRPCError({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({ ctx: { ...ctx, user: ctx.user } });
  }),
);
