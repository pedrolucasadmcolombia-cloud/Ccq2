import { createHash, createHmac, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import { ADMIN_CSRF_COOKIE } from "@shared/const";
import { getSessionCookieOptions } from "./cookies";

export const LOCAL_ADMIN_OPEN_ID = "cacique-local-admin-ph";
export const ADMIN_SESSION_COOKIE = "cacique_admin_session";
export const ADMIN_DISPLAY_NAME = "PH 👑 (Desenvolvedor / ADM)";

const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const MAX_LOGIN_FAILURES = 5;
const loginFailures = new Map<string, { count: number; resetAt: number }>();
let cachedFingerprint: string | null = null;
let cachedKey: Buffer | null = null;

function passwordSalt() {
  return Buffer.from(`SORTEADO-CACIQUE:${process.env.MANUS_PROJECT_ID || "local"}:admin-password-v1`);
}

function configuredKey(): Buffer | null {
  const password = process.env.CACIQUE_ADMIN_PASSWORD;
  if (!password || password.trim().length === 0) return null;
  const fingerprint = createHash("sha256").update(password).digest("hex");
  if (fingerprint !== cachedFingerprint || !cachedKey) {
    cachedKey = scryptSync(password, passwordSalt(), 32);
    cachedFingerprint = fingerprint;
  }
  return cachedKey;
}

export function hasAdminPasswordConfigured() {
  return configuredKey() !== null;
}

export function verifyAdminPassword(candidate: string) {
  const expected = configuredKey();
  if (!expected || candidate.length === 0 || candidate.length > 256) return false;
  const actual = scryptSync(candidate, passwordSalt(), 32);
  return timingSafeEqual(actual, expected);
}

function rateLimitKey(req: Request) {
  return req.ip || req.socket.remoteAddress || "unknown";
}

export function isAdminLoginRateLimited(req: Request) {
  const key = rateLimitKey(req);
  const entry = loginFailures.get(key);
  if (!entry || entry.resetAt <= Date.now()) {
    loginFailures.delete(key);
    return false;
  }
  return entry.count >= MAX_LOGIN_FAILURES;
}

export function recordAdminLoginFailure(req: Request) {
  const key = rateLimitKey(req);
  const now = Date.now();
  const entry = loginFailures.get(key);
  if (!entry || entry.resetAt <= now) {
    loginFailures.set(key, { count: 1, resetAt: now + LOGIN_WINDOW_MS });
  } else {
    entry.count += 1;
  }
  if (loginFailures.size > 2000) {
    for (const [ip, value] of loginFailures) if (value.resetAt <= now) loginFailures.delete(ip);
  }
}

export function clearAdminLoginFailures(req: Request) {
  loginFailures.delete(rateLimitKey(req));
}

export function createAdminSession() {
  const key = configuredKey();
  if (!key) throw new Error("Admin password is not configured");
  const csrfToken = randomBytes(32).toString("base64url");
  const payload = Buffer.from(JSON.stringify({ sub: LOCAL_ADMIN_OPEN_ID, exp: Date.now() + SESSION_TTL_MS, csrfToken })).toString("base64url");
  const signature = createHmac("sha256", key).update(payload).digest("base64url");
  return { token: `${payload}.${signature}`, csrfToken };
}

export function verifyAdminSession(token: string | undefined) {
  const key = configuredKey();
  if (!token || !key) return null;
  const parts = token.split(".");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return null;
  const [payload, suppliedSignature] = parts;
  const expectedSignature = createHmac("sha256", key).update(payload).digest();
  let receivedSignature: Buffer;
  try {
    receivedSignature = Buffer.from(suppliedSignature, "base64url");
  } catch {
    return null;
  }
  if (receivedSignature.length !== expectedSignature.length || !timingSafeEqual(receivedSignature, expectedSignature)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString("utf8")) as { sub?: unknown; exp?: unknown; csrfToken?: unknown };
    if (parsed.sub !== LOCAL_ADMIN_OPEN_ID || typeof parsed.exp !== "number" || parsed.exp <= Date.now() || parsed.exp > Date.now() + SESSION_TTL_MS + 60_000) return null;
    if (typeof parsed.csrfToken !== "string" || !/^[A-Za-z0-9_-]{40,60}$/.test(parsed.csrfToken)) return null;
    return { csrfToken: parsed.csrfToken };
  } catch {
    return null;
  }
}

export function constantTimeTokenMatch(actual: string | undefined, expected: string | null) {
  if (!actual || !expected) return false;
  const a = Buffer.from(actual);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export function setAdminSessionCookies(req: Request, res: Response, session: { token: string; csrfToken: string }) {
  const options = getSessionCookieOptions(req);
  res.cookie(ADMIN_SESSION_COOKIE, session.token, { ...options, maxAge: SESSION_TTL_MS });
  res.cookie(ADMIN_CSRF_COOKIE, session.csrfToken, { ...options, httpOnly: false, maxAge: SESSION_TTL_MS });
}

export function clearAdminSessionCookies(req: Request, res: Response) {
  const options = getSessionCookieOptions(req);
  res.clearCookie(ADMIN_SESSION_COOKIE, { ...options, maxAge: 0 });
  res.clearCookie(ADMIN_CSRF_COOKIE, { ...options, httpOnly: false, maxAge: 0 });
}
