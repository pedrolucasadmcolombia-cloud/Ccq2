import { parse as parseCookieHeader } from "cookie";
import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { getUserByOpenId } from "../db";
import { ADMIN_SESSION_COOKIE, LOCAL_ADMIN_OPEN_ID, verifyAdminSession } from "./adminPassword";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
  adminPasswordSession: boolean;
  adminCsrfToken: string | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: User | null = null;
  let adminPasswordSession = false;
  let adminCsrfToken: string | null = null;

  try {
    const cookies = parseCookieHeader(opts.req.headers.cookie ?? "");
    const localSession = verifyAdminSession(cookies[ADMIN_SESSION_COOKIE]);
    if (localSession) {
      const localAdmin = await getUserByOpenId(LOCAL_ADMIN_OPEN_ID);
      if (localAdmin?.role === "admin" && localAdmin.loginMethod === "local-password") {
        user = localAdmin;
        adminPasswordSession = true;
        adminCsrfToken = localSession.csrfToken;
      }
    }
  } catch {
    // An invalid or unavailable local session falls through to Manus OAuth.
  }

  if (!user) {
    try {
      user = await sdk.authenticateRequest(opts.req);
    } catch {
      // Authentication is optional for public procedures.
      user = null;
    }
  }

  return { req: opts.req, res: opts.res, user, adminPasswordSession, adminCsrfToken };
}
