export const MAX_ROULETTE_NAMES = 48;

export type WheelSelection = {
  selectedIndex: number;
  selectedName: string;
};

export type RouletteResultEntry = WheelSelection & {
  wheelIndex: number;
  title: string;
};

export function normalizedRouletteName(name: string) {
  return name.normalize("NFKC").trim().toLocaleLowerCase("pt-BR");
}

export function parseRouletteNames(value: string) {
  return value.split(/[\n,;]+/).map(name => name.trim()).filter(Boolean);
}

export function isValidRouletteNames(names: readonly string[]) {
  if (names.length < 2 || names.length > MAX_ROULETTE_NAMES) return false;
  if (names.some(name => !name.trim() || name.trim().length > 80)) return false;
  const keys = names.map(normalizedRouletteName);
  return new Set(keys).size === keys.length;
}
