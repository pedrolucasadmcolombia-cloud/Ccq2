import { useEffect, useId, useRef } from "react";
import { PartyPopper, UserRoundPlus, X } from "lucide-react";
import { Button } from "@/components/platform";
import type { RouletteResultEntry } from "@/lib/roulette";

const CONFETTI_COLORS = ["#e2b54e", "#c2f36b", "#5fc5d8", "#f17e74", "#a78bfa", "#f4f4ef"];

type RouletteResultDialogProps = {
  open: boolean;
  results: RouletteResultEntry[];
  onClose: () => void;
  onRemove: (result: RouletteResultEntry) => void;
  onUse: (result: RouletteResultEntry) => void;
};

export default function RouletteResultDialog({ open, results, onClose, onRemove, onUse }: RouletteResultDialogProps) {
  const titleId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open || !results.length) return;
    const previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose();
        return;
      }
      if (event.key !== "Tab" || !dialogRef.current) return;
      const focusable = Array.from(dialogRef.current.querySelectorAll<HTMLElement>("button:not([disabled]), [href], input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex='-1'])"));
      if (!focusable.length) return;
      const first = focusable[0]!;
      const last = focusable[focusable.length - 1]!;
      if (!dialogRef.current.contains(document.activeElement)) {
        event.preventDefault();
        first.focus();
      } else if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus();
    };
  }, [open, results.length, onClose]);

  if (!open || !results.length) return null;
  const combined = results.length > 1;

  return <div className="pairer-roulette-result-overlay" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
    <div ref={dialogRef} className={`pairer-roulette-result-dialog ${combined ? "has-multiple" : ""}`} role="dialog" aria-modal="true" aria-labelledby={titleId} tabIndex={-1}>
      <div className="pairer-confetti-layer" aria-hidden="true">
        {Array.from({ length: 42 }, (_, index) => <span key={index} className={`pairer-confetti ${index % 2 === 0 ? "drift-left" : "drift-right"}`} style={{ left: `${(index * 37 + 9) % 100}%`, animationDelay: `${(index % 9) * 0.08}s`, animationDuration: `${2.7 + (index % 5) * 0.2}s`, backgroundColor: CONFETTI_COLORS[index % CONFETTI_COLORS.length] }} />)}
      </div>
      <div className="pairer-roulette-result-header">
        <div className="pairer-roulette-result-title"><span><PartyPopper size={18}/></span><h2 id={titleId}>Resultado:</h2></div>
        <button ref={closeRef} type="button" className="pairer-roulette-result-close" onClick={onClose} aria-label="Fechar resultado"><X size={18}/></button>
      </div>
      <div className="pairer-roulette-result-list">
        {results.map(result => <div className="pairer-roulette-result-highlight" key={`${result.wheelIndex}-${result.selectedIndex}-${result.selectedName}`}>
          <div className="pairer-roulette-selected-copy"><small>{result.title} · NOME SORTEADO</small><strong>{result.selectedName}</strong></div>
          <div className="pairer-roulette-result-entry-actions">
            <Button onClick={() => onUse(result)}><UserRoundPlus size={14}/> Usar no pareador</Button>
            <button type="button" className="pairer-roulette-remove-button" onClick={() => onRemove(result)} aria-label={`Remover ${result.selectedName} da lista da ${result.title}`}>Remover</button>
          </div>
        </div>)}
      </div>
      <p className="pairer-roulette-result-caption">{combined ? "As três roletas pararam. Confira os resultados; cada nome ainda será validado pelo cadastro ao entrar no pareamento." : "O sorteio terminou. Você pode usar o nome no pareamento, remover da roleta ou fechar sem alterar a lista."}</p>
      <div className="pairer-roulette-result-actions"><button type="button" className="btn btn-secondary" onClick={onClose}>Fechar</button></div>
    </div>
  </div>;
}
