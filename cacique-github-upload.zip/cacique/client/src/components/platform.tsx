import type { ReactNode } from "react";
import { ArrowUpRight, Crown, ShieldCheck } from "lucide-react";

export function PageTitle({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div><div className="eyebrow">{eyebrow ?? "CENTRAL CACIQUE"}</div><h1 className="page-title">{title}</h1>{description && <p className="mt-2 max-w-2xl text-sm leading-6 text-[var(--muted)]">{description}</p>}</div>{action}</div>;
}
export function Panel({ title, subtitle, action, children, className = "" }: { title?: string; subtitle?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="mb-4 flex items-center justify-between gap-3">{title ? <div><h2 className="panel-title">{title}</h2>{subtitle && <p className="mt-1 text-xs text-[var(--muted)]">{subtitle}</p>}</div> : <span />}{action}</div>{children}</section>;
}
export function StatCard({ label, value, footnote, icon: Icon, tone = "gold" }: { label: string; value: string | number; footnote?: string; icon: typeof Crown; tone?: "gold" | "green" | "neutral" }) {
  return <div className={`stat-card tone-${tone}`}><div className="flex items-start justify-between"><span className="stat-label">{label}</span><span className="stat-icon"><Icon size={17} /></span></div><div className="stat-value">{value}</div><div className="mt-2 flex items-center gap-1 text-[11px] text-[var(--muted)]">{footnote ?? "Dados da comunidade"}<ArrowUpRight size={12} className="text-[var(--gold)]" /></div></div>;
}
export function EmptyState({ icon: Icon, title, detail }: { icon: typeof ShieldCheck; title: string; detail: string }) {
  return <div className="empty-state"><span className="empty-icon"><Icon size={22} /></span><h3>{title}</h3><p>{detail}</p></div>;
}
export function Badge({ children, color }: { children: ReactNode; color?: string | null }) {
  return <span className="badge" style={color ? { color, borderColor: `${color}55`, background: `${color}14` } : undefined}>{children}</span>;
}
export function Button({ children, variant = "primary", className = "", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "quiet" | "danger" }) {
  return <button className={`btn btn-${variant} ${className}`} {...props}>{children}</button>;
}
export function TextInput({ label, ...props }: React.InputHTMLAttributes<HTMLInputElement> & { label?: string }) {
  return <label className="field-wrap">{label && <span className="field-label">{label}</span>}<input className="field-input" {...props} /></label>;
}
export function SelectInput({ label, children, ...props }: React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string }) {
  return <label className="field-wrap">{label && <span className="field-label">{label}</span>}<select className="field-input" {...props}>{children}</select></label>;
}
export function Notice({ children, tone = "info" }: { children: ReactNode; tone?: "info" | "success" | "error" }) {
  return <div className={`notice notice-${tone}`}>{children}</div>;
}
export function Avatar({ name, src, size = "md" }: { name: string; src?: string | null; size?: "sm" | "md" | "lg" }) {
  return <span className={`avatar avatar-${size}`}>{src ? <img src={src} alt={`Avatar de ${name}`} /> : name.slice(0, 2).toUpperCase()}</span>;
}
