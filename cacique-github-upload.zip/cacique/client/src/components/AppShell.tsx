import type { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Activity, ArrowUpRight, CircleHelp, Crown, Flame, Gamepad2, Globe2, Home, ListChecks, Medal, Menu, Shield, Swords, Users, X } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";

const nav = [
  { href: "/", label: "Painel", icon: Home },
  { href: "/ranking", label: "Ranking", icon: Medal },
  { href: "/jogadores", label: "Jogadores", icon: Users },
  { href: "/confrontos", label: "Pareador", icon: Swords },
  { href: "/partidas", label: "Partidas", icon: Gamepad2 },
  { href: "/auditoria", label: "Auditoria", icon: Shield },
  { href: "/sorteios", label: "Sorteios", icon: Flame },
  { href: "/estatisticas", label: "Estatísticas", icon: Activity },
  { href: "/comunidade", label: "Comunidade", icon: Globe2 },
];

export function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const { data: me } = trpc.auth.me.useQuery(undefined, { retry: false });
  const { data: role } = trpc.auth.role.useQuery(undefined, { enabled: !!me, retry: false });
  return <div className="app-frame">
    <aside className="sidebar">
      <Link href="/" className="brand-mark"><span className="brand-emblem"><img src="/cacique-mark.svg" alt="" className="h-8 w-8 object-contain" /></span><span><b>CACIQUE</b><small>SORTEADOS</small></span></Link>
      <div className="sidebar-caption">ARENA</div>
      <nav className="side-nav">{nav.map(item => { const active = item.href === "/" ? location === "/" : location.startsWith(item.href); const Icon = item.icon; return <Link key={item.href} href={item.href} className={`nav-link ${active ? "is-active" : ""}`}><Icon size={17} /><span>{item.label}</span>{active && <i />}</Link>; })}</nav>
      <div className="sidebar-caption mt-auto">COMUNIDADE</div>
      <Link href="/regras" className={`nav-link ${location === "/regras" ? "is-active" : ""}`}><CircleHelp size={17} /><span>Regras da arena</span></Link>
      <Link href="/admin" className={`nav-link nav-admin ${location.startsWith("/admin") ? "is-active" : ""}`}><Shield size={17} /><span>{role && role !== "member" ? "Administração" : "Acesso admin"}</span><ArrowUpRight size={13} /></Link>
      <div className="sidebar-status"><span className="live-dot" /><div><b>ARENA OPERACIONAL</b><small>Comunidade ativa</small></div></div>
    </aside>
    <div className="main-column">
      <header className="topbar"><button aria-label="Abrir menu" className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X size={19} /> : <Menu size={19} />}</button><div className="topbar-crumb"><span>CACIQUE</span><b>/</b><span>{nav.find(item => item.href === location)?.label ?? (location === "/regras" ? "Regras" : location.startsWith("/admin") ? "Administração" : "Arena")}</span></div><div className="topbar-right"><span className="live-pill"><i /> AO VIVO</span><span className="topbar-user">{me?.name?.slice(0, 16) ?? "VISITANTE"}</span></div></header>
      {menuOpen && <div className="mobile-drawer"><div className="drawer-head"><strong>NAVEGAÇÃO</strong><button onClick={() => setMenuOpen(false)} aria-label="Fechar menu"><X size={18} /></button></div>{[...nav, { href: "/regras", label: "Regras da arena", icon: CircleHelp }, { href: "/admin", label: "Administração", icon: Shield }].map(item => { const Icon = item.icon; return <Link key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className="nav-link"><Icon size={17} />{item.label}</Link>; })}</div>}
      <main className="main-content">{children}</main>
      <footer className="footer"><span><b>CACIQUE SORTEADOS</b> · SORTEADO CACIQUE</span><span>Resultados auditados. Disputas limpas.</span></footer>
    </div>
    <nav className="mobile-bottom">{nav.slice(0, 5).map(item => { const Icon = item.icon; const active = item.href === "/" ? location === "/" : location.startsWith(item.href); return <Link key={item.href} href={item.href} className={active ? "active" : ""}><Icon size={18} /><span>{item.label}</span></Link>; })}</nav>
  </div>;
}
