import { useEffect, useMemo, useRef, useState } from "react";
import { AlertCircle, Check, Dices, UserRoundPlus } from "lucide-react";
import { Badge, Button } from "@/components/platform";
import RouletteResultDialog from "@/components/RouletteResultDialog";
import { isValidRouletteNames, normalizedRouletteName, parseRouletteNames, type RouletteResultEntry, type WheelSelection } from "@/lib/roulette";

type BatchSpin = { runId: number; selection: WheelSelection };
type RouletteWheelProps = {
  wheelIndex: number;
  title: string;
  value: string;
  disabled?: boolean;
  busy?: boolean;
  batchSpin?: BatchSpin | null;
  onChange: (value: string) => void;
  onSpin: (names: string[]) => Promise<WheelSelection>;
  onUseName: (name: string) => boolean;
  onSpinningChange: (wheelIndex: number, spinning: boolean) => void;
  onBatchComplete: (wheelIndex: number, runId: number, selection: WheelSelection) => void;
  onBatchError: (runId: number, message: string) => void;
};

const COLORS: Array<{ fill: string; text: string }> = [
  { fill: "#dc3d3d", text: "#fff" },
  { fill: "#318fce", text: "#07131a" },
  { fill: "#f0dc45", text: "#16170e" },
  { fill: "#684995", text: "#fff" },
  { fill: "#e8e8df", text: "#171915" },
  { fill: "#ed851b", text: "#17140d" },
  { fill: "#2ca453", text: "#07170d" },
  { fill: "#38a9c7", text: "#07151a" },
];
const FULL_SPIN_MS = 5000;

function point(angle: number, radius: number) {
  const radians = (angle * Math.PI) / 180;
  return { x: 100 + Math.cos(radians) * radius, y: 100 + Math.sin(radians) * radius };
}

function sectorPath(index: number, count: number) {
  const span = 360 / count;
  const start = -90 + index * span;
  const end = start + span;
  const first = point(start, 94);
  const last = point(end, 94);
  const largeArc = span > 180 ? 1 : 0;
  return `M 100 100 L ${first.x.toFixed(2)} ${first.y.toFixed(2)} A 94 94 0 ${largeArc} 1 ${last.x.toFixed(2)} ${last.y.toFixed(2)} Z`;
}

function shortLabel(name: string, max: number) {
  return name.length > max ? `${name.slice(0, max - 1)}…` : name;
}

export default function RouletteWheel({
  wheelIndex,
  title,
  value,
  disabled = false,
  busy = false,
  batchSpin = null,
  onChange,
  onSpin,
  onUseName,
  onSpinningChange,
  onBatchComplete,
  onBatchError,
}: RouletteWheelProps) {
  const names = useMemo(() => parseRouletteNames(value), [value]);
  const [rotation, setRotation] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [requesting, setRequesting] = useState(false);
  const [duration, setDuration] = useState(FULL_SPIN_MS);
  const [selectedName, setSelectedName] = useState("");
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [resultOpen, setResultOpen] = useState(false);
  const [error, setError] = useState("");
  const timerRef = useRef<number | null>(null);
  const reportedSpinningRef = useRef(false);
  const lastBatchRunRef = useRef(0);

  const duplicate = names.some((name, index) => names.findIndex(other => normalizedRouletteName(other) === normalizedRouletteName(name)) !== index);
  const tooLong = names.some(name => name.length > 80);
  const valid = isValidRouletteNames(names);
  const validationMessage = names.length === 0
    ? "Digite ou cole pelo menos dois nomes, um por linha."
    : names.length < 2
      ? "Adicione mais um nome para habilitar o giro."
      : names.length > 48
        ? "Cada roleta aceita até 48 nomes."
        : tooLong
          ? "Cada nome pode ter no máximo 80 caracteres."
          : duplicate
            ? "Há nomes duplicados. Cada participante precisa aparecer uma única vez."
            : "O giro usa uma seleção aleatória no servidor.";

  function reportSpinning(next: boolean) {
    setSpinning(next);
    if (reportedSpinningRef.current !== next) {
      reportedSpinningRef.current = next;
      onSpinningChange(wheelIndex, next);
    }
  }

  useEffect(() => {
    setSelectedName("");
    setSelectedIndex(null);
    setError("");
    setResultOpen(false);
    if (timerRef.current !== null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (reportedSpinningRef.current) {
      reportedSpinningRef.current = false;
      onSpinningChange(wheelIndex, false);
    }
    setSpinning(false);
  }, [value, onSpinningChange, wheelIndex]);

  useEffect(() => () => {
    if (timerRef.current !== null) window.clearTimeout(timerRef.current);
  }, []);

  function animateSelection(selection: WheelSelection, batchRunId: number | null) {
    if (!valid || selection.selectedIndex < 0 || selection.selectedIndex >= names.length || names[selection.selectedIndex] !== selection.selectedName) {
      const message = "O resultado não corresponde à lista atual. Confira os nomes e tente novamente.";
      setError(message);
      if (batchRunId !== null) onBatchError(batchRunId, message);
      return;
    }

    const reducedMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false;
    const spinDuration = reducedMotion ? 80 : FULL_SPIN_MS;
    setError("");
    setSelectedName("");
    setSelectedIndex(null);
    setResultOpen(false);
    setRequesting(false);
    setDuration(spinDuration);
    const span = 360 / names.length;
    const midpoint = -90 + (selection.selectedIndex + 0.5) * span;
    const targetAngle = ((-midpoint % 360) + 360) % 360;
    const currentAngle = ((rotation % 360) + 360) % 360;
    const delta = (targetAngle - currentAngle + 360) % 360;
    reportSpinning(true);
    setRotation(rotation + 6 * 360 + delta);

    if (timerRef.current !== null) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => {
      reportSpinning(false);
      setSelectedName(selection.selectedName);
      setSelectedIndex(selection.selectedIndex);
      if (batchRunId === null) setResultOpen(true);
      else onBatchComplete(wheelIndex, batchRunId, selection);
      timerRef.current = null;
    }, spinDuration + 100);
  }

  useEffect(() => {
    if (!batchSpin || batchSpin.runId <= lastBatchRunRef.current) return;
    lastBatchRunRef.current = batchSpin.runId;
    animateSelection(batchSpin.selection, batchSpin.runId);
  }, [batchSpin?.runId, batchSpin?.selection]);

  async function spin() {
    if (!valid || disabled || busy || spinning || requesting) return;
    setError("");
    setSelectedName("");
    setSelectedIndex(null);
    setResultOpen(false);
    setRequesting(true);
    try {
      const selection = await onSpin(names);
      if (selection.selectedIndex < 0 || selection.selectedIndex >= names.length || names[selection.selectedIndex] !== selection.selectedName) {
        throw new Error("A resposta da roleta não corresponde à lista atual. Confira os nomes e tente novamente.");
      }
      animateSelection(selection, null);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : "Não foi possível girar a roleta.";
      setError(message);
      setRequesting(false);
      reportSpinning(false);
    }
  }

  function closeResult() {
    setResultOpen(false);
  }

  function removeSelectedName() {
    if (!selectedName) return;
    const selectedKey = normalizedRouletteName(selectedName);
    onChange(names.filter(name => normalizedRouletteName(name) !== selectedKey).join("\n"));
    setResultOpen(false);
  }

  function useSelectedName() {
    if (selectedName && onUseName(selectedName)) setResultOpen(false);
  }

  const fontSize = names.length <= 5 ? 7 : names.length <= 8 ? 6 : names.length <= 12 ? 5 : 4.5;
  const labelRadius = names.length <= 8 ? 57 : 65;
  const wheelId = title.replace(/\s/g, "-").toLowerCase();
  const resultEntry: RouletteResultEntry[] = selectedName && selectedIndex !== null ? [{ wheelIndex, title, selectedName, selectedIndex }] : [];

  return <article className="pairer-roulette-card">
    <div className="pairer-roulette-heading">
      <div><span className="pairer-roulette-index"><Dices size={14}/></span><b>{title}</b></div>
      <Badge color="#d8b65b">{names.length} {names.length === 1 ? "nome" : "nomes"}</Badge>
    </div>

    <div className={`pairer-roulette-stage ${spinning ? "is-spinning" : ""}`} aria-busy={spinning || requesting}>
      <span className="pairer-roulette-pointer" aria-hidden="true"/>
      <svg className="pairer-roulette-wheel" viewBox="0 0 200 200" role="img" aria-label={`${title}: ${names.length ? names.join(", ") : "nenhum nome inserido"}`} style={{ transform: `rotate(${rotation}deg)`, transitionDuration: `${duration}ms` }}>
        <circle cx="100" cy="100" r="96" fill="#101512" stroke="#d8b65b" strokeWidth="2"/>
        {names.length > 1 && names.map((name, index) => {
          const span = 360 / names.length;
          const midpoint = -90 + (index + 0.5) * span;
          const labelPoint = point(midpoint, labelRadius);
          const normalizedAngle = ((midpoint % 360) + 360) % 360;
          const textRotation = normalizedAngle > 90 && normalizedAngle < 270 ? midpoint + 180 : midpoint;
          const label = names.length > 14 ? String(index + 1).padStart(2, "0") : shortLabel(name, names.length <= 6 ? 11 : names.length <= 10 ? 7 : 4);
          const color = COLORS[index % COLORS.length]!;
          return <g key={`${index}-${name}`}>
            <path d={sectorPath(index, names.length)} fill={color.fill} stroke="#171c19" strokeWidth="1.3"/>
            <text x={labelPoint.x} y={labelPoint.y} transform={`rotate(${textRotation} ${labelPoint.x} ${labelPoint.y})`} textAnchor="middle" dominantBaseline="middle" fill={color.text} fontSize={names.length > 14 ? 5 : fontSize} fontWeight="800" letterSpacing=".1">{label}</text>
          </g>;
        })}
        {names.length === 1 && <><circle cx="100" cy="100" r="94" fill={COLORS[0]!.fill}/><text x="100" y="78" textAnchor="middle" fill="#fff" fontSize="9" fontWeight="800">{shortLabel(names[0]!, 16)}</text><text x="100" y="119" textAnchor="middle" fill="#fff" fontSize="7">ADICIONE MAIS UM</text></>}
        {names.length === 0 && <><circle cx="100" cy="100" r="94" fill="#1b211d"/><circle cx="100" cy="100" r="69" fill="none" stroke="#303931" strokeWidth="1.5" strokeDasharray="4 5"/><text x="100" y="94" textAnchor="middle" fill="#99a49b" fontSize="9" fontWeight="800">ADICIONE</text><text x="100" y="109" textAnchor="middle" fill="#99a49b" fontSize="9" fontWeight="800">NOMES</text></>}
        <circle cx="100" cy="100" r="23" fill="#111613" stroke="#e2b54e" strokeWidth="2"/>
        <text x="100" y="104" textAnchor="middle" fill="#e2b54e" fontSize="9" fontWeight="900" letterSpacing="1">C</text>
      </svg>
    </div>

    <label className="pairer-roulette-label" htmlFor={`roulette-${wheelId}`}>NOMES DESTA ROLETA</label>
    <textarea id={`roulette-${wheelId}`} className="field-input pairer-roulette-input" value={value} onChange={event => onChange(event.target.value)} disabled={disabled || busy || spinning || requesting} placeholder={"Cole ou digite um nome por linha\nHype\nPimba\nDoc"} aria-label={`${title}: digite os nomes, um por linha`}/>
    <div className={`pairer-roulette-hint ${!valid && names.length > 0 ? "is-error" : ""}`}>{!valid && names.length > 0 ? <AlertCircle size={13}/> : <Check size={13}/>}<span>{validationMessage}</span></div>

    <div className="pairer-roulette-actions">
      <Button className="pairer-roulette-spin-button" onClick={() => void spin()} disabled={!valid || disabled || busy || spinning || requesting}>
        <Dices size={15}/>{requesting ? "Sorteando no servidor…" : spinning ? "Girando…" : busy ? "Aguarde…" : "Girar roleta"}
      </Button>
      {selectedName && <Button variant="secondary" onClick={useSelectedName} disabled={disabled}>
        <UserRoundPlus size={14}/> Usar no pareador
      </Button>}
    </div>

    <div className={`pairer-roulette-result ${selectedName ? "has-result" : ""}`} aria-live="polite">
      {selectedName ? <><span>SORTEADO</span><b>{selectedName}</b></> : error ? <><AlertCircle size={14}/><span>{error}</span></> : <span>{spinning || requesting ? "A roleta está girando…" : "O resultado aparecerá aqui"}</span>}
    </div>

    <RouletteResultDialog open={resultOpen && resultEntry.length > 0} results={resultEntry} onClose={closeResult} onRemove={removeSelectedName} onUse={useSelectedName}/>
  </article>;
}
