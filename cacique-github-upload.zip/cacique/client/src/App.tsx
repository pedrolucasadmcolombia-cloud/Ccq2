import { lazy, Suspense } from "react";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { AppShell } from "./components/AppShell";
import { HomePage, RankingPage, PlayersPage, PlayerProfilePage, CommunityPage, RulesPage } from "./pages/PublicPages";
import { MatchesPage, AuditPage, DrawsPage } from "./pages/CompetitionPages";
import PairerPage from "./pages/PairerPage";
import { AdminPage, AdminLoginPage } from "./pages/AdminPages";
import { ThemeProvider } from "./contexts/ThemeContext";

const StatsPage = lazy(() => import("./pages/StatsPage"));
function LazyStatsPage(){return <Suspense fallback={<div className="panel text-xs text-[#9ba69d]" role="status">Carregando estatísticas…</div>}><StatsPage/></Suspense>;}

function SiteRoutes() {
  return <Switch>
    <Route path="/admin/login" component={AdminLoginPage} />
    <Route><AppShell><Switch>
      <Route path="/" component={HomePage} />
      <Route path="/ranking" component={RankingPage} />
      <Route path="/jogadores" component={PlayersPage} />
      <Route path="/jogadores/:id" component={PlayerProfilePage} />
      <Route path="/confrontos" component={PairerPage} />
      <Route path="/partidas" component={MatchesPage} />
      <Route path="/auditoria" component={AuditPage} />
      <Route path="/sorteios" component={DrawsPage} />
      <Route path="/estatisticas" component={LazyStatsPage} />
      <Route path="/comunidade" component={CommunityPage} />
      <Route path="/regras" component={RulesPage} />
      <Route path="/admin" component={AdminPage} />
      <Route path="/admin/config" component={AdminPage} />
      <Route><NotFound /></Route>
    </Switch></AppShell></Route>
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="dark"><TooltipProvider><Toaster richColors position="top-right" /><SiteRoutes /></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
