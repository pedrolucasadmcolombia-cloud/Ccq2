import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Check, CircleAlert, ClipboardList, Copy, Download, Dices, LogIn, RefreshCw, ShieldCheck, Swords, Trash2, Trophy, Users } from "lucide-react";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { toPng } from "html-to-image";
import { trpc } from "@/lib/trpc";
import { Avatar, Badge, Button, Notice, PageTitle, Panel, SelectInput, TextInput } from "@/components/platform";
import RouletteWheel from "@/components/RouletteWheel";
import RouletteResultDialog from "@/components/RouletteResultDialog";
import { isValidRouletteNames, normalizedRouletteName, parseRouletteNames, type RouletteResultEntry, type WheelSelection } from "@/lib/roulette";

type Mode = "1x1" | "2x2" | "3x3" | "4x4" | "custom";
type MatchedPlayer = { id: number; nickname: string; points: number; seriesId: number | null; seriesName: string | null };
type Slot = { nickname: string; seriesId: number | null; seriesSelected: boolean; stakeAmount: number; player: MatchedPlayer | null };
type Participant = { id: number; nickname: string; points: number; seriesId: number | null; seriesName: string | null; seriesOrder: number | null; stakeAmount: number };
type Duel = { first: Participant; second: Participant };
type FinalTeams = { blue: Participant[]; red: Participant[] };
type BatchSpinRequest = { runId: number; results: [WheelSelection, WheelSelection, WheelSelection] };
type BatchSpinTracker = { runId: number; completed: Set<number>; results: Array<RouletteResultEntry | null> };
type PairerDraft = { version: 1; format: Mode; customSize: string; title: string; slots: Slot[]; duels: Duel[] | null; teams: FinalTeams | null; savedMatchId: number | null; resultReported: boolean; rawText?: string; resolvedImportText?: string; unrecognizedLines?: string[]; unknownResolutions?: Record<number, "fixed" | "not-player">; excessCount?: number; rouletteTexts?: [string, string, string] };

const DRAFT_KEY = "cacique-pairer-draft-v1";
const currency = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

function emptySlot(): Slot { return { nickname: "", seriesId: null, seriesSelected: false, stakeAmount: 15, player: null }; }
function emptySlots() { return Array.from({ length: 12 }, emptySlot); }

function loadDraft(): PairerDraft | null {
  if (typeof window === "undefined") return null;
  try {
    const value = JSON.parse(window.localStorage.getItem(DRAFT_KEY) ?? "null") as Partial<PairerDraft> | null;
    if (!value || value.version !== 1 || !Array.isArray(value.slots) || value.slots.length !== 12 || !(value.teams === null || (value.teams && Array.isArray(value.teams.blue) && Array.isArray(value.teams.red)))) return null;
    if (!Array.isArray(value.rouletteTexts) || value.rouletteTexts.length !== 3 || !value.rouletteTexts.every(text => typeof text === "string")) value.rouletteTexts = ["", "", ""];
    return value as PairerDraft;
  } catch {
    return null;
  }
}

function modeForCount(count: number): { format: Mode; customSize: string } | null {
  if (count < 2 || count > 12 || count % 2 !== 0) return null;
  const size = count / 2;
  return size <= 4 ? { format: `${size}x${size}` as Mode, customSize: "5" } : { format: "custom", customSize: String(size) };
}

function balanceText(first: Participant, second: Participant) {
  const pointGap = Math.abs(first.points - second.points);
  if (first.seriesId === second.seriesId) return `${first.seriesName ?? "Sem série"} nos dois lados · Δ ${pointGap} pts`;
  return `${first.seriesName ?? "Sem série"} × ${second.seriesName ?? "Sem série"} · Δ ${pointGap} pts`;
}

export default function PairerPage() {
  const [initialDraft] = useState(loadDraft);
  const [format, setFormat] = useState<Mode>(initialDraft?.format ?? "3x3");
  const [customSize, setCustomSize] = useState(initialDraft?.customSize ?? "5");
  const [matchTitle, setMatchTitle] = useState(initialDraft?.title ?? "");
  const [slots, setSlots] = useState<Slot[]>(initialDraft?.slots ?? emptySlots());
  const [duels, setDuels] = useState<Duel[] | null>(initialDraft?.duels ?? null);
  const [teams, setTeams] = useState<FinalTeams | null>(initialDraft?.teams ?? null);
  const [savedMatchId, setSavedMatchId] = useState<number | null>(initialDraft?.savedMatchId ?? null);
  const [resultReported, setResultReported] = useState(initialDraft?.resultReported ?? false);
  const [rouletteTexts, setRouletteTexts] = useState<[string, string, string]>(initialDraft?.rouletteTexts ?? ["", "", ""]);
  const [activeWheelSpins, setActiveWheelSpins] = useState<Set<number>>(() => new Set());
  const [batchSpinning, setBatchSpinning] = useState(false);
  const [batchSpinRequest, setBatchSpinRequest] = useState<BatchSpinRequest | null>(null);
  const [batchResultEntries, setBatchResultEntries] = useState<RouletteResultEntry[]>([]);
  const [batchResultOpen, setBatchResultOpen] = useState(false);
  const [rawText, setRawText] = useState(initialDraft?.rawText ?? "");
  const [resolvedImportText, setResolvedImportText] = useState(initialDraft?.resolvedImportText ?? "");
  const [unrecognizedLines, setUnrecognizedLines] = useState<string[]>(initialDraft?.unrecognizedLines ?? []);
  const [unknownResolutions, setUnknownResolutions] = useState<Record<number, "fixed" | "not-player">>(initialDraft?.unknownResolutions ?? {});
  const [excessCount, setExcessCount] = useState(initialDraft?.excessCount ?? 0);
  const [notice, setNotice] = useState("");
  const [noticeTone, setNoticeTone] = useState<"info" | "success" | "error">("info");
  const [resultScore, setResultScore] = useState("");
  const storyRef = useRef<HTMLDivElement>(null);
  const batchRunIdRef = useRef(0);
  const batchTrackerRef = useRef<BatchSpinTracker | null>(null);
  const [, navigate] = useLocation();

  const role = trpc.auth.role.useQuery(undefined, { retry: false });
  const manager = role.data === "owner" || role.data === "match_admin";
  const seriesQuery = trpc.series.list.useQuery();
  const utils = trpc.useUtils();
  const resolveRoster = trpc.pairer.resolveRoster.useMutation();
  const wheelSpin = trpc.pairer.spinWheel.useMutation();
  const spinAllMutation = trpc.pairer.spinAllWheels.useMutation();
  const generation = trpc.pairer.generate.useMutation();
  const drawMutation = trpc.pairer.drawTeams.useMutation();
  const createBatch = trpc.matches.createBatch.useMutation();
  const reportResult = trpc.matches.setResult.useMutation();
  const seriesById = useMemo(() => new Map((seriesQuery.data ?? []).map(item => [item.id, item])), [seriesQuery.data]);
  const teamSize = format === "custom" ? Number(customSize) || 1 : Number(format[0]);
  const wheelNameLists = useMemo(() => rouletteTexts.map(parseRouletteNames) as [string[], string[], string[]], [rouletteTexts]);
  const canSpinAll = wheelNameLists.every(isValidRouletteNames);
  const rouletteBusy = wheelSpin.isPending || spinAllMutation.isPending || batchSpinning || activeWheelSpins.size > 0;
  const activeSlots = slots.slice(0, teamSize * 2);
  const unresolvedLineIndexes = useMemo(() => unrecognizedLines.map((_, index) => index).filter(index => !unknownResolutions[index]), [unrecognizedLines, unknownResolutions]);
  const importPending = Boolean(rawText.trim() && rawText !== resolvedImportText);
  const hasLocalDraft = Boolean(rawText.trim() || rouletteTexts.some(text => text.trim()) || slots.some(slot => slot.nickname.trim() || slot.player || slot.seriesSelected || slot.stakeAmount !== 15) || duels || teams || savedMatchId !== null);
  const duplicateIds = useMemo(() => {
    const counts = new Map<number, number>();
    for (const slot of activeSlots) if (slot.player) counts.set(slot.player.id, (counts.get(slot.player.id) ?? 0) + 1);
    return new Set([...counts.entries()].filter(([, count]) => count > 1).map(([id]) => id));
  }, [activeSlots]);

  const handleWheelSpinningChange = useCallback((wheelIndex: number, spinning: boolean) => {
    setActiveWheelSpins(current => {
      if (current.has(wheelIndex) === spinning) return current;
      const next = new Set(current);
      if (spinning) next.add(wheelIndex);
      else next.delete(wheelIndex);
      return next;
    });
  }, []);

  const handleBatchWheelComplete = useCallback((wheelIndex: number, runId: number, selection: WheelSelection) => {
    if (!Number.isInteger(wheelIndex) || wheelIndex < 0 || wheelIndex > 2) return;
    const tracker = batchTrackerRef.current;
    if (!tracker || tracker.runId !== runId || tracker.completed.has(wheelIndex)) return;
    tracker.results[wheelIndex] = { wheelIndex, title: `Roleta ${wheelIndex + 1}`, ...selection };
    tracker.completed.add(wheelIndex);
    if (tracker.completed.size !== 3) return;
    const results = tracker.results.filter((entry): entry is RouletteResultEntry => entry !== null);
    batchTrackerRef.current = null;
    if (results.length !== 3) {
      setBatchSpinning(false);
      setNotice("Não foi possível reunir os três resultados. Tente girar as roletas novamente.");
      setNoticeTone("error");
      return;
    }
    setBatchResultEntries(results);
    setBatchResultOpen(true);
    setBatchSpinning(false);
  }, []);

  const handleBatchWheelError = useCallback((runId: number, message: string) => {
    if (batchTrackerRef.current?.runId !== runId) return;
    batchTrackerRef.current = null;
    setBatchSpinRequest(null);
    setBatchSpinning(false);
    setNotice(message);
    setNoticeTone("error");
    toast.error(message);
  }, []);

  const shareText = useMemo(() => {
    if (!teams) return "";
    const heading = matchTitle.trim() || `Sorteio Cacique · ${teamSize}x${teamSize}`;
    const renderTeam = (label: string, roster: Participant[]) => [`${label}`, ...roster.map(player => `• ${player.nickname} · ${player.seriesName ?? "Sem série"} · ${currency.format(player.stakeAmount)}`)].join("\n");
    const duelsText = duels?.length ? ["DUELOS 1v1", ...duels.map((duel, index) => `${index + 1}. ${duel.first.nickname} × ${duel.second.nickname}`)].join("\n") : "";
    return [`⚔️ SORTEADO CACIQUE · ${teamSize}x${teamSize}`, heading, "", renderTeam("🔵 TIME AZUL · LADO A", teams.blue), "", renderTeam("🔴 TIME VERMELHO · LADO B", teams.red), ...(duelsText ? ["", duelsText] : []), "", "Sorteio realizado no sistema Cacique."].join("\n");
  }, [teams, duels, matchTitle, teamSize]);

  useEffect(() => {
    if (!hasLocalDraft || resultReported) {
      window.localStorage.removeItem(DRAFT_KEY);
      return;
    }
    const draft: PairerDraft = { version: 1, format, customSize, title: matchTitle, slots, duels, teams, savedMatchId, resultReported, rawText, resolvedImportText, unrecognizedLines, unknownResolutions, excessCount, rouletteTexts };
    window.localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
  }, [format, customSize, matchTitle, slots, duels, teams, savedMatchId, resultReported, rawText, resolvedImportText, unrecognizedLines, unknownResolutions, excessCount, rouletteTexts, hasLocalDraft]);

  function clearPreview() {
    setDuels(null);
    setTeams(null);
    setSavedMatchId(null);
    setResultReported(false);
    setResultScore("");
  }

  function changeSlot(index: number, patch: Partial<Slot>) {
    if (savedMatchId) return;
    setSlots(current => current.map((slot, slotIndex) => slotIndex === index ? { ...slot, ...patch } : slot));
    setUnknownResolutions({});
    clearPreview();
    setNotice("");
  }

  function clearEverything() {
    if (rouletteBusy) return;
    if (savedMatchId && !window.confirm(`A partida #${savedMatchId} já foi criada e continuará no histórico. Limpar apenas este rascunho salvo neste dispositivo?`)) return;
    setRawText("");
    setRouletteTexts(["", "", ""]);
    setBatchSpinRequest(null);
    setBatchResultEntries([]);
    setBatchResultOpen(false);
    batchTrackerRef.current = null;
    setResolvedImportText("");
    setUnrecognizedLines([]);
    setUnknownResolutions({});
    setExcessCount(0);
    setSlots(emptySlots());
    setFormat("3x3");
    setCustomSize("5");
    setMatchTitle("");
    setNotice("");
    clearPreview();
    window.localStorage.removeItem(DRAFT_KEY);
  }

  function changeRouletteText(index: number, value: string) {
    if (!Number.isInteger(index) || index < 0 || index > 2) return;
    setRouletteTexts(current => {
      const next = [...current] as [string, string, string];
      next[index] = value;
      return next;
    });
    setBatchSpinRequest(null);
    setBatchResultEntries([]);
    setBatchResultOpen(false);
  }

  async function spinAllWheels() {
    if (!canSpinAll || rouletteBusy || savedMatchId) return;
    const runId = batchRunIdRef.current + 1;
    batchRunIdRef.current = runId;
    batchTrackerRef.current = { runId, completed: new Set(), results: [null, null, null] };
    setBatchSpinRequest(null);
    setBatchResultEntries([]);
    setBatchResultOpen(false);
    setBatchSpinning(true);
    try {
      const response = await spinAllMutation.mutateAsync({ wheels: wheelNameLists });
      if (response.results.length !== 3) throw new Error("O servidor não retornou os três resultados.");
      const results = response.results as [WheelSelection, WheelSelection, WheelSelection];
      for (const [index, selection] of results.entries()) {
        const names = wheelNameLists[index]!;
        if (!isValidRouletteNames(names) || selection.selectedIndex < 0 || selection.selectedIndex >= names.length || names[selection.selectedIndex] !== selection.selectedName) {
          throw new Error(`O resultado da Roleta ${index + 1} não corresponde à lista atual. Confira os nomes e tente novamente.`);
        }
      }
      setBatchSpinRequest({ runId, results });
    } catch (error) {
      batchTrackerRef.current = null;
      setBatchSpinning(false);
      const message = error instanceof Error ? error.message : "Não foi possível girar as três roletas.";
      setNotice(message);
      setNoticeTone("error");
      toast.error(message);
    }
  }

  function removeBatchWheelResult(result: RouletteResultEntry) {
    if (result.wheelIndex < 0 || result.wheelIndex > 2) return;
    const nameKey = normalizedRouletteName(result.selectedName);
    setRouletteTexts(current => {
      const next = [...current] as [string, string, string];
      next[result.wheelIndex] = parseRouletteNames(next[result.wheelIndex]!).filter(name => normalizedRouletteName(name) !== nameKey).join("\n");
      return next;
    });
    const remaining = batchResultEntries.filter(entry => entry.wheelIndex !== result.wheelIndex);
    setBatchResultEntries(remaining);
    if (!remaining.length) setBatchResultOpen(false);
  }

  function useBatchWheelResult(result: RouletteResultEntry) {
    if (useRouletteName(result.selectedName)) {
      setBatchResultOpen(false);
      setBatchResultEntries([]);
    }
  }

  function useRouletteName(name: string): boolean {
    if (savedMatchId) return false;
    const trimmedName = name.trim();
    const key = trimmedName.normalize("NFKC").toLocaleLowerCase("pt-BR");
    if (activeSlots.some(slot => slot.nickname.trim() && slot.nickname.trim().normalize("NFKC").toLocaleLowerCase("pt-BR") === key)) {
      setNotice(`“${trimmedName}” já está em uma vaga ativa. Escolha outro nome ou remova a duplicata.`);
      setNoticeTone("error");
      toast.error("O nome sorteado já consta em uma vaga.");
      return false;
    }
    const emptyIndex = activeSlots.findIndex(slot => !slot.nickname.trim());
    if (emptyIndex < 0) {
      setNotice("Todas as vagas ativas estão preenchidas. Libere uma vaga ou escolha um formato maior antes de adicionar o sorteado.");
      setNoticeTone("error");
      toast.error("Não há vaga ativa vazia para preencher.");
      return false;
    }
    const next = [...slots];
    next[emptyIndex] = { ...emptySlot(), nickname: trimmedName };
    setSlots(next);
    setUnknownResolutions({});
    clearPreview();
    setNotice(`“${trimmedName}” foi colocado na vaga ${String(emptyIndex + 1).padStart(2, "0")}; o nick será validado pelo cadastro ao gerar os duelos.`);
    setNoticeTone("info");
    toast.success("Nome sorteado adicionado à próxima vaga vazia.");
    return true;
  }

  async function fillVacancies() {
    if (!rawText.trim()) { setNotice("Cole a lista do WhatsApp antes de preencher as vagas."); setNoticeTone("error"); return; }
    try {
      const result = await resolveRoster.mutateAsync({ text: rawText });
      clearPreview();
      setResolvedImportText(rawText);
      setUnrecognizedLines(result.unrecognizedLines);
      setUnknownResolutions({});
      setExcessCount(result.excessCount);
      if (!result.slots.length) {
        setSlots(emptySlots());
        setFormat("3x3");
        setCustomSize("5");
        setNotice("Nenhum nick cadastrado foi reconhecido. Revise as linhas abaixo e preencha as vagas manualmente; não será possível confirmar enquanto houver linha sem resolução.");
        setNoticeTone("error");
        toast.error("A lista ainda contém linhas sem jogador reconhecido.");
        return;
      }
      const nextSlots = emptySlots();
      result.slots.forEach((entry, index) => {
        nextSlots[index] = {
          nickname: entry.nickname,
          seriesId: entry.seriesId,
          seriesSelected: entry.seriesOverridden,
          stakeAmount: entry.stakeAmount,
          player: { id: entry.playerId, nickname: entry.nickname, points: entry.points, seriesId: entry.currentSeriesId, seriesName: entry.currentSeriesName },
        };
      });
      setSlots(nextSlots);
      const suggested = modeForCount(result.slots.length);
      if (suggested) { setFormat(suggested.format); setCustomSize(suggested.customSize); }
      const parts = [`${result.slots.length} jogador(es) reconhecido(s) e preenchido(s).`];
      if (result.duplicates.length) parts.push(`Duplicados: ${result.duplicates.join(", ")}.`);
      if (result.unrecognizedLines.length) {
        const examples = result.unrecognizedLines.slice(0, 5).map(line => `“${line.slice(0, 70)}”`).join(" · ");
        parts.push(`${result.unrecognizedLines.length} linha(s) sem jogador reconhecido: ${examples}${result.unrecognizedLines.length > 5 ? " · …" : ""}. Revise se eram participantes.`);
      }
      if (result.excessCount) parts.push(`${result.excessCount} jogador(es) excedente(s) não entrou/entraram nas 12 vagas.`);
      setNotice(parts.join(" "));
      setNoticeTone(result.duplicates.length || result.excessCount || result.unrecognizedLines.length ? "error" : "success");
      if (result.duplicates.length || result.excessCount || result.unrecognizedLines.length) toast.error("Revise duplicados, linhas não reconhecidas e excedentes antes de gerar.");
      else toast.success("Vagas preenchidas a partir da lista.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível interpretar a lista.";
      setNotice(message); setNoticeTone("error"); toast.error(message);
    }
  }

  async function generateDuels(excludeCurrent = false) {
    if (!manager) return;
    if (importPending) { setNotice("A lista colada mudou. Clique em “Preencher Vagas” para reprocessá-la antes de gerar."); setNoticeTone("error"); return; }
    if (unresolvedLineIndexes.length) { setNotice("Resolva cada linha não reconhecida: corrija o nick em uma vaga ou marque explicitamente que não é um participante."); setNoticeTone("error"); return; }
    if (excessCount) { setNotice(`A lista tem ${excessCount} participante(s) além do limite de 12. Ajuste o texto e importe novamente antes de gerar.`); setNoticeTone("error"); return; }
    const names = activeSlots.map(slot => slot.nickname.trim());
    if (names.some(name => !name)) { setNotice(`Preencha todos os ${teamSize * 2} nicks antes de gerar os duelos.`); setNoticeTone("error"); return; }
    try {
      const validation = await utils.pairer.validateNames.fetch({ names });
      if (validation.unknown.length) throw new Error(`Nicks não cadastrados: ${validation.unknown.join(", ")}.`);
      if (validation.duplicates.length) throw new Error(`Remova os nicks duplicados: ${validation.duplicates.join(", ")}.`);
      const matched = validation.players.map(item => item.matched);
      if (matched.some(player => !player || player.status !== "active")) throw new Error("Há jogador inativo ou não cadastrado. Somente participantes ativos podem entrar no pareamento.");
      const nextSlots = activeSlots.map((slot, index) => {
        const player = matched[index]!;
        return {
          ...slot,
          nickname: player.nickname,
          seriesId: slot.seriesSelected ? slot.seriesId : player.seriesId,
          player: { id: player.id, nickname: player.nickname, points: player.points, seriesId: player.seriesId, seriesName: player.seriesName },
        };
      });
      const sourcePairs = excludeCurrent && duels ? duels.map(duel => [duel.first.id, duel.second.id] as [number, number]) : [];
      const seriesOverrides = nextSlots.filter(slot => slot.seriesSelected && slot.player).map(slot => ({ playerId: slot.player!.id, seriesId: slot.seriesId }));
      const result = await generation.mutateAsync({ playerIds: nextSlots.map(slot => slot.player!.id), mode: "1x1", balance: true, avoidRematches: true, sourcePairs, seriesOverrides });
      const slotByPlayer = new Map(nextSlots.map(slot => [slot.player!.id, slot]));
      const nextDuels: Duel[] = result.pairings.map(pairing => {
        const first = pairing.teamA[0]!;
        const second = pairing.teamB[0]!;
        return {
          first: { ...first, stakeAmount: slotByPlayer.get(first.id)?.stakeAmount ?? 15 },
          second: { ...second, stakeAmount: slotByPlayer.get(second.id)?.stakeAmount ?? 15 },
        };
      });
      setSlots(current => current.map((slot, index) => index < nextSlots.length ? nextSlots[index]! : slot));
      setDuels(nextDuels);
      setTeams(null); setSavedMatchId(null); setResultReported(false);
      setNotice(result.note); setNoticeTone("success");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível gerar os duelos.";
      setNotice(message); setNoticeTone("error"); toast.error(message);
    }
  }

  async function drawFinalTeams() {
    if (!duels?.length) return;
    try {
      const result = await drawMutation.mutateAsync({ duels: duels.map(duel => [duel.first.id, duel.second.id] as [number, number]) });
      const byId = new Map<number, Participant>();
      duels.forEach(duel => { byId.set(duel.first.id, duel.first); byId.set(duel.second.id, duel.second); });
      setTeams({ blue: result.teamA.map(id => byId.get(id)!), red: result.teamB.map(id => byId.get(id)!) });
      setSavedMatchId(null); setResultReported(false);
      setNotice("Sorteio 50/50 concluído: cada duelo enviou um jogador para cada lado."); setNoticeTone("success");
      toast.success("Times Azul e Vermelho sorteados.");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível sortear os times.";
      setNotice(message); setNoticeTone("error"); toast.error(message);
    }
  }

  async function saveMatch() {
    if (!teams || savedMatchId) return;
    if (importPending || unresolvedLineIndexes.length || excessCount) { setNotice("Resolva a lista importada e remova os excedentes antes de salvar a partida."); setNoticeTone("error"); return; }
    const mode = `${teamSize}x${teamSize}`;
    const title = matchTitle.trim() || `Sorteio Cacique · ${mode}`;
    if (!window.confirm(`Salvar esta escalação como partida agendada ${mode}? A pontuação só muda após resultado e auditoria aprovados.`)) return;
    try {
      const participantDetails = [...teams.blue, ...teams.red].map(player => ({ playerId: player.id, stakeAmount: player.stakeAmount, seriesIdAtMatch: player.seriesId }));
      const result = await createBatch.mutateAsync({ matches: [{ mode, title, teamA: teams.blue.map(player => player.id), teamB: teams.red.map(player => player.id), participantDetails }] });
      const id = result.ids[0];
      if (!id) throw new Error("A partida não retornou um identificador válido.");
      setSavedMatchId(id); setNotice(`Escalação salva como partida #${id}. O resultado e os comprovantes ainda serão registrados após a partida.`); setNoticeTone("success");
      await Promise.all([utils.matches.list.invalidate(), utils.dashboard.overview.invalidate(), utils.administration.auditLog.invalidate()]);
      toast.success(`Partida #${id} salva no histórico.`);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível salvar a escalação.";
      setNotice(message); setNoticeTone("error"); toast.error(message);
    }
  }

  async function registerWinner(winnerTeam: "A" | "B") {
    if (!savedMatchId || resultReported) return;
    const side = winnerTeam === "A" ? "Azul" : "Vermelho";
    if (!window.confirm(`Registrar vitória do Time ${side} na partida #${savedMatchId}? A pontuação continuará pendente até a auditoria dos comprovantes.`)) return;
    try {
      const score = resultScore.trim();
      await reportResult.mutateAsync({ id: savedMatchId, winnerTeam, resultText: `Vitória Time ${side}${score ? ` · ${score}` : ""}`.slice(0, 160) });
      setResultReported(true);
      await utils.matches.list.invalidate();
      toast.success("Resultado encaminhado; envie os comprovantes individuais na página Partidas.");
      navigate("/partidas");
    } catch (error) {
      const message = error instanceof Error ? error.message : "Não foi possível registrar a vitória.";
      setNotice(message); setNoticeTone("error"); toast.error(message);
    }
  }

  async function copyForWhatsApp() {
    if (!shareText) return;
    try {
      if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(shareText);
      else {
        const field = document.createElement("textarea"); field.value = shareText; field.style.position = "fixed"; field.style.opacity = "0";
        document.body.appendChild(field); field.select(); document.execCommand("copy"); field.remove();
      }
      toast.success("Texto copiado para compartilhar no WhatsApp.");
    } catch { toast.error("Não foi possível copiar. Selecione o texto e copie manualmente."); }
  }

  async function downloadStory() {
    if (!storyRef.current) return;
    try {
      await document.fonts.ready;
      const png = await toPng(storyRef.current, { cacheBust: true, pixelRatio: 3, width: 360, height: 640 });
      const link = document.createElement("a");
      link.download = `cacique-stories-${new Date().toISOString().slice(0, 10)}.png`;
      link.href = png; link.click();
      toast.success("Banner Story baixado em PNG vertical 1080 × 1920.");
    } catch { toast.error("Não foi possível exportar o banner. Tente novamente."); }
  }

  if (role.isLoading) return <Panel title="Pareador inteligente"><p className="text-sm text-[#9ba69d]">Verificando a permissão administrativa…</p></Panel>;
  if (!manager) return <><PageTitle eyebrow="FERRAMENTA DA EQUIPE" title="Pareador inteligente" description="O pareamento e a confirmação de partidas ficam restritos à equipe autorizada."/><Notice tone="info">Entre com uma conta autorizada como Administrador principal ou Administrador de partidas para importar listas, sortear times e registrar partidas.</Notice><Link href="/admin/login" className="btn btn-primary mt-4 inline-flex"><LogIn size={14}/> Entrar no painel administrativo</Link></>;

  return <>
    <PageTitle eyebrow="ORGANIZAÇÃO COMPETITIVA · CACIQUE SORTEADOS" title="Sorteado Cacique" description="Preencha as vagas, revise os duelos 1v1 e só então sorteie os times Azul e Vermelho." action={<Badge color="#d8b65b">{teamSize}x{teamSize} · {teamSize * 2} vagas</Badge>}/>
    <div className="pairer-stepbar" aria-label="Etapas do pareamento">
      <div className={`pairer-step ${!duels ? "is-current" : "is-complete"}`}><span>01</span><div><b>Vagas e duelos</b><small>Equilíbrio por série e pontos</small></div></div>
      <div className="pairer-step-connector"/>
      <div className={`pairer-step ${teams ? "is-complete" : duels ? "is-current" : ""}`}><span>02</span><div><b>Sorteio 50/50</b><small>Um de cada duelo em cada lado</small></div></div>
      <div className="pairer-step-local"><ShieldCheck size={13}/> {resultReported ? "Resultado enviado à auditoria" : hasLocalDraft ? "Rascunho salvo neste dispositivo" : "Prévia sem salvar partida"}</div>
    </div>

    <Panel className="pairer-panel pairer-roulette-panel mt-4" title="Três roletas de nomes" subtitle="Cada roleta tem uma lista independente. O resultado pode ser enviado para a próxima vaga ativa vazia.">
      <div className="pairer-roulette-batch-toolbar">
        <div><b>Giro simultâneo</b><small>As três roletas param juntas; o resultado só aparece quando todas terminarem.</small></div>
        <Button onClick={() => void spinAllWheels()} disabled={!canSpinAll || rouletteBusy || Boolean(savedMatchId)}><Dices size={15}/>{batchSpinning ? "Girando as 3 roletas…" : "Girar as 3 roletas"}</Button>
      </div>
      <div className="pairer-roulette-grid">
        {rouletteTexts.map((text, index) => <RouletteWheel key={`roulette-${index + 1}`} wheelIndex={index} title={`Roleta ${index + 1}`} value={text} onChange={value => changeRouletteText(index, value)} onSpin={names => wheelSpin.mutateAsync({ names })} onUseName={useRouletteName} onSpinningChange={handleWheelSpinningChange} onBatchComplete={handleBatchWheelComplete} onBatchError={handleBatchWheelError} batchSpin={batchSpinRequest ? { runId: batchSpinRequest.runId, selection: batchSpinRequest.results[index]! } : null} disabled={Boolean(savedMatchId)} busy={rouletteBusy}/>)}
      </div>
      <p className="pairer-roulette-footnote">Cada nome é sorteado com aleatoriedade criptográfica no servidor. Nomes escolhidos continuam sujeitos à validação dos jogadores ativos antes da geração dos duelos.</p>
    </Panel>
    <RouletteResultDialog open={batchResultOpen} results={batchResultEntries} onClose={() => setBatchResultOpen(false)} onRemove={removeBatchWheelResult} onUse={useBatchWheelResult}/>

    <div className="pairer-workspace">
      <Panel className="pairer-panel" title="Lista do WhatsApp" subtitle="Cole nicks cadastrados em linhas separadas ou em pares como “Jogador A - Jogador B”. Os pares colados serão desfeitos e redistribuídos.">
        <textarea className="field-input pairer-whatsapp-input" value={rawText} onChange={event => { setRawText(event.target.value); clearPreview(); }} disabled={Boolean(savedMatchId)} placeholder={'3x3 · FULL UMP\nHype · DIAMANTE I · R$ 12\nPimba · MESTRE · R$ 15'} aria-label="Lista de participantes colada do WhatsApp"/>
        <div className="pairer-toolbar">
          <Button onClick={() => void fillVacancies()} disabled={!rawText.trim() || resolveRoster.isPending || Boolean(savedMatchId)}><ClipboardList size={14}/>{resolveRoster.isPending ? "Lendo lista…" : "Preencher Vagas"}</Button>
          <Button variant="secondary" onClick={clearEverything} disabled={createBatch.isPending || rouletteBusy}><Trash2 size={14}/> Limpar tudo</Button>
          <span className="pairer-helper"><CircleAlert size={13}/> A série por vaga vale só para esta partida; o perfil não será alterado.</span>
        </div>
        {importPending && <div className="mt-3"><Notice tone="error">A lista foi alterada depois da última leitura. Reprocesse-a antes de gerar os duelos.</Notice></div>}
        {unrecognizedLines.length > 0 && <div className="pairer-unresolved-list" role="group" aria-label="Resolução de linhas não reconhecidas">
          <div className="pairer-unresolved-heading"><b>LINHAS SEM JOGADOR RECONHECIDO</b><span>{unresolvedLineIndexes.length ? `${unresolvedLineIndexes.length} pendente(s)` : "todas revisadas"}</span></div>
          <p>Não confirme uma lista com participante faltando. Em cada linha, corrija o nick em uma vaga ou declare explicitamente que o texto não é um participante.</p>
          {unrecognizedLines.map((line, index) => <div className={`pairer-unresolved-row ${unknownResolutions[index] ? "is-resolved" : ""}`} key={`${index}-${line}`}>
            <div className="pairer-unresolved-copy"><b>{line}</b><small>{unknownResolutions[index] === "fixed" ? "Marcada como corrigida em uma vaga; os nicks ainda serão validados." : unknownResolutions[index] === "not-player" ? "Confirmado como cabeçalho/texto que não é participante." : "Escolha como esta linha foi resolvida."}</small></div>
            <div className="pairer-unresolved-actions">
              <Button variant={unknownResolutions[index] === "fixed" ? "primary" : "secondary"} disabled={Boolean(savedMatchId)} onClick={() => { setUnknownResolutions(current => ({ ...current, [index]: "fixed" })); clearPreview(); }}>Corrigi em uma vaga</Button>
              <Button variant={unknownResolutions[index] === "not-player" ? "primary" : "quiet"} disabled={Boolean(savedMatchId)} onClick={() => { setUnknownResolutions(current => ({ ...current, [index]: "not-player" })); clearPreview(); }}>Não é participante</Button>
            </div>
          </div>)}
        </div>}
        {excessCount > 0 && <div className="mt-3"><Notice tone="error">{excessCount} participante(s) excedente(s) ficaram fora das 12 vagas. Reduza a lista importada para impedir omissão silenciosa.</Notice></div>}
      </Panel>

      <Panel className="pairer-panel" title="Etapa 1 · Vagas e formato" subtitle="Cada vaga tem nick, série e aposta individual. Seis vagas vêm selecionadas no modo 3x3.">
        <div className="pairer-format-row">
          <SelectInput label="Formato" value={format} disabled={Boolean(savedMatchId)} onChange={event => { const value = event.target.value as Mode; setFormat(value); clearPreview(); }}>
            <option value="1x1">1x1 · 2 vagas</option><option value="2x2">2x2 · 4 vagas</option><option value="3x3">3x3 · 6 vagas</option><option value="4x4">4x4 · 8 vagas</option><option value="custom">Personalizado</option>
          </SelectInput>
          {format === "custom" && <SelectInput label="Jogadores por equipe" value={customSize} disabled={Boolean(savedMatchId)} onChange={event => { setCustomSize(event.target.value); clearPreview(); }}>{[1,2,3,4,5,6].map(count => <option key={count} value={count}>{count}x{count} · {count * 2} vagas</option>)}</SelectInput>}
          <div className="pairer-format-note"><Users size={15}/><span><b>{teamSize * 2} vagas ativas</b><small>Máximo: 12 participantes</small></span></div>
        </div>
        <div className="pairer-slot-grid">
          {activeSlots.map((slot, index) => {
            const seriesValue = slot.seriesSelected ? slot.seriesId === null ? "__none" : String(slot.seriesId) : "__current";
            const seriesName = slot.player?.seriesName ?? "a validar";
            const duplicate = Boolean(slot.player && duplicateIds.has(slot.player.id));
            return <article className={`pairer-slot-card ${duplicate ? "is-duplicate" : ""}`} key={index}>
              <div className="pairer-slot-heading"><b>VAGA {String(index + 1).padStart(2, "0")}</b><span>{slot.player ? `${slot.player.points} pts` : "PENDENTE"}</span></div>
              <TextInput label="Nick Free Fire" maxLength={40} value={slot.nickname} disabled={Boolean(savedMatchId)} onChange={event => changeSlot(index, { nickname: event.target.value, player: null, seriesId: null, seriesSelected: false })} placeholder="Nick cadastrado"/>
              <SelectInput label="Série neste confronto" value={seriesValue} disabled={Boolean(savedMatchId)} onChange={event => {
                const value = event.target.value;
                if (value === "__current") changeSlot(index, { seriesSelected: false, seriesId: slot.player?.seriesId ?? null });
                else if (value === "__none") changeSlot(index, { seriesSelected: true, seriesId: null });
                else changeSlot(index, { seriesSelected: true, seriesId: Number(value) });
              }}>
                <option value="__current">Do cadastro · {seriesName}</option><option value="__none">Sem série neste confronto</option>
                {seriesQuery.data?.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}
              </SelectInput>
              <TextInput label="Aposta individual (R$)" type="number" inputMode="numeric" min={0} max={100000} step={1} value={slot.stakeAmount} disabled={Boolean(savedMatchId)} onChange={event => changeSlot(index, { stakeAmount: Math.min(100000, Math.max(0, Number(event.target.value) || 0)) })}/>
              <div className={`pairer-slot-status ${duplicate ? "has-error" : ""}`}>{duplicate ? <><CircleAlert size={12}/> Jogador duplicado — troque uma vaga</> : slot.player ? <><Check size={12}/> Cadastro ativo · {slot.player.seriesName ?? "sem série"}</> : <><CircleAlert size={12}/> O nick será validado ao gerar</>}</div>
            </article>;
          })}
        </div>
        <div className="pairer-primary-actions">
          <Button onClick={() => void generateDuels(false)} disabled={generation.isPending || Boolean(savedMatchId) || importPending || unresolvedLineIndexes.length > 0 || excessCount > 0}><Dices size={15}/>{generation.isPending ? "Gerando duelos…" : "1. Gerar Pareamento (Duelos 1v1)"}</Button>
          {duels && <Button variant="secondary" onClick={() => void generateDuels(true)} disabled={generation.isPending || Boolean(savedMatchId)}><RefreshCw size={14}/> Alterar pareamento</Button>}
        </div>
        {notice && <div className="mt-3"><Notice tone={noticeTone}>{notice}</Notice></div>}
      </Panel>

      {duels && <Panel className="pairer-panel mt-4" title="Etapa 1/2 · Duelos 1v1" subtitle="Revise os adversários e os indicadores derivados de série e pontuação antes do sorteio dos lados." action={<Badge>{duels.length} duelo(s)</Badge>}>
        <div className="pairer-duel-grid">
          {duels.map((duel, index) => <article className="pairer-duel-card" key={`${duel.first.id}-${duel.second.id}`}>
            <div className="pairer-duel-heading"><b>DUELO {String(index + 1).padStart(2, "0")}</b><Badge color="#d8b65b">1v1</Badge></div>
            {[duel.first, duel.second].map((player, side) => <div className="pairer-duel-person" key={player.id}>
              <Avatar name={player.nickname} size="sm"/><span className="pairer-duel-details"><b>{player.nickname}</b><small>{player.seriesName ?? "Sem série"} · {player.points} pts · {currency.format(player.stakeAmount)}</small></span>
              {side === 0 && <Swords size={14} className="pairer-duel-swords"/>}
            </div>)}
            <div className="pairer-balance-indicator"><CircleAlert size={13}/><span>{balanceText(duel.first, duel.second)}</span></div>
          </article>)}
        </div>
        <div className="pairer-primary-actions pairer-stage-two-action">
          <Button className="pairer-button-green" onClick={() => void drawFinalTeams()} disabled={drawMutation.isPending || Boolean(savedMatchId)}><Dices size={15}/>{drawMutation.isPending ? "Sorteando…" : "2. Realizar Sorteio dos Times (50/50)"}</Button>
          <p>O servidor distribui um jogador de cada duelo para cada time e evita qualquer revanche contra adversários já enfrentados.</p>
        </div>
      </Panel>}

      {teams && <>
        <Panel className="pairer-panel mt-4" title="Resultado do sorteio · Times finais" subtitle="Cada duelo contribuiu com exatamente um jogador para cada lado; apostas e séries ficam registradas por participante.">
          <div className="pairer-team-grid">
            {([{ key: "blue", label: "TIME AZUL", side: "LADO A", roster: teams.blue }, { key: "red", label: "TIME VERMELHO", side: "LADO B", roster: teams.red }] as const).map(team => <section className={`pairer-team-card pairer-team-${team.key}`} key={team.key}>
              <div className="pairer-team-heading"><div><b>{team.label}</b><small>{team.side} · {team.roster.length} jogador(es)</small></div><span className="pairer-team-light"/></div>
              <div className="pairer-team-roster">{team.roster.map((player, index) => <div className="pairer-final-player" key={player.id}>
                <span className="pairer-final-number">{String(index + 1).padStart(2, "0")}</span><Avatar name={player.nickname} size="sm"/>
                <span className="pairer-final-details"><b>{player.nickname}</b><small><Badge color={player.seriesId === null ? undefined : seriesById.get(player.seriesId)?.color}>{player.seriesName ?? "Sem série"}</Badge><em>{currency.format(player.stakeAmount)}</em></small></span>
              </div>)}</div>
            </section>)}
          </div>
          <div className="pairer-share-block">
            <div className="pairer-share-heading"><div><b>Texto pronto para WhatsApp</b><small>Inclui times, séries e apostas individuais</small></div><div className="pairer-share-buttons"><Button variant="secondary" onClick={() => void copyForWhatsApp()}><Copy size={14}/> Copiar pro WhatsApp</Button><Button variant="secondary" onClick={() => void downloadStory()}><Download size={14}/> Baixar Banner (Stories)</Button></div></div>
            <textarea className="field-input pairer-share-text" readOnly value={shareText} aria-label="Texto pronto para WhatsApp"/>
          </div>
          <div className="pairer-save-row">
            <TextInput label="Identificação da sala/partida (opcional)" maxLength={120} value={matchTitle} disabled={Boolean(savedMatchId)} onChange={event => setMatchTitle(event.target.value)} placeholder={`Sorteio Cacique · ${teamSize}x${teamSize}`}/>
            {savedMatchId ? <Notice tone="success">Partida #{savedMatchId} salva como agendada. O rascunho também fica neste dispositivo.</Notice> : <Button onClick={() => void saveMatch()} disabled={createBatch.isPending}><Check size={15}/>{createBatch.isPending ? "Salvando…" : "Salvar escalação como partida"}</Button>}
          </div>
        </Panel>

        {savedMatchId && <Panel className="pairer-panel mt-4" title="Após a partida · resultado e comprovantes" subtitle="Registrar o vencedor não altera a pontuação: os comprovantes individuais ainda precisam ser enviados e aprovados na auditoria.">
          {!resultReported ? <><TextInput label="Placar (opcional)" maxLength={60} value={resultScore} onChange={event => setResultScore(event.target.value)} placeholder="Ex.: 5 × 3"/>
            <div className="pairer-result-actions"><Button className="pairer-button-blue" onClick={() => void registerWinner("A")} disabled={reportResult.isPending}><Trophy size={14}/> Registrar vitória Time Azul</Button><Button className="pairer-button-red" onClick={() => void registerWinner("B")} disabled={reportResult.isPending}><Trophy size={14}/> Registrar vitória Time Vermelho</Button></div>
          </> : <Notice tone="success">Resultado enviado para análise. Continue em Partidas para acompanhar os comprovantes.</Notice>}
          <Link href="/partidas" className="pairer-history-link">Abrir Partidas e comprovantes <span>→</span></Link>
        </Panel>}
      </>}
    </div>

    {teams && <div className="pairer-story-stage" aria-hidden="true"><div className="pairer-story-canvas" ref={storyRef}>
      <div className="pairer-story-brand"><span className="pairer-story-mark">C</span><span>SORTEADO <b>CACIQUE</b></span><small>ARENA FREE FIRE</small></div>
      <div className="pairer-story-title"><small>ESCALAÇÃO OFICIAL</small><h2>{matchTitle.trim() || `${teamSize}x${teamSize} · SORTEIO`}</h2><span>{new Date().toLocaleDateString("pt-BR")}</span></div>
      <div className="pairer-story-team pairer-story-blue"><div><b>TIME AZUL</b><small>LADO A</small></div>{teams.blue.map(player => <div className="pairer-story-player" key={player.id}><b>{player.nickname}</b><span>{player.seriesName ?? "Sem série"} · {currency.format(player.stakeAmount)}</span></div>)}</div>
      <div className="pairer-story-team pairer-story-red"><div><b>TIME VERMELHO</b><small>LADO B</small></div>{teams.red.map(player => <div className="pairer-story-player" key={player.id}><b>{player.nickname}</b><span>{player.seriesName ?? "Sem série"} · {currency.format(player.stakeAmount)}</span></div>)}</div>
      <div className="pairer-story-footer">SORTEIO 50/50 · SORTEADO CACIQUE</div>
    </div></div>}
  </>;
}
