# Plano de implementação — SORTEADO CACIQUE / CACIQUE SORTEADOS

## Direção e escopo

Construir, no projeto gerenciado já inicializado, uma aplicação responsiva para administrar a comunidade de sorteados de Free Fire. **SORTEADO CACIQUE** será o nome do sistema e **CACIQUE SORTEADOS** a marca apresentada na página inicial, mantendo o nome do sistema e a marca Cacique solicitada. O público poderá consultar conteúdo público; ações administrativas ficarão protegidas por login e autorização no servidor. Não usar dados inventados como se fossem reais: a primeira execução mostrará estados vazios e dados demonstrativos, se necessários, claramente marcados.

## Abordagem técnica e integração

- Reutilizar o starter React + TypeScript + Tailwind no cliente e Express + tRPC no servidor. Preservar Manus OAuth para identidade de jogadores e equipe; o administrador principal PH terá acesso por conta e senha conforme a escolha explícita do usuário.
- Usar Drizzle e migrações versionadas para os dados de domínio. O projeto foi inicializado com a base gerenciada Manus, **compatível com MySQL**, e com servidor e banco habilitados. Isso entrega um banco SQL persistente equivalente para as funcionalidades pedidas, mas difere do PostgreSQL nominalmente citado no anexo. Se PostgreSQL/Supabase for obrigatório, pausar antes das migrações e acordar uma integração PostgreSQL externa; essa alternativa depende de serviço e credenciais próprios e não pode ser substituída silenciosamente pela base gerenciada já escolhida.
- Separar dados em jogadores, séries, partidas, confrontos/equipes, comprovantes, eventos de pontuação, sorteios, configurações e eventos de auditoria. Aplicar índices, chaves estrangeiras, unicidade e transações para evitar duplicidades e atribuição repetida de pontos.
- Calcular ranking e estatísticas a partir de partidas auditadas e eventos de pontuação persistidos; jogador não terá procedimento de escrita de pontuação. Escrever validação Zod nos procedimentos, verificar o papel no servidor e limitar cada ação pelo papel; papéis de administrador principal, administrador de partidas, auditor e moderador. A conta PH local será criada pelo backend com papel de administrador principal somente após validação da senha protegida; o bootstrap não será uma permissão aberta ao público.
- Para imagens e provas, manter índices/ownership no banco e bytes em armazenamento durável gerenciado; validar tipo/tamanho e permissão no backend, nunca expor credenciais ou URLs temporárias. Guardar decisões e seus motivos no log de auditoria.
- A senha administrativa ficará somente em variável protegida do runtime, não será gravada no banco, código, frontend nem logs. O servidor limitará força bruta e emitirá sessão assinada de oito horas em cookie HttpOnly, Secure e SameSite=None, com proteção CSRF; OAuth continua disponível para as contas de jogadores/equipe. Recomenda-se uma senha longa e exclusiva, sem rejeitar a credencial protegida já escolhida pelo usuário.

## Páginas e comportamento

1. **Início público:** marca CACIQUE SORTEADOS, status de sistema, métricas reais, Top 3 semanal, partidas recentes, avisos, destaques, links da comunidade e atalhos.
2. **Ranking e perfil:** busca/filtros (nick, série, pontuação, vitórias, período), Top 3 com medalhas, paginação, histórico, taxa de vitória, série e tendências; ranking geral, semanal e mensal calculados a partir de dados aprovados.
3. **Jogadores:** cadastro e edição administrativa (nick, ID opcional, avatar, série, observações, status); cards em celular, tabela em desktop, prevenção de duplicidade, estatísticas e histórico. A exclusão permanente será permitida somente sem histórico de partidas/pontos; jogadores com histórico poderão ser inativados para preservar registros.
4. **Confrontos/pareador:** manter os formatos 1x1, 2x2, 3x3, 4x4 e personalizados (de 1 a 6 jogadores por equipe), com 3x3/seis vagas como padrão visual. A primeira etapa aceitará texto colado do WhatsApp, identificará jogadores cadastrados e permitirá editar nick, série usada somente neste confronto e aposta individual por vaga; linhas em formato `Jogador1 - Jogador2` serão tratadas como roster, não como equipes fixas. “Preencher Vagas” deverá resolver nomes conhecidos, série e valores explícitos em reais, deixando campos editáveis e destacando nomes não reconhecidos/duplicados. Duplicatas — inclusive repetidas na mesma linha — e excedentes acima de 12 bloquearão a geração; cada linha desconhecida exigirá correção numa vaga ou declaração explícita de que não é participante.
   - Etapa 1: gerar duelos 1v1 a partir do roster completo, equilibrando por série e pontuação real; não repetir adversários anteriores, e “Alterar Pareamento” deverá evitar os duelos recém-gerados. Cada duelo mostra os dois jogadores, suas séries/valores e um indicador transparente do equilíbrio.
	   - Etapa 2: somente após revisão dos duelos, sortear no servidor, de forma aleatória, qual participante de cada duelo vai ao Time Azul/Lado A e qual vai ao Time Vermelho/Lado B; cada duelo contribuirá exatamente um jogador para cada lado e os times terão o mesmo tamanho.
	   - A escalação final exibirá série e aposta por jogador, permitirá copiar o texto pronto para WhatsApp e baixar um banner vertical 9:16 para Stories. Só ao confirmar explicitamente será criada uma partida agendada usando o fluxo existente, salvando aposta individual e série no momento do confronto sem alterar o cadastro do jogador; após a partida, o resultado irá pelo fluxo de envio de comprovantes/auditoria já existente, sem pontuar antes da aprovação.
	   - A referência menciona “EMU/K3”, mas não especifica a regra exata para calcular essa vantagem; não codificar uma fórmula presumida. Mostrar equilíbrio/diferenças derivadas dos dados reais de série e pontuação, deixando a regra especial para quando seus critérios forem definidos.
	   - **Roletas de apoio:** acrescentar exatamente três roletas circulares independentes; cada uma aceita sua própria lista de 2 a 48 nomes, um por linha ou separados por vírgula, sem duplicatas. Um giro individual imparcial, decidido no servidor, anima até a opção escolhida e abre um modal “Resultado:” com fundo desfocado/escurecido, confetes e o nome em destaque. Acima das três rodas, “Girar as 3 roletas” envia as três listas válidas em uma única operação, sorteia cada uma independentemente e anima as três ao mesmo tempo; somente ao final abre uma modal única com os três nomes e suas roletas, sem modais sobrepostos. Oferecer “Usar no pareador” no resultado individual, “Remover” para retirar o sorteado da lista e “Fechar” sem alteração; nomes continuam sujeitos à validação normal antes dos duelos. Salvar as listas no rascunho local; em desktop organizar em três colunas, empilhar no celular e respeitar movimento reduzido.
5. **Partidas/auditoria:** registrar participantes, vencedor, resultado, data e responsável; anexar várias provas relacionadas ao jogador correto; estados `Aguardando comprovantes`, `Aguardando auditoria`, `Aprovado`, `Rejeitado` e `Em análise`; decisão de auditor com motivo; pontuar uma única vez após aprovação. Partidas ainda agendadas poderão ser editadas (título, modo, horário e distribuição das equipes) antes de comprovantes/pontuação; excluir será permitido somente sem provas ou pontuação, sempre preservando um resumo no log de auditoria.
6. **Sorteios:** vagas, participantes sem duplicidade, distribuição aleatória, modo balanceado por série, revisão/refazer antes de confirmar, histórico e autor.
7. **Estatísticas e histórico:** comparações e gráficos individuais/coletivos, histórico de confronto, filtros, exportação de ranking e denúncia de resultado.
8. **Links e regras:** grupos principal/secundário do WhatsApp, TikTok, Instagram, suporte e regras personalizáveis; configuração administrativa.
9. **Administração:** painel e configuração de séries, nomes/cores/requisitos/progressão, pontuação, links, papéis e acesso, logs administrativos, backup/exportação de dados e avisos/notificações internas. Séries padrão, nesta ordem: 👑 MESTRE; 💎 DIAMANTE I; 💎 DIAMANTE II; 💎 DIAMANTE III; 🛡️ PLATINA I; 🛡️ PLATINA II; 🛡️ PLATINA III; 🥇 OURO I; 🥈 OURO II; 🥉 OURO III.
10. **Acesso:** páginas públicas consultáveis sem login; operações de administração sempre autenticadas e autorizadas. A página `/admin/login` seguirá o print enviado: fundo da arena desfocado/escurecido, cartão/modal arredondado, escudo dourado, título/subtítulo, conta PH selecionável, senha, botão amarelo “Validar Acesso” e fechar/voltar; responsiva e mobile-first. O login de PH será validado no servidor; OAuth continua sendo login real para outras contas.

## Design

- **Movimento:** dashboard de esports competitivo com linguagem de centro de comando tático — preciso, legível e focado em desempenho, sem copiar uma marca de referência.
- **Princípios:** hierarquia clara; contraste alto; densidade de informação sem poluição; ações administrativas sempre distinguíveis e seguras.
- **Cores:** carvão/grafite como superfície estável; dourado como conquista e destaque de ranking; verde neon como atividade/confirmação; tons neutros para dados e estados. Reservar vermelho para erro/rejeição e âmbar para pendências, mantendo contraste acessível.
- **Layout:** rail lateral no desktop, navegação inferior/drawer no celular, barra contextual no topo e coluna principal de dados; rankings e partidas priorizam linhas comparáveis, com cards empilhados em telas pequenas. A tela de login aparece sobre a própria página inicial desfocada, centralizada e dimensionada para telas estreitas.
- **Motivos visuais:** marca angular inspirada em brasão/troféu; linhas finas de mira e divisores de arena; borda dourada curta para Top 3 e indicador verde de sistema online. No login, reproduzir o escudo em uma placa âmbar, contorno discreto e botão dourado de alto contraste conforme a referência fornecida.
- **Interação e movimento:** respostas táteis curtas; transições discretas em navegação, cartões e estados; skeletons na carga; nenhuma animação longa ou que impeça leitura. Ações destrutivas e de confirmação pedem revisão explícita.
- **Tipografia:** Barlow Condensed para títulos/números competitivos e Inter para texto/UI, com fallbacks de sistema; números tabulares para estatísticas.
- **Essência da marca:** “A central de confrontos e desempenho da comunidade Cacique, com resultados auditáveis e ranking confiável.” Personalidade: competitiva, transparente, precisa.
- **Voz:** CTAs curtos e objetivos; estados descrevem a próxima ação. Exemplos: “Conferir confrontos”; “Pontuação só muda após auditoria aprovada.”
- **Logotipo:** wordmark compacto CACIQUE SORTEADOS com um escudo geométrico/angular próprio; SORTEADO CACIQUE fica como assinatura do sistema.
- **Cor proprietária:** dourado-cacique (âmbar metálico) para os destaques, com verde ácido reservado a estados ativos.

## Estrutura de projeto prevista

- `client/src/App.tsx`: rotas para páginas públicas e administrativas.
- `client/src/pages/`: home, ranking, jogador/perfil, partidas/auditoria, pareador, sorteios, estatísticas, links/regras, login e administração.
- `client/src/components/`: shell de navegação, cards, filtros, tabelas responsivas, diálogos, formulários e indicadores de estado.
- `client/src/lib/`: cliente tRPC, tipos auxiliares, formatação e regras de interface.
- `client/src/index.css`: tokens escuros, contraste, tipografia e breakpoints.
- `server/routers.ts` e `server/routers/`: procedimentos públicos, operações autenticadas por domínio e autorização por papel.
- `server/_core/adminPassword.ts`: comparação da senha protegida, criação/verificação da sessão PH e controles de tentativas.
- `server/_core/context.ts` e `server/_core/trpc.ts`: resolução de sessão/cookies e proteção CSRF das mutações autenticadas.
- `server/db.ts` e `server/services/`: persistência e regras transacionais para ranking, sorteios e auditoria.
- `drizzle/schema.ts` e `drizzle/`: entidades, relações e migrações versionadas.
- `client/public/manus-routes.json`: manifesto sincronizado com as rotas renderizadas.

## Entrega e limites

Desenvolver por fatias verticais, mantendo a aplicação inicial executável: base visual/rotas e modelo de dados; cadastro/ranking; confrontos; provas/auditoria/pontuação; sorteios; estatísticas, regras, links e polimento de permissões/responsividade. Cada fluxo precisa ligar interface, validação, backend e persistência — não apenas trocar estado na tela. Incluir verificação de tipos, testes adequados às regras críticas e execução dos comandos de build/check. Preservar a configuração de publicação já existente no projeto; não alterá-la durante a implementação. O usuário confirmou que aceita MySQL gerenciado como equivalente relacional ao PostgreSQL citado no anexo.

## Decisões que precisam ficar explícitas

1. **Banco:** decisão confirmada pelo usuário — usar o banco Manus gerenciado compatível com MySQL como alternativa relacional equivalente ao PostgreSQL citado no anexo.
2. **Links sociais:** inicialmente vazios/não configurados até serem informados; o administrador poderá preenchê-los no painel.
3. **Referência da tela administrativa:** screenshot fornecido pelo usuário orienta o modal escuro, plano desfocado, conta PH, senha e CTA amarelo.
4. **Autenticação administrativa:** decisão confirmada pelo usuário — conta PH + senha; senha configurada em segredo protegido `CACIQUE_ADMIN_PASSWORD`. Manus OAuth permanece para as demais contas (jogadores/equipe).
